const SUPABASE_URL = 'https://ybccbyyrrxdzarsgylql.supabase.co';
        const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_JjkT61xxSWFUImTeMNHWxA_e1zkZWr-';
        const legacyUserSession = localStorage.getItem('smachimSession') || '';
        if (legacyUserSession) {
            sessionStorage.setItem('smachimSession', legacyUserSession);
            localStorage.removeItem('smachimSession');
        }
        const storedAdminSession = sessionStorage.getItem('smachimAdminSession') || '';
        let sessionToken = storedAdminSession || sessionStorage.getItem('smachimSession') || '';

        function createAppClient() {
            const headers = sessionToken ? { 'x-app-session': sessionToken } : {};
            return window.supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
                auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
                global: { headers }
            });
        }

        let _supabase = createAppClient();

        function applySessionToken(token) {
            sessionToken = token || '';
            sessionStorage.removeItem('smachimAdminSession');
            sessionStorage.removeItem('smachimAdminMode');
            localStorage.removeItem('smachimSession');
            if (sessionToken) sessionStorage.setItem('smachimSession', sessionToken);
            else sessionStorage.removeItem('smachimSession');
            _supabase = createAppClient();
        }

        function applyAdminSessionToken(token) {
            sessionToken = token || '';
            localStorage.removeItem('smachimSession');
            sessionStorage.removeItem('smachimSession');
            sessionStorage.removeItem('smachimAdminMode');
            if (sessionToken) {
                sessionStorage.setItem('smachimAdminSession', sessionToken);
                sessionStorage.setItem('smachimAdminMode','1');
            } else {
                sessionStorage.removeItem('smachimAdminSession');
                sessionStorage.removeItem('smachimAdminMode');
            }
            _supabase = createAppClient();
        }

        let currentUser = null;
        let currentProfile = null;
        let currentIsAdmin = false;
        let adminMode = sessionStorage.getItem('smachimAdminMode') === '1' && !!storedAdminSession;
        let hostEventsCache = new Map();
        let privateEventCache = new Map();
        let matchingEventsCache = [];
        let matchingRegsCache = [];
        let familyChildrenCache = [];
        let activeFamilyChildId = null;
        let adminUsersCache = [];
        let adminTab = 'overview';
        let adminUserSearch = '';
        let adminEventSearch = '';
        let adminEventStatus = 'all';
        let adminSmsFilter = 'all';
        let publicSiteConfig = {content:{},field_config:{}};
        let adminEditorState = null;
        let adminTextSearch = '';
        let adminTextRows = [];
        let textOverrideObserver = null;
        let textOverrideScheduled = false;
        let adminIdleTimer = null;
        const ADMIN_IDLE_MS = 30 * 60 * 1000;
        let calendarEventCache = new Map();
        let modalResolver = null;
        let dashboardArea = localStorage.getItem('smachimDashboardArea') || '';
        let routeMapInstances = new Map();
        let matchingMapObserver = null;
        let addressCitiesCache = null;
        let addressStreetCache = new Map();
        let addressListsLoading = null;
        let activeChatEventId = null;
        let activeChatEventName = '';
        let chatPollTimer = null;
        const EVENT_DRAFT_PREFIX = 'smachimEventDraftV5:';
        const LEGACY_PERSONAL_STORAGE_KEYS = ['smachimEventDraftV4','pendingHostEvent'];

        function armAdminIdleLogout(){
            if(adminIdleTimer){clearTimeout(adminIdleTimer);adminIdleTimer=null;}
            if(!adminMode)return;
            adminIdleTimer=setTimeout(()=>{
                if(adminMode){
                    showToast('סשן המנהל נסגר לאחר חוסר פעילות.','warning');
                    handleLogout();
                }
            },ADMIN_IDLE_MS);
        }

        function eventDraftKey() {
            return sessionToken && currentProfile?.id ? EVENT_DRAFT_PREFIX + currentProfile.id : '';
        }

        function clearAllPersonalBrowserStorage() {
            try {
                [...Object.keys(localStorage)].forEach(key => {
                    if (key.startsWith(EVENT_DRAFT_PREFIX) || key.startsWith('smachimEventDraft')) localStorage.removeItem(key);
                });
                LEGACY_PERSONAL_STORAGE_KEYS.forEach(key=>localStorage.removeItem(key));
                localStorage.removeItem('smachimDashboardArea');
                sessionStorage.removeItem('smachimSession');
                sessionStorage.removeItem('smachimAdminMode');
                sessionStorage.removeItem('smachimAdminSession');
            } catch(_) {}
        }

        function clearSensitiveForms() {
            ['login-form','admin-password-form','reset-password-form','volunteer-form','event-form','edit-event-form','profile-form','support-form'].forEach(id=>{
                try { $(id)?.reset(); } catch(_) {}
            });
            ['profile-phone-display','profile-role-display','user-greeting'].forEach(id=>{
                const el=$(id); if(el) el.textContent='';
            });
            try { toggleManualAddress('vol',false); } catch(_) {}
            try { toggleManualAddress('ev',false); } catch(_) {}
            try { toggleManualAddress('edit-ev',false); } catch(_) {}
            try { toggleManualAddress('profile',false); } catch(_) {}
            try { syncVolunteerGuardianMode(); } catch(_) {}
            if($('draft-indicator')) $('draft-indicator').textContent='';
        }

        function clearRuntimeUserData() {
            currentUser=null;
            currentProfile=null;
            currentIsAdmin=false;
            adminMode=false;
            if(adminIdleTimer){clearTimeout(adminIdleTimer);adminIdleTimer=null;}
            dashboardArea='';
            hostEventsCache.clear();
            privateEventCache.clear();
            matchingEventsCache=[];
            matchingRegsCache=[];
            adminUsersCache=[];
            calendarEventCache.clear();
            routeMapInstances.forEach(m=>{try{m.remove();}catch(_){}});
            routeMapInstances.clear();
            if(matchingMapObserver){try{matchingMapObserver.disconnect();}catch(_){}matchingMapObserver=null;}
            if(chatPollTimer){clearInterval(chatPollTimer);chatPollTimer=null;}
            activeChatEventId=null;
            activeChatEventName='';
            const chat=$('chat-modal');
            if(chat){chat.classList.add('hidden');chat.classList.remove('flex');}
            if($('chat-messages')) $('chat-messages').innerHTML='';
            if($('chat-input')) $('chat-input').value='';
            if($('chat-title')) $('chat-title').textContent='צ׳אט האירוע';
            if($('dashboard-content')) $('dashboard-content').innerHTML='';
            if($('modal-message')) $('modal-message').textContent='';
            if($('modal-input')) $('modal-input').value='';
            clearSensitiveForms();
        }

        function clearGuestFormWhenLeaving(nextView) {
            if(sessionToken) return;
            const active=document.querySelector('.screen.active');
            if(!active) return;
            const current=active.id.replace('view-','');
            if(current===nextView) return;
            if(['login','reset-password','register-volunteer','add-event','support'].includes(current)) clearSensitiveForms();
        }

        const $ = (id) => document.getElementById(id);
        const esc = (value) => String(value ?? '')
            .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;').replaceAll("'", '&#039;');

        let lastFocusedBeforeAppModal = null;
        let lastFocusedBeforeChat = null;
        let lastFocusedBeforeAccessibility = null;
        let accessibilityInitialized = false;
        const ACCESSIBILITY_PREFS_KEY = 'smachimA11yPrefsV1';
        let accessibilityPrefs = {
            fontScale:1,
            highContrast:false,
            grayscale:false,
            underlineLinks:false,
            readableFont:false,
            reduceMotion:false
        };

        function loadAccessibilityPreferences() {
            try {
                const saved=JSON.parse(localStorage.getItem(ACCESSIBILITY_PREFS_KEY)||'null');
                if(saved&&typeof saved==='object'){
                    accessibilityPrefs={
                        ...accessibilityPrefs,
                        ...saved,
                        fontScale:Math.min(2,Math.max(1,Number(saved.fontScale)||1))
                    };
                }
            } catch(_) {}
            applyAccessibilityPreferences(false);
        }

        function saveAccessibilityPreferences() {
            try{localStorage.setItem(ACCESSIBILITY_PREFS_KEY,JSON.stringify(accessibilityPrefs));}catch(_){}
        }

        function applyAccessibilityPreferences(announce=false) {
            const root=document.documentElement;
            root.style.setProperty('--a11y-scale',String(accessibilityPrefs.fontScale));
            root.classList.toggle('a11y-high-contrast',!!accessibilityPrefs.highContrast);
            root.classList.toggle('a11y-grayscale',!!accessibilityPrefs.grayscale);
            root.classList.toggle('a11y-underlined-links',!!accessibilityPrefs.underlineLinks);
            root.classList.toggle('a11y-readable-font',!!accessibilityPrefs.readableFont);
            root.classList.toggle('a11y-reduce-motion',!!accessibilityPrefs.reduceMotion);

            const value=$('a11y-font-value');
            if(value)value.textContent=Math.round(accessibilityPrefs.fontScale*100)+'%';

            const map={
                'a11y-high-contrast-btn':'highContrast',
                'a11y-grayscale-btn':'grayscale',
                'a11y-links-btn':'underlineLinks',
                'a11y-font-btn':'readableFont',
                'a11y-motion-btn':'reduceMotion'
            };
            Object.entries(map).forEach(([id,key])=>{
                const btn=$(id);
                if(btn)btn.setAttribute('aria-pressed',accessibilityPrefs[key]?'true':'false');
            });

            if(announce)announceA11y('הגדרות הנגישות עודכנו');
        }

        function changeAccessibilityFont(delta) {
            const next=Math.round((accessibilityPrefs.fontScale+Number(delta))*10)/10;
            accessibilityPrefs.fontScale=Math.min(2,Math.max(1,next));
            saveAccessibilityPreferences();
            applyAccessibilityPreferences(true);
        }

        function toggleAccessibilityPreference(key) {
            if(!(key in accessibilityPrefs)||key==='fontScale')return;
            accessibilityPrefs[key]=!accessibilityPrefs[key];
            saveAccessibilityPreferences();
            applyAccessibilityPreferences(true);
        }

        function resetAccessibilityPreferences() {
            accessibilityPrefs={
                fontScale:1,
                highContrast:false,
                grayscale:false,
                underlineLinks:false,
                readableFont:false,
                reduceMotion:false
            };
            try{localStorage.removeItem(ACCESSIBILITY_PREFS_KEY);}catch(_){}
            applyAccessibilityPreferences(true);
        }

        function toggleAccessibilityPanel(force=null) {
            const panel=$('accessibility-panel'),toggle=$('accessibility-toggle');
            if(!panel||!toggle)return;
            const open=force===null?panel.classList.contains('hidden'):!!force;
            if(open){
                lastFocusedBeforeAccessibility=document.activeElement;
                panel.classList.remove('hidden');
                toggle.setAttribute('aria-expanded','true');
                toggle.setAttribute('aria-label','סגור הגדרות נגישות');
                const first=focusableElements(panel)[0];
                window.setTimeout(()=>first?.focus(),20);
                announceA11y('נפתח תפריט נגישות');
            }else{
                panel.classList.add('hidden');
                toggle.setAttribute('aria-expanded','false');
                toggle.setAttribute('aria-label','פתח הגדרות נגישות');
                if(lastFocusedBeforeAccessibility instanceof HTMLElement)lastFocusedBeforeAccessibility.focus();
            }
        }

        function announceA11y(message, urgent=false) {
            const region=$(urgent?'a11y-alert-region':'a11y-live-region');
            if(!region)return;
            region.textContent='';
            window.setTimeout(()=>{region.textContent=String(message||'');},20);
        }

        function focusableElements(container) {
            if(!container)return[];
            return [...container.querySelectorAll(
                'a[href],button:not([disabled]),input:not([disabled]):not([type="hidden"]),select:not([disabled]),textarea:not([disabled]),summary,[tabindex]:not([tabindex="-1"])'
            )].filter(el=>!el.hidden&&el.offsetParent!==null&&!el.closest('[aria-hidden="true"]'));
        }

        function setDialogBackgroundInert(dialog,on) {
            document.querySelectorAll('header, footer, main > *').forEach(el=>{
                if(el===dialog)return;
                if(on){
                    if(!el.hasAttribute('data-a11y-was-inert')) el.setAttribute('data-a11y-was-inert',el.inert?'1':'0');
                    el.inert=true;
                }else if(el.hasAttribute('data-a11y-was-inert')){
                    el.inert=el.getAttribute('data-a11y-was-inert')==='1';
                    el.removeAttribute('data-a11y-was-inert');
                }
            });
        }

        function trapFocusInDialog(event,dialog,onEscape) {
            if(!dialog||dialog.classList.contains('hidden'))return;
            if(event.key==='Escape'){
                event.preventDefault();
                onEscape?.();
                return;
            }
            if(event.key!=='Tab')return;
            const items=focusableElements(dialog);
            if(!items.length){event.preventDefault();dialog.focus?.();return;}
            const first=items[0],last=items[items.length-1];
            if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}
            else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
        }

        function fieldAccessibleName(el) {
            if(el.getAttribute('aria-label')||el.getAttribute('aria-labelledby'))return true;
            if(el.id&&document.querySelector('label[for="'+CSS.escape(el.id)+'"]'))return true;
            if(el.closest('label'))return true;
            return false;
        }

        function enhanceAccessibility(root=document) {
            const scope=root?.querySelectorAll?root:document;

            scope.querySelectorAll?.('i.fa-solid,i.fa-regular,i.fa-brands').forEach(icon=>{
                icon.setAttribute('aria-hidden','true');
                icon.setAttribute('focusable','false');
            });

            scope.querySelectorAll?.('input,select,textarea').forEach(el=>{
                if(el.type==='hidden')return;
                if(el.required)el.setAttribute('aria-required','true');
                if(!el.hasAttribute('aria-invalid'))el.setAttribute('aria-invalid','false');
                if(!fieldAccessibleName(el)){
                    const named={
                        'admin-logo-file':'בחירת קובץ לוגו',
                        'admin-hero-file':'בחירת קובץ תמונת דף הבית'
                    };
                    const label=named[el.id]||el.getAttribute('placeholder')||el.getAttribute('name')||'שדה';
                    el.setAttribute('aria-label',label);
                }
                const label=el.closest('label');
                const help=label?.querySelector('.field-help');
                if(help){
                    if(!help.id)help.id='help-'+(el.id||Math.random().toString(36).slice(2));
                    const prev=(el.getAttribute('aria-describedby')||'').split(/\s+/).filter(Boolean);
                    if(!prev.includes(help.id))el.setAttribute('aria-describedby',[...prev,help.id].join(' '));
                }
            });

            scope.querySelectorAll?.('.choice-grid').forEach((group,index)=>{
                if(group.hasAttribute('role'))return;
                const parent=group.parentElement;
                const heading=parent?.querySelector(':scope > .field-label');
                if(heading){
                    if(!heading.id)heading.id='choice-heading-'+index+'-'+Math.random().toString(36).slice(2,7);
                    group.setAttribute('role','group');
                    group.setAttribute('aria-labelledby',heading.id);
                }
            });

            scope.querySelectorAll?.('button').forEach(btn=>{
                if(!btn.hasAttribute('type')){
                    const insideForm=!!btn.closest('form');
                    btn.type=(insideForm&&!btn.hasAttribute('onclick'))?'submit':'button';
                }
                if(btn.getAttribute('aria-label')||btn.textContent.trim())return;
                const icon=btn.querySelector('i');
                const cls=icon?.className||'';
                const map=[
                    ['fa-flag','דווח על אירוע'],['fa-xmark','סגור'],['fa-gear','הגדרות'],
                    ['fa-trash','מחק'],['fa-pen','ערוך'],['fa-edit','ערוך'],['fa-chevron','פתח או סגור']
                ];
                const found=map.find(([key])=>cls.includes(key));
                btn.setAttribute('aria-label',found?.[1]||'פעולה');
            });

            scope.querySelectorAll?.('a[target="_blank"]').forEach(a=>{
                if(!a.getAttribute('aria-label')){
                    const text=a.textContent.trim()||'קישור';
                    a.setAttribute('aria-label',text+' — נפתח בחלון חדש');
                }
            });

            scope.querySelectorAll?.('table').forEach(table=>{
                if(table.getAttribute('aria-label')||table.getAttribute('aria-labelledby'))return;
                const heading=table.closest('section,div')?.querySelector('h2,h3,h4');
                if(heading){
                    if(!heading.id)heading.id='table-heading-'+Math.random().toString(36).slice(2,7);
                    table.setAttribute('aria-labelledby',heading.id);
                }
            });
            scope.querySelectorAll?.('th').forEach(th=>{if(!th.hasAttribute('scope'))th.setAttribute('scope','col');});

            scope.querySelectorAll?.('.route-map').forEach(map=>{
                map.setAttribute('role','region');
                if(!map.getAttribute('aria-label'))map.setAttribute('aria-label','מפת מסלול בין מקום המגורים לאולם האירוע');
                map.setAttribute('tabindex','0');
            });
        }

        function initAccessibility() {
            if(accessibilityInitialized){
                enhanceAccessibility(document);
                return;
            }
            accessibilityInitialized=true;
            document.querySelectorAll('.screen').forEach(el=>el.setAttribute('aria-hidden',el.classList.contains('active')?'false':'true'));
            enhanceAccessibility(document);

            document.addEventListener('invalid',event=>{
                const el=event.target;
                if(!(el instanceof HTMLElement))return;
                el.setAttribute('aria-invalid','true');
                const name=el.getAttribute('aria-label')||el.closest('label')?.innerText?.trim()||el.getAttribute('placeholder')||'שדה';
                announceA11y('יש לתקן את השדה: '+name,true);
            },true);
            document.addEventListener('input',event=>{
                const el=event.target;
                if(el instanceof HTMLElement&&el.matches('input,select,textarea'))el.setAttribute('aria-invalid','false');
            },true);
            document.addEventListener('change',event=>{
                const el=event.target;
                if(el instanceof HTMLElement&&el.matches('input,select,textarea'))el.setAttribute('aria-invalid','false');
            },true);

            document.addEventListener('keydown',event=>{
                const chat=$('chat-modal'),app=$('app-modal'),a11y=$('accessibility-panel');
                if(chat&&!chat.classList.contains('hidden'))return trapFocusInDialog(event,chat,closeEventChat);
                if(app&&!app.classList.contains('hidden'))return trapFocusInDialog(event,app,()=>resolveAppModal(false));
                if(event.key==='Escape'&&a11y&&!a11y.classList.contains('hidden')){
                    event.preventDefault();
                    toggleAccessibilityPanel(false);
                }
            });

            const observer=new MutationObserver(records=>{
                records.forEach(record=>record.addedNodes.forEach(node=>{
                    if(node.nodeType===1)enhanceAccessibility(node);
                }));
            });
            observer.observe(document.body,{childList:true,subtree:true});
        }

        function navigate(view) {
            clearGuestFormWhenLeaving(view);
            document.querySelectorAll('.screen').forEach(el=>{
                el.classList.remove('active');
                el.setAttribute('aria-hidden','true');
            });
            const target=$('view-'+view);
            if(target){
                target.classList.add('active');
                target.setAttribute('aria-hidden','false');
                enhanceAccessibility(target);
                const heading=target.querySelector('h1,h2');
                const focusTarget=heading||target;
                if(!focusTarget.hasAttribute('tabindex'))focusTarget.setAttribute('tabindex','-1');
                window.scrollTo({top:0,left:0,behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'auto'});
                window.setTimeout(()=>focusTarget.focus({preventScroll:true}),30);
                document.title=(heading?.textContent?.trim()?heading.textContent.trim()+' | ':'')+'שמחים בשמחתם';
                announceA11y('נפתח: '+(heading?.textContent?.trim()||'דף הבית'));
            }
        }

        function setBusy(buttonId,busy,busyText='טוען...') {
            const btn=$(buttonId);
            if(!btn)return;
            btn.setAttribute('aria-busy',busy?'true':'false');
            if(busy){
                btn.dataset.oldText=btn.innerHTML;
                btn.disabled=true;
                btn.textContent=busyText;
                announceA11y(busyText);
            }else{
                btn.disabled=false;
                if(btn.dataset.oldText)btn.innerHTML=btn.dataset.oldText;
            }
        }

        function showToast(message,type='info') {
            const box=$('toast-container');if(!box)return;
            const el=document.createElement('div');
            const accent=type==='error'?'border-red-200 text-red-700':type==='success'?'border-emerald-200 text-emerald-800':type==='warning'?'border-amber-200 text-amber-800':'border-slate-200 text-slate-700';
            el.className='toast-card '+accent;
            el.textContent=message;
            el.setAttribute('role',type==='error'?'alert':'status');
            el.setAttribute('aria-live',type==='error'?'assertive':'polite');
            box.appendChild(el);
            announceA11y(message,type==='error');
            setTimeout(()=>{el.style.opacity='0';el.style.transform='translateY(-4px)';el.style.transition='.25s';},4200);
            setTimeout(()=>el.remove(),4550);
        }
        function openAppModal({title,message='',confirmText='אישור',cancelText='ביטול',input=false,placeholder='',inputMode='text',autocomplete='off',maxLength=0,pattern=''}) {
            return new Promise(resolve=>{
                modalResolver=resolve;
                lastFocusedBeforeAppModal=document.activeElement instanceof HTMLElement?document.activeElement:null;
                $('modal-title').textContent=title;
                $('modal-message').textContent=message;
                $('modal-confirm').textContent=confirmText;
                $('modal-cancel').textContent=cancelText;
                const inp=$('modal-input');
                inp.classList.toggle('hidden',!input);
                inp.value='';
                inp.placeholder=placeholder;
                inp.inputMode=inputMode||'text';
                inp.autocomplete=autocomplete||'off';
                if(maxLength>0) inp.maxLength=maxLength; else inp.removeAttribute('maxlength');
                if(pattern) inp.setAttribute('pattern',pattern); else inp.removeAttribute('pattern');
                inp.setAttribute('enterkeyhint','done');
                $('modal-input-label').textContent=placeholder||title||'הקלדת תשובה';
                const modal=$('app-modal');
                modal.classList.remove('hidden');
                modal.classList.add('flex');
                setDialogBackgroundInert(modal,true);
                window.setTimeout(()=>{(input?inp:$('modal-confirm')).focus();},50);
            });
        }
        function resolveAppModal(ok) {
            const modal=$('app-modal');
            const inputVisible=!$('modal-input').classList.contains('hidden');
            const value=inputVisible?$('modal-input').value.trim():true;
            modal.classList.add('hidden');modal.classList.remove('flex');
            setDialogBackgroundInert(modal,false);
            const restore=lastFocusedBeforeAppModal;lastFocusedBeforeAppModal=null;
            if(modalResolver){const r=modalResolver;modalResolver=null;r(ok?value:null);}
            window.setTimeout(()=>restore?.focus?.(),30);
        }
        const askConfirm=(title,message,confirmText='אישור')=>openAppModal({title,message,confirmText});
        const askText=(title,message,placeholder='')=>openAppModal({title,message,confirmText:'שלח',input:true,placeholder});
        function roleLabel(role){return ({volunteer:'משמח/ת',host:'בעל/ת שמחה',both:'משמח/ת + בעל/ת שמחה'})[role]||'משתמש';}
        function displayPhone(phone){const p=String(phone||'');return p.startsWith('+972')?'0'+p.slice(4):p;}
        function isValidPhone(phone){return /^\+972\d{8,9}$/.test(normalizePhone(phone));}
        function dayName(dateStr){if(!dateStr)return'';return new Intl.DateTimeFormat('he-IL',{weekday:'long'}).format(new Date(dateStr+'T12:00:00'));}
        function isFridayOrSaturday(dateStr){if(!dateStr)return false;const d=new Date(dateStr+'T12:00:00').getDay();return d===5||d===6;}
        function guardEventDateInput(input){if(!input||!input.value||!isFridayOrSaturday(input.value))return true;input.value='';showToast('לא ניתן לפרסם אירוע ביום שישי או בשבת.','warning');return false;}
        function relativeDateLabel(dateStr){if(!dateStr)return'';const today=new Date();today.setHours(12,0,0,0);const d=new Date(dateStr+'T12:00:00');const days=Math.round((d-today)/86400000);if(days===0)return'היום';if(days===1)return'מחר';if(days>1&&days<=7)return'בעוד '+days+' ימים';if(days<0)return'הסתיים';return dayName(dateStr);}
        function timeRange(start,close){return [start?.slice(0,5),close?.slice(0,5)].filter(Boolean).join('–');}
        function mapButtons(address){if(!address)return'';const q=encodeURIComponent(address);return '<div class="flex flex-wrap gap-2 mt-2"><a target="_blank" rel="noopener" href="https://waze.com/ul?q='+q+'&navigate=yes" class="btn-soft px-3 py-1.5 text-xs"><i class="fa-brands fa-waze ml-1"></i> Waze</a><a target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query='+q+'" class="btn-soft px-3 py-1.5 text-xs"><i class="fa-solid fa-map-location-dot ml-1"></i> Google Maps</a></div>';}
        function icsEscape(v){return String(v||'').replace(/\\/g,'\\\\').replace(/;/g,'\\;').replace(/,/g,'\\,').replace(/\n/g,'\\n');}
        function downloadCalendar(eventId){const e=calendarEventCache.get(eventId);if(!e)return showToast('לא מצאתי את פרטי האירוע ליומן.','error');const d=String(e.event_date||'').replaceAll('-','');const start=String(e.start_time||'00:00').slice(0,5).replace(':','')+'00';const end=String(e.close_time||e.start_time||'00:00').slice(0,5).replace(':','')+'00';const ics=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Smachim//HE','BEGIN:VEVENT','UID:'+eventId+'@smachim','DTSTART;TZID=Asia/Jerusalem:'+d+'T'+start,'DTEND;TZID=Asia/Jerusalem:'+d+'T'+end,'SUMMARY:'+icsEscape('שמחים בשמחתם - '+(e.event_name||e.couple_names||'אירוע')),'LOCATION:'+icsEscape(e.exact_address||e.public_location||''),'DESCRIPTION:'+icsEscape('אירוע דרך שמחים בשמחתם'),'END:VEVENT','END:VCALENDAR'].join('\r\n');const blob=new Blob([ics],{type:'text/calendar;charset=utf-8'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='event.ics';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
        function updateHeaderActions(){const box=$('header-actions');if(!box)return;if(sessionToken&&currentProfile&&currentIsAdmin&&adminMode){box.innerHTML='<div class="flex gap-4 items-center"><button onclick="navigate(\'home\')" class="header-home-action text-sm font-semibold text-slate-500 hover:text-brand-600"><i class="fa-solid fa-house ml-1"></i> דף הבית</button><button onclick="loadAdminArea()" class="text-sm font-bold text-brand-700 hover:text-brand-900"><i class="fa-solid fa-shield-halved ml-1"></i> ניהול</button></div>';enhanceAccessibility(box);return;}box.innerHTML=sessionToken&&currentProfile?'<div class="flex gap-4 items-center"><button onclick="navigate(\'home\')" class="header-home-action text-sm font-semibold text-slate-500 hover:text-brand-600"><i class="fa-solid fa-house ml-1"></i> דף הבית</button><button onclick="loadDashboard()" class="text-sm font-bold text-brand-700 hover:text-brand-900"><i class="fa-solid fa-user ml-1"></i> אזור אישי</button></div>':'<button onclick="navigate(\'home\')" class="header-home-action text-sm font-semibold text-slate-500 hover:text-brand-600 transition"><i class="fa-solid fa-house ml-1"></i> דף הבית</button>';enhanceAccessibility(box);}

        async function callPublicEdge(name,payload){
            const res=await fetch(SUPABASE_URL+'/functions/v1/'+name,{
                method:'POST',
                headers:{'Content-Type':'application/json','apikey':SUPABASE_PUBLISHABLE_KEY},
                body:JSON.stringify(payload||{})
            });
            const data=await res.json().catch(()=>({}));
            if(!res.ok||data?.ok===false){
                const e=new Error(data?.error||('edge_http_'+res.status));
                e.status=res.status;
                throw e;
            }
            return data;
        }

        async function ensurePhoneVerification(phone,purpose){
            await callPublicEdge('phone-auth',{action:'request',phone,purpose});
            showToast('שלחנו קוד אימות ב-SMS.','success');
            for(let attempt=0;attempt<5;attempt++){
                const code=await openAppModal({
                    title:'אימות מספר טלפון',
                    message:'הקלד/י את הקוד בן 6 הספרות שנשלח ב-SMS.',
                    confirmText:'אימות',
                    input:true,
                    placeholder:'123456',
                    inputMode:'numeric',
                    autocomplete:'one-time-code',
                    maxLength:6,
                    pattern:'[0-9]*'
                });
                if(code===null) throw new Error('verification_cancelled');
                try{
                    const result=await callPublicEdge('phone-auth',{action:'verify',phone,purpose,code:String(code).trim()});
                    if(result?.token)return result.token;
                    throw new Error('verification_invalid_code');
                }catch(e){
                    const m=String(e?.message||'');
                    if(m.includes('verification_invalid_code')&&attempt<4){
                        showToast('הקוד אינו נכון. נסה/י שוב.','error');
                        continue;
                    }
                    throw e;
                }
            }
            throw new Error('verification_too_many_attempts');
        }

        async function verifyTypedAddress(city,street,number){
            const result=await callPublicEdge('address-verify',{city,street,number});
            if(!result?.ok||!Number.isFinite(Number(result.lat))||!Number.isFinite(Number(result.lng))) throw new Error('address_not_found');
            return {lat:Number(result.lat),lng:Number(result.lng),formatted_address:result.formatted_address||'',provider:result.provider||''};
        }

        function showLegalSummary(kind){
            if(kind==='privacy'){
                return openAppModal({title:'מדיניות פרטיות',message:'אנחנו שומרים את הפרטים הנדרשים להפעלת החשבון ולהתאמת אירועים: טלפון, פרטי פרופיל, כתובת לצורך חישוב מרחק ופעילות במערכת. כתובת המגורים אינה מוצגת לבעלי אירועים. ניתן למחוק חשבון מההגדרות.',confirmText:'הבנתי',cancelText:'סגור'});
            }
            return openAppModal({title:'תנאי שימוש',message:'יש למסור פרטים נכונים, להשתמש בשירות למטרת המיזם בלבד ולעדכן ביטול או שינוי בזמן. המערכת מסייעת בהתאמה אך אינה יכולה להבטיח הגעה בפועל.',confirmText:'הבנתי',cancelText:'סגור'});
        }

        async function handlePasswordReset(){
            setBusy('reset-password-submit',true,'שולח קוד...');
            try{
                const phone=normalizePhone($('reset-phone').value);
                const password=$('reset-password').value;
                const confirm=$('reset-password-confirm').value;
                if(!isValidPhone(phone))throw new Error('invalid_phone');
                if(password.length<8)throw new Error('invalid_password');
                if(password!==confirm)throw new Error('הסיסמאות אינן זהות.');
                const verificationToken=await ensurePhoneVerification(phone,'reset_password');
                const {error}=await _supabase.rpc('reset_password_with_verification',{
                    p_phone:phone,p_verification_token:verificationToken,p_new_password:password
                });
                if(error)throw error;
                $('reset-password-form')?.reset();
                showToast('הסיסמה עודכנה. אפשר להתחבר.','success');
                navigate('login');
            }catch(e){showToast(readableError(e),'error');}
            finally{setBusy('reset-password-submit',false);}
        }

        async function deleteMyAccount(){
            const ok=await askConfirm('מחיקת חשבון','המחיקה היא פעולה בלתי הפיכה. אם יש לך אירועים עתידיים שפרסמת, יש לבטל אותם קודם.','המשך למחיקה');
            if(!ok)return;
            const typed=await askText('אישור אחרון','כדי לאשר, יש להקליד את המילה: מחיקה','מחיקה');
            if(typed!=='מחיקה')return showToast('החשבון לא נמחק.','warning');
            const {error}=await _supabase.rpc('delete_my_account');
            if(error)return showToast(readableError(error),'error');
            applySessionToken('');
            clearAllPersonalBrowserStorage();
            clearRuntimeUserData();
            updateHeaderActions();
            navigate('home');
            showToast('החשבון נמחק.','success');
        }

        function normalizePhone(phone) {
            const raw = String(phone || '').replace(/[\s\-()]/g, '');
            if (!raw) return '';
            if (raw.startsWith('+')) return raw;
            if (raw.startsWith('972')) return '+' + raw;
            if (raw.startsWith('0')) return '+972' + raw.slice(1);
            return raw;
        }


        function siteText(key,fallback=''){
            const v=publicSiteConfig?.content?.[key];
            return typeof v==='string'&&v.trim()?v:fallback;
        }

        function configuredItems(key,fallback=[]){
            const v=publicSiteConfig?.field_config?.[key];
            return Array.isArray(v)&&v.length?v:fallback;
        }

        function configuredEventTypes(){
            return configuredItems('event_types',[
                {value:'wedding',label:'חתונה',enabled:true},
                {value:'engagement',label:'אירוסין',enabled:true},
                {value:'bar_mitzvah',label:'בר מצווה',enabled:true},
                {value:'bat_mitzvah',label:'בת מצווה',enabled:true}
            ]);
        }

        function configuredSectors(){
            return configuredItems('sectors',[
                {value:'haredi',label:'חרדי',enabled:true},
                {value:'religious',label:'דתי לאומי',enabled:true},
                {value:'traditional',label:'מסורתי',enabled:true},
                {value:'secular',label:'חילוני',enabled:true}
            ]);
        }

        function configuredAgeRanges(){
            return configuredItems('age_ranges',[
                {value:'all',label:'ללא הגבלת גיל',min:null,max:null,enabled:true,minor_only:false},
                {value:'12-18',label:'12–18',min:12,max:18,enabled:true,minor_only:true},
                {value:'18-25',label:'18–25',min:18,max:25,enabled:true,minor_only:false},
                {value:'26-35',label:'26–35',min:26,max:35,enabled:true,minor_only:false},
                {value:'36-50',label:'36–50',min:36,max:50,enabled:true,minor_only:false},
                {value:'51-65',label:'51–65',min:51,max:65,enabled:true,minor_only:false},
                {value:'66+',label:'66 ומעלה',min:66,max:null,enabled:true,minor_only:false}
            ]);
        }

        function configuredRadiusOptions(){
            return configuredItems('radius_options',[
                {value:10,label:'עד 10 ק״מ',enabled:true},{value:20,label:'עד 20 ק״מ',enabled:true},
                {value:50,label:'עד 50 ק״מ',enabled:true},{value:100,label:'עד 100 ק״מ',enabled:true},
                {value:999,label:'כל הארץ',enabled:true}
            ]);
        }

        function rebuildSelect(id,items,{includeAll=false,allLabel='כל המגזרים',placeholder='',keep=true}={}){
            const el=$(id);if(!el)return;
            const current=keep?String(el.value||''):'';
            const rows=(items||[]).filter(x=>x.enabled!==false);
            el.innerHTML=(placeholder?'<option value="" disabled>'+esc(placeholder)+'</option>':'')+
                (includeAll?'<option value="all">'+esc(allLabel)+'</option>':'')+
                rows.map(x=>'<option value="'+esc(x.value)+'">'+esc(x.label)+'</option>').join('');
            if(current&&[...el.options].some(o=>o.value===current))el.value=current;
            else if(placeholder)el.value='';
        }

        function updateChoiceLabels(name,items){
            const map=new Map((items||[]).map(x=>[String(x.value),x]));
            document.querySelectorAll('input[name="'+name+'"]').forEach(input=>{
                if(input.value==='all')return;
                const item=map.get(String(input.value));
                const label=input.closest('label');
                if(!label)return;
                if(!item){label.classList.add('hidden');input.disabled=true;return;}
                label.classList.toggle('hidden',item.enabled===false);
                input.disabled=item.enabled===false;
                const textNodes=[...label.childNodes].filter(n=>n.nodeType===Node.TEXT_NODE);
                if(textNodes.length)textNodes[textNodes.length-1].textContent=' '+item.label;
            });
        }

        function applyFieldConfig(){
            const eventTypes=configuredEventTypes();
            const sectors=configuredSectors();
            const ages=configuredAgeRanges();
            const radii=configuredRadiusOptions();
            const defaultLabels={
                vol_name:'שם מלא',vol_phone:'מספר טלפון — שם המשתמש',vol_gender:'איך לפנות אליך?',
                vol_birth_year:'שנת לידה',vol_sector:'המגזר שאני משתייך אליו',vol_address:'כתובת מגורים',
                event_name:'שם האירוע',event_type:'סוג האירוע',event_date:'תאריך האירוע',
                event_start:'שעת התחלה',event_end:'שעת סיום',event_deadline:'עד מתי אפשר להירשם?',
                event_venue:'האולם',event_age_range:'טווח גילאים למשמחים',
                host_name:'שם בעל השמחה',host_phone:'טלפון — שם המשתמש',host_password:'סיסמה',host_password_confirm:'אימות סיסמה',
                family_name:'שם הילד/ה',family_gender:'איך לפנות?',family_birth_year:'שנת לידה',family_sector:'מגזר'
            };
            const labels={...defaultLabels,...(publicSiteConfig?.field_config?.labels||{})};
            document.querySelectorAll('[data-field-label]').forEach(el=>{
                const key=el.getAttribute('data-field-label');
                if(labels[key])el.textContent=labels[key];
            });

            rebuildSelect('ev-type',eventTypes);
            rebuildSelect('edit-ev-type',eventTypes);
            rebuildSelect('vol-sector',sectors,{placeholder:'בחר'});
            rebuildSelect('profile-sector',sectors);
            rebuildSelect('family-child-sector',sectors,{placeholder:'בחר'});
            ['ev-sector','edit-ev-sector'].forEach(id=>rebuildSelect(id,sectors,{includeAll:true}));
            ['vol-radius','profile-radius','family-child-radius'].forEach(id=>rebuildSelect(id,radii));

            updateChoiceLabels('vol-event-type-pref',eventTypes);
            updateChoiceLabels('profile-event-type-pref',eventTypes);
            updateChoiceLabels('family-event-type',eventTypes.filter(x=>['bar_mitzvah','bat_mitzvah'].includes(x.value)));
            updateChoiceLabels('vol-sector-pref',sectors);
            updateChoiceLabels('profile-sector-pref',sectors);
            updateChoiceLabels('ev-accepted-sector',sectors);
            updateChoiceLabels('edit-ev-accepted-sector',sectors);

            for(const id of ['ev-age-range','edit-ev-age-range']){
                const el=$(id);if(!el)continue;
                const current=el.value||'all';
                el.innerHTML=ages.filter(x=>x.enabled!==false).map(x=>'<option value="'+esc(x.value)+'" '+(x.minor_only?'data-minor-age':'')+'>'+esc(x.label)+'</option>').join('');
                if([...el.options].some(o=>o.value===current))el.value=current;
            }

            const defaultType=publicSiteConfig?.field_config?.volunteer_event_default||'wedding';
            if(!sessionToken){
                setCheckedValues('vol-event-type-pref',[defaultType]);
            }
            syncEventAgeRangeOptions('');
            syncEventAgeRangeOptions('edit-');
        }

        function applyTextOverridesToNode(root){
            const overrides=publicSiteConfig?.text_overrides||{};
            if(!root||!Object.keys(overrides).length)return;
            const isInsideAdmin=node=>{
                const el=node?.nodeType===Node.ELEMENT_NODE?node:node?.parentElement;
                return !!el?.closest?.('#view-admin');
            };
            const applyTextNode=node=>{
                if(isInsideAdmin(node))return;
                const raw=node.nodeValue||'';
                const trimmed=raw.trim();
                if(!trimmed)return;
                const replacement=overrides[trimmed];
                if(typeof replacement!=='string'||replacement===trimmed)return;
                const start=raw.indexOf(trimmed);
                if(start>=0)node.nodeValue=raw.slice(0,start)+replacement+raw.slice(start+trimmed.length);
            };
            if(root.nodeType===Node.TEXT_NODE){
                applyTextNode(root);
                return;
            }
            if(root.nodeType!==Node.ELEMENT_NODE&&root.nodeType!==Node.DOCUMENT_FRAGMENT_NODE)return;
            if(root.nodeType===Node.ELEMENT_NODE&&isInsideAdmin(root))return;

            const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{
                acceptNode(node){
                    const p=node.parentElement;
                    if(!p||p.closest('#view-admin')||['SCRIPT','STYLE','NOSCRIPT'].includes(p.tagName))return NodeFilter.FILTER_REJECT;
                    return NodeFilter.FILTER_ACCEPT;
                }
            });
            let n;
            while((n=walker.nextNode()))applyTextNode(n);

            const nodes=[];
            if(root.nodeType===Node.ELEMENT_NODE)nodes.push(root);
            if(root.querySelectorAll)nodes.push(...root.querySelectorAll('[placeholder],[title],[aria-label],[alt]'));
            for(const el of nodes){
                if(el.closest?.('#view-admin'))continue;
                for(const attr of ['placeholder','title','aria-label','alt']){
                    if(!el.hasAttribute?.(attr))continue;
                    const value=el.getAttribute(attr)||'';
                    const replacement=overrides[value.trim()];
                    if(typeof replacement==='string'&&replacement!==value.trim())el.setAttribute(attr,replacement);
                }
            }
        }

        function scheduleTextOverrideApply(){
            if(textOverrideScheduled)return;
            textOverrideScheduled=true;
            requestAnimationFrame(()=>{
                textOverrideScheduled=false;
                applyTextOverridesToNode(document.body);
            });
        }

        function ensureTextOverrideObserver(){
            if(textOverrideObserver||!document.body)return;
            textOverrideObserver=new MutationObserver(mutations=>{
                if(!publicSiteConfig?.text_overrides)return;
                if(mutations.some(m=>m.addedNodes?.length))scheduleTextOverrideApply();
            });
            textOverrideObserver.observe(document.body,{childList:true,subtree:true});
        }

        function applyPublicSiteConfig(){
            const logo=$('site-logo-img'),hero=$('home-hero-img');
            const versionedAsset=(url,fallback)=>{
                const value=url||fallback;
                if(value.startsWith('./assets/')){
                    const base=value.split('?')[0];
                    return base+'?v=20260914-mobilefix3';
                }
                return value;
            };
            if(logo){
                logo.dataset.fallback='';
                logo.src=versionedAsset(publicSiteConfig?.logo_url,'./assets/site-title.jpg');
            }
            if(hero){
                hero.dataset.fallback='';
                hero.src=versionedAsset(publicSiteConfig?.hero_url,'./assets/hero-banner.jpg');
            }
            document.querySelectorAll('[data-site-text]').forEach(el=>{
                const key=el.getAttribute('data-site-text');
                const v=publicSiteConfig?.content?.[key];
                if(typeof v==='string'&&v.trim())el.textContent=v;
            });
            applyFieldConfig();
            applyTextOverridesToNode(document.body);
            ensureTextOverrideObserver();
        }

        async function loadPublicSiteConfig(){
            try{
                const {data,error}=await _supabase.rpc('public_site_config');
                if(!error&&data){
                    publicSiteConfig=data;
                    applyPublicSiteConfig();
                }
            }catch(e){console.warn('public site config unavailable',e);}
        }

        function formatDate(dateStr) {
            if (!dateStr) return '';
            const d = new Date(dateStr + 'T12:00:00');
            return new Intl.DateTimeFormat('he-IL', { day:'2-digit', month:'2-digit', year:'numeric' }).format(d);
        }

        function sectorLabel(v) {
            if(v==='all')return 'כל המגזרים';
            return configuredSectors().find(x=>x.value===v)?.label || v || '';
        }

        function eventTypeLabel(v) {
            return configuredEventTypes().find(x=>x.value===v)?.label || 'אירוע';
        }

        function eventTypeListLabel(values) {
            const a=values||[];
            if(a.includes('all')) return 'כל סוגי האירועים';
            return a.map(eventTypeLabel).join(', ')||'לא הוגדר';
        }

        function ageRangeBounds(value) {
            const v=String(value||'all');
            const row=configuredAgeRanges().find(x=>String(x.value)===v);
            return row?{min:row.min==null?null:Number(row.min),max:row.max==null?null:Number(row.max)}:{min:null,max:null};
        }

        function ageRangeValue(min,max) {
            const a=min==null?null:Number(min),b=max==null?null:Number(max);
            return configuredAgeRanges().find(x=>(x.min==null?null:Number(x.min))===a&&(x.max==null?null:Number(x.max))===b)?.value||'all';
        }


        function syncEventAgeRangeOptions(prefix='') {
            const type=$(prefix+'ev-type')?.value||'';
            const select=$(prefix+'ev-age-range');
            if(!select) return;
            const minor=select.querySelector('option[value="12-18"]');
            const allowed=type==='bar_mitzvah'||type==='bat_mitzvah';
            if(minor){minor.hidden=!allowed;minor.disabled=!allowed;}
            if(!allowed&&select.value==='12-18') select.value='all';
        }

        function syncVolunteerGuardianMode() {
            const now=new Date().getFullYear();
            const birth=$('vol-birth-year');
            if(!birth)return;
            [...birth.options].forEach(o=>{
                if(!o.value)return;
                const age=now-Number(o.value);
                const allowed=age>=18;
                o.disabled=!allowed;
                o.hidden=!allowed;
            });
            if(birth.value&&now-Number(birth.value)<18) birth.value='';
        }

        function populateFamilyBirthYears(){
            const now=new Date().getFullYear();
            document.querySelectorAll('.family-birth-year-select').forEach(sel=>{
                if(sel.options.length>2)return;
                for(let age=12;age<=17;age++){
                    const y=now-age;
                    const o=document.createElement('option');o.value=String(y);o.textContent=String(y);sel.appendChild(o);
                }
            });
        }

        function checkedValues(name) {
            return [...document.querySelectorAll('input[name="'+name+'"]:checked')].map(x=>x.value);
        }

        function checkedNumbers(name) {
            return checkedValues(name).map(Number).filter(Number.isFinite);
        }

        function setCheckedValues(name, values=[]) {
            const set=new Set((values||[]).map(String));
            document.querySelectorAll('input[name="'+name+'"]').forEach(x=>x.checked=set.has(String(x.value)));
        }

        function bindAllChoice(name) {
            document.querySelectorAll('input[name="'+name+'"]').forEach(input=>{
                input.addEventListener('change',()=>{
                    const all=document.querySelector('input[name="'+name+'"][value="all"]');
                    if(input.value==='all' && input.checked) {
                        document.querySelectorAll('input[name="'+name+'"]').forEach(x=>{ if(x.value!=='all') x.checked=false; });
                    } else if(input.value!=='all' && input.checked && all) {
                        all.checked=false;
                    }
                    if(!checkedValues(name).length && all) all.checked=true;
                });
            });
        }

        function populateBirthYears() {
            const now=new Date().getFullYear();
            document.querySelectorAll('.birth-year-select').forEach(sel=>{
                if(sel.options.length>2) return;
                for(let y=now;y>=1930;y--){
                    const o=document.createElement('option');o.value=String(y);o.textContent=String(y);sel.appendChild(o);
                }
            });
        }

        function fullAddress(city,street,number='') {
            return [street,number,city].map(x=>String(x||'').trim()).filter(Boolean).join(' ');
        }

        function toDateTimeLocal(value) {
            if(!value) return '';
            const s=String(value).replace(' ','T');
            return s.slice(0,16);
        }

        function debounce(fn,wait=300) {
            let t; return (...args)=>{clearTimeout(t);t=setTimeout(()=>fn(...args),wait);};
        }

        const GOV_CITIES_RESOURCE='5c78e9fa-c2e2-4771-93ff-7f400a12f7ba';
        const GOV_STREETS_RESOURCE='9ad3862c-8391-4b2f-84a4-2d4c68625f4b';

        async function fetchGovAddressRecords(resourceId,{limit=5000,filters=null}={}){
            const controller=new AbortController();
            const timeout=setTimeout(()=>controller.abort(),6000);
            try{
                const params=new URLSearchParams({resource_id:resourceId,limit:String(limit)});
                if(filters)params.set('filters',JSON.stringify(filters));
                const res=await fetch('https://data.gov.il/api/3/action/datastore_search?'+params.toString(),{
                    signal:controller.signal,
                    headers:{'Accept':'application/json'}
                });
                if(!res.ok)throw new Error('gov_address_http_'+res.status);
                const json=await res.json();
                if(!json?.success||!Array.isArray(json?.result?.records))throw new Error('gov_address_bad_response');
                return json.result.records;
            }finally{clearTimeout(timeout);}
        }

        async function fetchAllLookupRows(table,column,filterColumn=null,filterValue=null){
            const pageSize=1000;
            const out=[];
            for(let from=0;;from+=pageSize){
                let q=_supabase.from(table).select(column).order(column,{ascending:true}).range(from,from+pageSize-1);
                if(filterColumn)q=q.eq(filterColumn,filterValue);
                const {data,error}=await q;
                if(error)throw error;
                const rows=data||[];
                out.push(...rows);
                if(rows.length<pageSize)break;
            }
            return out;
        }

        async function localCityList(){
            const rows=await fetchAllLookupRows('address_cities','city');
            return [...new Set(rows.map(x=>String(x.city||'').trim()).filter(Boolean))];
        }

        async function localStreetList(city){
            const rows=await fetchAllLookupRows('address_streets','street','city',city);
            return [...new Set(rows.map(x=>String(x.street||'').trim()).filter(Boolean))];
        }

        async function edgeAddressLookup(body){
            const {data,error}=await _supabase.functions.invoke('israel-addresses',{body});
            if(error)throw error;
            if(!Array.isArray(data?.items))throw new Error('address_list_unavailable');
            return data.items;
        }

        async function loadCityList(){
            if(addressCitiesCache)return addressCitiesCache;
            if(addressListsLoading)return addressListsLoading;
            addressListsLoading=(async()=>{
                try{
                    let items=await localCityList();
                    if(items.length<1000){
                        try{items=await edgeAddressLookup({type:'cities'});}catch(e){console.warn('address edge fallback failed',e);}
                    }
                    if(!items.length)throw new Error('address_list_unavailable');
                    addressCitiesCache=[...new Set(items)].sort((a,b)=>a.localeCompare(b,'he'));
                    return addressCitiesCache;
                }finally{addressListsLoading=null;}
            })();
            return addressListsLoading;
        }

        async function loadStreetList(city){
            if(addressStreetCache.has(city))return addressStreetCache.get(city);
            let items=await localStreetList(city);
            if(!items.length){
                try{items=await edgeAddressLookup({type:'streets',city});}catch(e){console.warn('address edge street fallback failed',e);}
            }
            items=[...new Set(items)].sort((a,b)=>a.localeCompare(b,'he'));
            addressStreetCache.set(city,items);
            return items;
        }

        function manualAddressEnabled(prefix){
            const wrap=$(prefix+'-address-manual-fields');
            return !!wrap&&!wrap.classList.contains('hidden');
        }

        async function toggleManualAddress(prefix,force=null){
            const wrap=$(prefix+'-address-manual-fields');
            const cityWrap=$(prefix+'-city-select-wrap');
            const streetWrap=$(prefix+'-street-select-wrap');
            const citySel=$(prefix+'-city');
            const streetSel=$(prefix+'-street');
            const cityManual=$(prefix+'-city-manual');
            const streetManual=$(prefix+'-street-manual');
            const label=$(prefix+'-address-manual-label');
            if(!wrap||!citySel||!streetSel)return;

            const on=force===null?!manualAddressEnabled(prefix):!!force;
            if(on){
                if(cityManual&&!cityManual.value)cityManual.value=citySel.value||'';
                if(streetManual&&!streetManual.value)streetManual.value=streetSel.value||'';
                wrap.classList.remove('hidden');
                cityWrap?.classList.add('hidden');
                streetWrap?.classList.add('hidden');
                citySel.required=false;streetSel.required=false;
                citySel.disabled=true;streetSel.disabled=true;
                if(cityManual)cityManual.required=true;
                if(streetManual)streetManual.required=true;
                if(label)label.textContent='חזור לבחירה מהרשימה';
            }else{
                wrap.classList.add('hidden');
                cityWrap?.classList.remove('hidden');
                streetWrap?.classList.remove('hidden');
                citySel.required=true;citySel.disabled=false;
                streetSel.required=true;streetSel.disabled=!citySel.value;
                if(cityManual)cityManual.required=false;
                if(streetManual)streetManual.required=false;
                if(label)label.textContent='לא מצאתי עיר או רחוב — הקלדה ידנית';
            }
        }

        function getAddressParts(prefix){
            const manual=manualAddressEnabled(prefix);
            const cityEl=manual?$(prefix+'-city-manual'):$(prefix+'-city');
            const streetEl=manual?$(prefix+'-street-manual'):$(prefix+'-street');
            return {
                city:String(cityEl?.value||'').trim(),
                street:String(streetEl?.value||'').trim(),
                number:String($(prefix+'-house-number')?.value||'').trim(),
                manual
            };
        }

        function fillSelect(sel,items,placeholder,selected=''){
            if(!sel)return;
            sel.innerHTML='';
            const first=document.createElement('option');first.value='';first.textContent=placeholder;sel.appendChild(first);
            if(selected&&!items.includes(selected)){
                const legacy=document.createElement('option');
                legacy.value=selected;legacy.textContent=selected+' (ערך קיים)';legacy.selected=true;sel.appendChild(legacy);
            }
            items.forEach(v=>{
                const o=document.createElement('option');o.value=v;o.textContent=v;
                if(v===selected)o.selected=true;
                sel.appendChild(o);
            });
        }

        async function ensureCities(selectId,selected=''){
            const sel=$(selectId);if(!sel)return;
            sel.disabled=true;fillSelect(sel,[],'טוען רשימת ערים...');
            try{
                fillSelect(sel,await loadCityList(),'בחר עיר',selected);
                sel.disabled=false;
            }catch(e){
                fillSelect(sel,[],'רשימת הערים לא נטענה — רענן את הדף');
                sel.disabled=true;
                console.error('city list',e);
            }
        }

        async function loadStreets(city,selectId,selected=''){
            const sel=$(selectId);if(!sel)return;
            if(!city){fillSelect(sel,[],'בחר קודם עיר');sel.disabled=true;return;}
            sel.disabled=true;fillSelect(sel,[],'טוען את כל הרחובות...');
            try{
                const items=await loadStreetList(city);
                fillSelect(sel,items,items.length?'בחר רחוב':'לא נמצאו רחובות — אפשר להקליד ידנית',selected);
                sel.disabled=false;
            }catch(e){
                fillSelect(sel,[],'רשימת הרחובות לא נטענה — אפשר להקליד ידנית');
                sel.disabled=true;
                console.error('street list',e);
            }
        }

        function wireAddressSelect(cityId,streetId){
            const city=$(cityId);if(city)city.addEventListener('change',()=>loadStreets(city.value,streetId));
        }

        function fillDatalist(id,items){
            const list=$(id);if(!list)return;
            list.innerHTML='';
            const frag=document.createDocumentFragment();
            items.forEach(value=>{
                const opt=document.createElement('option');
                opt.value=value;
                frag.appendChild(opt);
            });
            list.appendChild(frag);
        }

        async function refreshStreetDatalist(cityInputId,listId){
            const input=$(cityInputId);
            if(!input)return;
            const city=String(input.value||'').trim();
            if(!city){fillDatalist(listId,[]);return;}
            try{
                fillDatalist(listId,await loadStreetList(city));
            }catch(e){
                console.warn('street datalist failed',e);
                fillDatalist(listId,[]);
            }
        }

        function wireAddressDatalist(cityInputId,listId){
            const input=$(cityInputId);
            if(!input)return;
            const run=debounce(()=>refreshStreetDatalist(cityInputId,listId),250);
            input.addEventListener('input',run);
            input.addEventListener('change',()=>refreshStreetDatalist(cityInputId,listId));
            input.addEventListener('blur',()=>refreshStreetDatalist(cityInputId,listId));
        }

        async function initializeAddressLists(){
            try{
                fillDatalist('israel-cities-list',await loadCityList());
            }catch(e){
                console.error('city datalist failed',e);
            }
            [
                ['vol-city','vol-streets-list'],
                ['ev-city','ev-streets-list'],
                ['edit-ev-city','edit-ev-streets-list'],
                ['profile-city','profile-streets-list'],
                ['family-child-city','family-streets-list']
            ].forEach(([city,list])=>wireAddressDatalist(city,list));
        }

        function registrationLabel(v) {
            return ({approved:'מאושר', waitlist:'רשימת המתנה', cancelled:'בוטל'})[v] || v;
        }

        function registrationPill(v) {
            if (v === 'approved') return '<span class="status-pill bg-green-50 text-green-700">מאושר</span>';
            if (v === 'waitlist') return '<span class="status-pill bg-amber-50 text-amber-700">רשימת המתנה</span>';
            return '<span class="status-pill bg-slate-100 text-slate-600">בוטל</span>';
        }

        function eventStatusLabel(ev) {
            const status=ev.status||ev.event_status;
            if (status === 'cancelled') return 'בוטל';
            if (ev.event_date < new Date().toISOString().slice(0,10)) return 'הסתיים';
            if (status === 'full') return 'מלא';
            return 'פעיל';
        }

        function readableError(error) {
            const m=String(error?.message||error||'שגיאה לא ידועה');
            const pairs=[
                ['session_expired','ההתחברות פגה. התחבר מחדש.'],
                ['profile_missing','לא הצלחנו לטעון את הפרופיל. נסה להתחבר מחדש.'],
                ['weekly_limit_reached','הגעת למספר ימי ההתנדבות המקסימלי שהגדרת לשבוע זה.'],
                ['time_conflict','כבר יש לך התנדבות אחרת שחופפת בשעות לאירוע הזה.'],
                ['gender_required','יש לבחור משמח או משמחת בפרופיל.'],
                ['birth_year_required','יש להגדיר שנת לידה.'],
                ['invalid_birth_year','שנת הלידה אינה תקינה.'],
                ['address_required','יש להשלים עיר ורחוב בפרופיל.'],
                ['address_not_found','לא הצלחנו לזהות את הכתובת במפה. בדוק/י את העיר, הרחוב ומספר הבית.'],
                ['invalid_address','יש להשלים עיר ורחוב.'],
                ['invalid_availability','טווח שעות הזמינות אינו תקין.'],
                ['invalid_transport_mode','אמצעי ההגעה אינו תקין.'],
                ['invalid_registration_deadline','מועד סגירת ההרשמה חייב להיות מעכשיו ועד שעת תחילת האירוע.'],
                ['invalid_age_range','טווח הגילאים אינו תקין.'],
                ['invalid_event_type','סוג האירוע אינו תקין.'],
                ['invalid_event_type_preferences','יש לבחור לפחות סוג אירוע אחד שבו תרצה/י לשמח.'],
                ['minimum_volunteer_age','הגיל המינימלי למשמח/ת הוא 12.'],
                ['adult_account_required','חשבון רגיל למשמח/ת מיועד מגיל 18. ילד/ה בגיל 12–17 ניתן להוסיף מתוך האזור האישי של ההורה.'],
                ['family_child_must_be_added_from_account','ילד/ה בגיל 12–17 יש להוסיף מתוך חשבון ההורה באזור האישי.'],
                ['family_child_age_required','אפשר להוסיף לחשבון ילד/ה בגיל 12–17 בלבד.'],
                ['guardian_required','למשמח/ת מתחת לגיל 18 נדרש רישום ואישור של הורה או אפוטרופוס.'],
                ['minor_event_types_only','משמחים מתחת לגיל 18 יכולים להירשם רק לאירועי בר מצווה ובת מצווה.'],
                ['minor_age_range_only_mitzvah','טווח גיל 12–18 זמין רק בבר מצווה ובבת מצווה.'],
                ['weekend_event_forbidden','לא ניתן לפרסם אירוע ביום שישי או בשבת.'],
                ['weekend_availability_forbidden','זמינות למשמחים היא בימים ראשון עד חמישי בלבד.'],
                ['address_list_unavailable','רשימת הערים והרחובות אינה זמינה כרגע. נסה לרענן את הדף.'],
                ['invalid_message','ההודעה ריקה או ארוכה מדי.'],
                ['registration_not_found','לא נמצאה הרשמה פעילה לאירוע.'],
                ['attendance_confirmation_too_early','אפשר לאשר הגעה בפועל רק אחרי שהאירוע הסתיים.'],
                ['user_blocked','החשבון חסום כרגע.'],
                ['event_unavailable','האירוע אינו זמין להרשמה.'],
                ['event_not_found','האירוע כבר לא קיים.'],
                ['cannot_register_own_event','לא ניתן להירשם כמשמח לאירוע שפרסמת.'],
                ['quota_below_existing_registrations','אי אפשר להקטין מכסה מתחת למספר הנרשמים שכבר אושרו.'],
                ['invalid_event_times','שעת הסיום חייבת להיות מאוחרת משעת ההתחלה.'],
                ['duplicate_event','נראה שכבר פרסמת את האירוע הזה.'],
                ['invalid_event_name','יש להזין שם לאירוע.'],
                ['invalid_location','יש להשלים עיר, רחוב ומספר בכתובת האולם.'],
                ['event_location_missing','לא הצלחנו לזהות את כתובת האולם במפה.'],
                ['gender_change_with_active_registrations','לא ניתן לשנות בין משמח למשמחת כל עוד יש הרשמות פעילות לאירועים עתידיים.'],
                ['report_reason_required','יש לכתוב סיבה קצרה לדיווח.'],
                ['event_date_in_past','לא ניתן לבחור תאריך שכבר עבר.'],
                ['invalid_login','מספר הטלפון או הסיסמה שגויים.'],
                ['too_many_login_attempts','יותר מדי ניסיונות התחברות. נסה שוב בעוד כ־15 דקות.'],
                ['already_registered','כבר קיים חשבון עם מספר הטלפון הזה. התחבר כדי להמשיך.'],
                ['invalid_phone','מספר הטלפון אינו תקין.'],
                ['invalid_password','הסיסמה חייבת לכלול לפחות 8 תווים.'],
                ['invalid_name','יש להזין שם מלא.'],
                ['not_allowed','אין הרשאה לבצע את הפעולה הזאת.'],
                ['invalid_admin_login','שם המשתמש או סיסמת המנהל שגויים.'],
                ['admin_login_locked','הכניסה למנהל ננעלה זמנית לאחר מספר ניסיונות שגויים. נסה שוב בעוד כ־15 דקות.'],
                ['admin_login_rate_limited','בוצעו יותר מדי ניסיונות כניסה לניהול מהמכשיר הזה. נסה שוב מאוחר יותר.'],
                ['invalid_admin_password','סיסמת המנהל הנוכחית שגויה.'],
                ['invalid_admin_new_password','סיסמת מנהל חדשה חייבת לכלול לפחות 12 תווים.'],
                ['admin_password_unchanged','יש לבחור סיסמת מנהל חדשה ושונה מהסיסמה הנוכחית.'],
                ['cannot_block_self','לא ניתן לחסום את חשבון המנהל הפעיל.'],
                ['invalid_reminder_hours','מספר השעות לתזכורת חייב להיות בין 1 ל-168.'],
                ['sms_missing','הודעת ה-SMS לא נמצאה.'],
                ['sms_expired','תוקף הודעת ה-SMS כבר פג.'],
                ['sms_not_retryable','אפשר לשלוח מחדש רק הודעת SMS שנכשלה.'],
                ['report_missing','הדיווח לא נמצא.'],
                ['event_missing','האירוע לא נמצא.'],
                ['registration_temporarily_disabled','ההרשמה לאתר סגורה זמנית.'],
                ['minor_registration_temporarily_disabled','הרשמת בני 12–17 סגורה זמנית.'],
                ['event_creation_temporarily_disabled','פרסום אירועים חדשים סגור זמנית.'],
                ['invalid_site_content','תוכן האתר אינו תקין.'],
                ['invalid_field_config','הגדרות השדות אינן תקינות.'],
                ['invalid_event_type_config','הגדרת סוגי האירועים אינה תקינה.'],
                ['invalid_radius_config','הגדרת המרחקים אינה תקינה.'],
                ['invalid_sector_config','הגדרת המגזרים אינה תקינה.'],
                ['invalid_age_range_config','הגדרת טווחי הגיל אינה תקינה.'],
                ['invalid_asset_url','כתובת קובץ התמונה אינה מאושרת.'],
                ['invalid_sms_template','נוסח הודעת ה-SMS ריק או ארוך מדי.'],
                ['sms_template_missing','תבנית ה-SMS לא נמצאה.'],
                ['upload_failed','העלאת התמונה נכשלה. נסה שוב.'],
                ['configured_option_disabled','האפשרות שנבחרה אינה פעילה כרגע לפי הגדרות האתר.'],
                ['admin_user_consent_required','יש לאשר שקיבלת הסכמה מהמשתמש לפתיחת החשבון ולשימוש התפעולי.'],
                ['cannot_delete_current_admin','אי אפשר למחוק את חשבון המנהל שבו אתה משתמש כרגע.'],
                ['cannot_delete_admin','אי אפשר למחוק חשבון מנהל מתוך רשימת המשתמשים.'],
                ['invalid_site_text','הטקסט אינו תקין או ארוך מדי.'],
                ['site_text_missing','הטקסט לא נמצא במאגר העריכה.'],
                ['invalid_support_request','יש להשלים שם, טלפון תקין ותיאור של הפנייה.'],
                ['support_rate_limited','נשלחו יותר מדי פניות היום. אפשר לנסות שוב מאוחר יותר.'],
                ['support_request_missing','הפנייה לא נמצאה.'],
                ['invalid_support_status','סטטוס הפנייה אינו תקין.'],
                ['volunteer_profile_required','יש להפעיל קודם מצב משמח בפרופיל.'],
                ['criteria_mismatch','האירוע כבר לא עומד בכל קריטריוני ההתאמה.'],
                ['consent_required','יש לאשר את תנאי השימוש, מדיניות הפרטיות וקבלת ה-SMS התפעולי.'],
                ['phone_verification_required','יש לאמת את מספר הטלפון לפני המשך ההרשמה.'],
                ['verification_rate_limited','נשלח קוד לאחרונה. יש להמתין כדקה לפני שליחת קוד נוסף.'],
                ['verification_invalid_code','קוד האימות שגוי.'],
                ['verification_expired','קוד האימות פג. יש לשלוח קוד חדש.'],
                ['verification_too_many_attempts','בוצעו יותר מדי ניסיונות קוד. יש לשלוח קוד חדש.'],
                ['gateway_unavailable','שירות ה-SMS אינו זמין כרגע. נסה שוב בעוד כמה דקות.'],
                ['gateway_send_failed','לא הצלחנו לשלוח את קוד האימות. נסה שוב בעוד כמה דקות.'],
                ['gateway_auth_failed','שירות ה-SMS אינו מחובר כרגע. נסה שוב בעוד כמה דקות.'],
                ['verification_cancelled','האימות בוטל.'],
                ['reset_not_available','לא ניתן לאפס סיסמה עבור המספר הזה.'],
                ['active_host_events_exist','לפני מחיקת החשבון יש לבטל את האירועים העתידיים שפרסמת.'],
                ['address_incomplete','יש להקליד עיר, רחוב ומספר בית.'],
                ['address_lookup_failed','לא הצלחנו לבדוק את הכתובת כרגע. נסה שוב בעוד רגע.']
            ];
            for(const [key,text] of pairs) if(m.includes(key)) return text;
            if(m.includes('אינן זהות')) return 'הסיסמאות אינן זהות.';
            return 'אירעה שגיאה. נסה שוב בעוד רגע.';
        }

        async function geocodeAddress(address) {
            if (!address || address.trim().length < 3) return {lat:null, lng:null};
            try {
                const url = 'https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=il&accept-language=he&q=' + encodeURIComponent(address + ', ישראל');
                const res = await fetch(url, { headers: { 'Accept': 'application/json' } });
                if (!res.ok) return {lat:null,lng:null};
                const rows = await res.json();
                if (!rows?.length) return {lat:null,lng:null};
                return { lat: Number(rows[0].lat), lng: Number(rows[0].lon) };
            } catch (_) {
                return {lat:null,lng:null};
            }
        }

        async function loadProfile(retries=2) {
            if (!sessionToken) return null;
            for (let i=0; i<retries; i++) {
                const { data, error } = await _supabase.rpc('username_my_profile');
                const profile = Array.isArray(data) ? data[0] : data;
                if (!error && profile) {
                    currentProfile = profile;
                    currentUser = { id: profile.id };
                    return profile;
                }
                await new Promise(r => setTimeout(r, 250));
            }
            currentProfile = null;
            currentUser = null;
            return null;
        }

        async function initSession(){
            LEGACY_PERSONAL_STORAGE_KEYS.forEach(key=>{try{localStorage.removeItem(key);}catch(_){}});
            if(!sessionToken){clearAllPersonalBrowserStorage();clearSensitiveForms();clearRuntimeUserData();updateHeaderActions();return;}
            const profile=await loadProfile();
            if(!profile){
                applySessionToken('');
                clearAllPersonalBrowserStorage();
                clearRuntimeUserData();
                updateHeaderActions();
                return;
            }
            const {data:adminFlag}=await _supabase.rpc('is_admin');
            currentIsAdmin=!!adminFlag;
            if(adminMode&&!currentIsAdmin){
                adminMode=false;
                applyAdminSessionToken('');
            }
            updateHeaderActions();
            if(adminMode&&currentIsAdmin){armAdminIdleLogout();await loadAdminArea();}
        }
        async function openPersonalArea(){if(!sessionToken)return navigate('login');const profile=await loadProfile();if(!profile){applySessionToken('');updateHeaderActions();showToast('ההתחברות פגה. יש להתחבר מחדש.','warning');return navigate('login');}await loadDashboard();}

        async function handleRegisterVolunteer(){
            setBusy('vol-submit',true,'יוצר חשבון...');
            try {
                const name=$('vol-name').value.trim();
                const phone=normalizePhone($('vol-phone').value);
                const password=$('vol-pass').value;
                const confirmPassword=$('vol-pass-confirm').value;
                const gender=$('vol-gender').value;
                const birthYear=Number($('vol-birth-year').value);
                const sector=$('vol-sector').value;
                const prefs=checkedValues('vol-sector-pref');
                const eventTypePrefs=checkedValues('vol-event-type-pref');
                const {city,street,number}=getAddressParts('vol');
                const radius=Number($('vol-radius').value);
                const maxDays=Number($('vol-days').value);
                const days=checkedNumbers('vol-available-day');
                const availableFrom=$('vol-available-from').value||null;
                const availableUntil=$('vol-available-until').value||null;
                const transport=$('vol-transport').value;
                const separation=$('vol-separation').checked;
                const legalConsent=!!$('vol-legal-consent')?.checked;
                const smsConsent=!!$('vol-sms-consent')?.checked;

                if(!isValidPhone(phone)) throw new Error('invalid_phone');
                if(password.length<8) throw new Error('invalid_password');
                if(password!==confirmPassword) throw new Error('הסיסמאות אינן זהות.');
                if(!days.length) throw new Error('יש לבחור לפחות יום זמינות אחד.');
                if(!eventTypePrefs.length) throw new Error('invalid_event_type_preferences');
                const calculatedAge=new Date().getFullYear()-birthYear;
                if(calculatedAge<18) throw new Error('adult_account_required');
                if(!legalConsent||!smsConsent) throw new Error('consent_required');
                if(!city||!street||!number) throw new Error('address_incomplete');
                const coords=await verifyTypedAddress(city,street,number);
                const verificationToken=await ensurePhoneVerification(phone,'register');

                const {data:token,error}=await _supabase.rpc('username_register_v8',{
                    p_phone:phone,p_password:password,p_full_name:name,p_role:'volunteer',
                    p_gender:gender,p_sector:sector,p_volunteer_sector_preferences:prefs,
                    p_volunteer_event_type_preferences:eventTypePrefs,p_birth_year:birthYear,p_city:city,p_street:street,p_house_number:number,
                    p_radius:radius,p_max_days_per_week:maxDays,p_strict_separation:separation,
                    p_availability_days:days,p_availability_from:availableFrom,p_availability_until:availableUntil,
                    p_transport_mode:transport,p_lat:coords.lat,p_lng:coords.lng,
                    p_verification_token:verificationToken,p_privacy_accepted:true,p_terms_accepted:true,p_sms_consent:true,
                    p_guardian_managed:false,p_guardian_name:null,p_guardian_consent:false
                });
                if(error) throw error;
                applySessionToken(token); await loadProfile(); updateHeaderActions();
                $('volunteer-form')?.reset();
                showToast('ההרשמה הושלמה בהצלחה!','success');
                await loadDashboard();
            } catch(e) { showToast(String(e?.message||'').includes('לפחות יום')?String(e.message):readableError(e),'error'); }
            finally { setBusy('vol-submit',false); }
        }


        function renderAdminPasswordCard(mustChange=false){
            return '<div class="glass-card p-6 '+(mustChange?'border-2 border-amber-300':'')+'"><h3 class="text-xl font-bold">'+(mustChange?'נדרשת החלפת סיסמה':'שינוי סיסמת מנהל')+'</h3>'+(mustChange?'<p class="text-sm text-amber-700 mt-1">החשבון נוצר עם סיסמה זמנית. מאחר שכבר נכנסת כמנהל, צריך לבחור רק סיסמה חדשה.</p>':'<p class="text-sm text-slate-500 mt-1">הכניסה הפעילה שלך מאשרת את הזהות, לכן אין צורך להזין שוב את הסיסמה הנוכחית.</p>')+'<form id="admin-password-form" onsubmit="event.preventDefault(); handleAdminPasswordChange();" class="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4"><input type="password" id="admin-new-password" class="input-clean" placeholder="סיסמה חדשה — לפחות 12 תווים" minlength="12" maxlength="72" required autocomplete="new-password"><input type="password" id="admin-new-password-confirm" class="input-clean" placeholder="אימות סיסמה חדשה" minlength="12" maxlength="72" required autocomplete="new-password"><button id="admin-password-submit" type="submit" class="btn-dark py-3 md:col-span-2">שמור סיסמה חדשה</button></form></div>';
        }

        async function handleAdminPasswordChange(){
            setBusy('admin-password-submit',true,'שומר...');
            try{
                const next=$('admin-new-password').value;
                const confirm=$('admin-new-password-confirm').value;
                if(next.length<12) throw new Error('invalid_admin_new_password');
                if(next!==confirm) throw new Error('הסיסמאות אינן זהות.');
                const {error}=await _supabase.rpc('admin_set_password',{p_new_password:next});
                if(error) throw error;
                $('admin-password-form')?.reset();
                showToast('סיסמת המנהל עודכנה.','success');
                await loadAdminArea();
            }catch(e){showToast(readableError(e),'error');}
            finally{setBusy('admin-password-submit',false);}
        }

        async function loadAdminArea(){
            if(!sessionToken||!adminMode) return navigate('login');
            const profile=currentProfile||await loadProfile();
            const {data:adminFlag,error:adminErr}=await _supabase.rpc('is_admin');
            currentIsAdmin=!!adminFlag&&!adminErr;
            if(!profile||!currentIsAdmin){
                applySessionToken('');
                adminMode=false;
                sessionStorage.removeItem('smachimAdminMode');
                updateHeaderActions();
                showToast('אין הרשאת מנהל.','error');
                return navigate('login');
            }
            const {data:status,error:statusErr}=await _supabase.rpc('admin_account_status');
            if(statusErr) return showToast(readableError(statusErr),'error');
            const account=Array.isArray(status)?status[0]:status;
            const root=$('admin-area-root');
            if(!root) return;
            navigate('admin');
            updateHeaderActions();
            if(account?.must_change_password){
                root.innerHTML=renderAdminPasswordCard(true);
                return;
            }
            root.innerHTML=renderAdminPanel();
            await adminOpenTab(adminTab);
        }

        async function handleLogin(){
            setBusy('login-submit',true,'מתחבר...');
            const identifier=$('login-phone').value.trim();
            const password=$('login-password').value;
            const phone=normalizePhone(identifier);
            const isPhone=isValidPhone(phone);

            try{
                if(isPhone){
                    const loginRes=await fetch(SUPABASE_URL+'/functions/v1/user-auth',{
                        method:'POST',
                        headers:{'Content-Type':'application/json','apikey':SUPABASE_PUBLISHABLE_KEY},
                        body:JSON.stringify({phone,password})
                    });
                    const loginData=await loginRes.json().catch(()=>({}));
                    if(!loginRes.ok)throw new Error(loginData?.error||'invalid_login');
                    const token=loginData?.token;
                    if(!token)throw new Error('invalid_login');

                    applySessionToken(token);
                    adminMode=false;
                    currentIsAdmin=false;
                    sessionStorage.removeItem('smachimAdminMode');

                    const profile=await loadProfile();
                    if(!profile)throw new Error('session_expired');

                    $('login-form')?.reset();
                    updateHeaderActions();
                    showToast('ברוך הבא!','success');
                    await loadDashboard();
                    return;
                }

                const username=identifier.toLowerCase();
                const adminRes=await fetch(SUPABASE_URL+'/functions/v1/admin-auth',{
                    method:'POST',
                    headers:{'Content-Type':'application/json','apikey':SUPABASE_PUBLISHABLE_KEY},
                    body:JSON.stringify({username,password})
                });
                const data=await adminRes.json().catch(()=>({}));
                if(!adminRes.ok)throw new Error(data?.error||'invalid_admin_login');

                const token=data?.token;
                if(!token)throw new Error('invalid_admin_login');

                applyAdminSessionToken(token);
                adminMode=true;

                const profile=await loadProfile();
                const {data:adminFlag,error:adminErr}=await _supabase.rpc('is_admin');
                if(adminErr||!profile||!adminFlag)throw new Error('not_allowed');

                currentIsAdmin=true;
                armAdminIdleLogout();
                $('login-form')?.reset();
                updateHeaderActions();
                await loadAdminArea();

                if(data?.must_change_password){
                    showToast('יש להחליף את הסיסמה הזמנית לפני שימוש בפאנל.','warning');
                }
            }catch(e){
                if(!isPhone){
                    applyAdminSessionToken('');
                    adminMode=false;
                    currentIsAdmin=false;
                    const msg=String(e?.message||'');
                    showToast(['admin_login_rate_limited','admin_login_locked'].includes(msg)?readableError(e):'פרטי ההתחברות שגויים.','error');
                }else{
                    showToast(readableError(e),'error');
                }
                if($('login-password'))$('login-password').value='';
            }finally{
                setBusy('login-submit',false);
            }
        }


        async function handleLogout(){
            const token=sessionToken;
            const wasAdmin=adminMode;
            try{if(token)await _supabase.rpc('username_logout',{p_token:token});}catch(_){}
            if(wasAdmin) applyAdminSessionToken(''); else applySessionToken('');
            clearAllPersonalBrowserStorage();
            clearRuntimeUserData();
            updateHeaderActions();
            navigate('home');
            showToast('התנתקת מהמערכת. כל הנתונים האישיים המקומיים נוקו מהדפדפן.');
        }

        async function openAddEvent(){
            if(sessionToken&&!currentProfile) await loadProfile();
            const block=$('host-account-block');
            const accountFields=$('host-account-fields');
            const existingNote=$('host-existing-account-note');
            const existingText=$('host-existing-account-text');
            const fields=['host-name','host-phone','host-pass','host-pass-confirm','host-legal-consent','host-sms-consent'];
            block?.classList.remove('hidden');
            if(currentProfile){
                accountFields?.classList.add('hidden');
                existingNote?.classList.remove('hidden');
                if(existingText){
                    existingText.textContent='בעל השמחה: '+(currentProfile.full_name||'החשבון שלי')+' · טלפון: '+displayPhone(currentProfile.phone||'');
                }
                fields.forEach(id=>{const el=$(id);if(el){el.required=false;el.value='';}});
            } else {
                accountFields?.classList.remove('hidden');
                existingNote?.classList.add('hidden');
                if(existingText)existingText.textContent='';
                fields.forEach(id=>{const el=$(id);if(el)el.required=true;});
            }
            $('ev-date').min=new Date().toISOString().slice(0,10);
            syncEventAgeRangeOptions('');
            await restoreEventDraft();
            navigate('add-event');
        }

        function saveEventDraft(){
            const form=$('event-form');
            const key=eventDraftKey();
            if(!form || !key) return;
            const addr=getAddressParts('ev');
            const draft={
                event_name:$('ev-name')?.value||'',event_type:$('ev-type')?.value||'wedding',
                event_date:$('ev-date')?.value||'',registration_deadline:$('ev-registration-deadline')?.value||'',
                hall_name:$('ev-hall-name')?.value||'',city:addr.city,street:addr.street,address_manual:addr.manual,
                house_number:addr.number,start_time:$('ev-start')?.value||'',close_time:$('ev-close')?.value||'',
                sector_pref:$('ev-sector')?.value||'all',accepted_sectors:checkedValues('ev-accepted-sector'),
                is_separated:!!$('ev-separation')?.checked,quota_men:$('ev-men')?.value||'0',quota_women:$('ev-women')?.value||'0',
                age_range:$('ev-age-range')?.value||'all',note:$('ev-note')?.value||''
            };
            localStorage.setItem(key,JSON.stringify(draft));
            if($('draft-indicator')) $('draft-indicator').textContent='הטיוטה נשמרה';
        }

        async function restoreEventDraft(){
            const key=eventDraftKey();
            if(!key) return;
            const raw=localStorage.getItem(key); if(!raw) return;
            try {
                const d=JSON.parse(raw);
                const map={event_name:'ev-name',event_type:'ev-type',event_date:'ev-date',registration_deadline:'ev-registration-deadline',
                    hall_name:'ev-hall-name',city:'ev-city',street:'ev-street',house_number:'ev-house-number',start_time:'ev-start',
                    close_time:'ev-close',sector_pref:'ev-sector',quota_men:'ev-men',quota_women:'ev-women',age_range:'ev-age-range',note:'ev-note'};
                Object.entries(map).forEach(([k,id])=>{if(k!=='age_range'&&d[k]!==undefined&&$(id))$(id).value=d[k];});
                syncEventAgeRangeOptions('');
                if(d.age_range!==undefined&&$('ev-age-range')) $('ev-age-range').value=d.age_range;
                if($('ev-separation')) $('ev-separation').checked=!!d.is_separated;
                setCheckedValues('ev-accepted-sector',d.accepted_sectors||['all']);
                if($('draft-indicator')) $('draft-indicator').textContent='שוחזרה טיוטה';
            } catch(_) {}
        }

        function clearEventDraft(){
            const key=eventDraftKey();
            if(key) localStorage.removeItem(key);
            LEGACY_PERSONAL_STORAGE_KEYS.forEach(k=>{try{localStorage.removeItem(k);}catch(_){}});
            if($('draft-indicator'))$('draft-indicator').textContent='';
        }

        function initEventDraftAutosave(){
            const form=$('event-form'); if(!form) return;
            form.querySelectorAll('input,select,textarea').forEach(el=>{
                if(['host-pass','host-pass-confirm'].includes(el.id)) return;
                el.addEventListener('input',saveEventDraft); el.addEventListener('change',saveEventDraft);
            });
            const suggest=()=>{
                if($('ev-registration-deadline').value||!$('ev-date').value||!$('ev-start').value) return;
                const d=new Date($('ev-date').value+'T'+$('ev-start').value+':00');
                d.setHours(d.getHours()-2);
                const pad=n=>String(n).padStart(2,'0');
                $('ev-registration-deadline').value=d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())+'T'+pad(d.getHours())+':'+pad(d.getMinutes());
            };
            $('ev-date')?.addEventListener('change',suggest); $('ev-start')?.addEventListener('change',suggest);
        }

        function collectEventForm(prefix='') {
            const id=(name)=>$(prefix+name);
            const n=(name)=>{const v=id(name).value;return v===''?null:Number(v);};
            const acceptedName=prefix?'edit-ev-accepted-sector':'ev-accepted-sector';
            const addr=getAddressParts(prefix?'edit-ev':'ev');
            const ageRange=ageRangeBounds(id('ev-age-range').value);
            return {
                event_name:id('ev-name').value.trim(),
                event_type:id('ev-type').value,
                event_date:id('ev-date').value,
                registration_deadline:id('ev-registration-deadline').value,
                hall_name:id('ev-hall-name').value.trim(),
                city:addr.city,
                street:addr.street,
                house_number:addr.number,
                start_time:id('ev-start').value,
                close_time:id('ev-close').value,
                sector_pref:id('ev-sector').value,
                accepted_sectors:checkedValues(acceptedName),
                is_separated:id('ev-separation').checked,
                quota_men:Number(id('ev-men').value||0),
                quota_women:Number(id('ev-women').value||0),
                age_min:ageRange.min,
                age_max:ageRange.max,
                note:id('ev-note').value.trim()
            };
        }

        function validateEventPayload(ev) {
            if(!ev.event_name||ev.event_name.length<2) throw new Error('invalid_event_name');
            if(!ev.event_date||ev.event_date<new Date().toISOString().slice(0,10)) throw new Error('event_date_in_past');
            if(isFridayOrSaturday(ev.event_date)) throw new Error('weekend_event_forbidden');
            if(!ev.start_time||!ev.close_time||ev.close_time<=ev.start_time) throw new Error('invalid_event_times');
            if(!ev.registration_deadline) throw new Error('invalid_registration_deadline');
            if(!ev.city||!ev.street||!ev.house_number) throw new Error('invalid_location');
            if(ev.quota_men<0||ev.quota_women<0) throw new Error('invalid_quota');
            if(ev.age_min!=null&&ev.age_max!=null&&ev.age_min>ev.age_max) throw new Error('invalid_age_range');
        }

        async function createEventRpc(ev) {
            validateEventPayload(ev);
            const coords=await verifyTypedAddress(ev.city,ev.street,ev.house_number);

            const {data:eventId,error}=await _supabase.rpc('create_event_v5',{
                p_event_name:ev.event_name,p_event_type:ev.event_type,p_event_date:ev.event_date,
                p_registration_deadline:ev.registration_deadline,p_hall_name:ev.hall_name,
                p_city:ev.city,p_street:ev.street,p_house_number:ev.house_number,
                p_start_time:ev.start_time,p_close_time:ev.close_time,p_sector_pref:ev.sector_pref,
                p_accepted_volunteer_sectors:ev.accepted_sectors,p_is_separated:ev.is_separated,
                p_quota_men:ev.quota_men,p_quota_women:ev.quota_women,p_age_min:ev.age_min,p_age_max:ev.age_max,
                p_volunteer_note:ev.note||null,p_lat:coords.lat,p_lng:coords.lng
            });
            if(error) throw error;
            return eventId;
        }

        async function previewEventMatches(){
            const box=$('event-preview-count'); if(!box) return;
            try{
                const ev=collectEventForm(''); validateEventPayload(ev);
                box.textContent='בודק התאמות...';
                const coords=await verifyTypedAddress(ev.city,ev.street,ev.house_number);
                const {data,error}=await _supabase.rpc('preview_event_match_count_v3',{
                    p_event_type:ev.event_type,p_event_date:ev.event_date,p_start_time:ev.start_time,p_close_time:ev.close_time,
                    p_sector_pref:ev.sector_pref,p_accepted_volunteer_sectors:ev.accepted_sectors,
                    p_is_separated:ev.is_separated,p_age_min:ev.age_min,p_age_max:ev.age_max,
                    p_lat:coords.lat,p_lng:coords.lng
                });
                if(error) throw error;
                const x=data?.[0]||{men_count:0,women_count:0,total_count:0};
                box.innerHTML='<b>'+Number(x.total_count||0)+'</b> משמחים מתאימים כרגע · משמחים '+Number(x.men_count||0)+' · משמחות '+Number(x.women_count||0);
            }catch(e){box.textContent=readableError(e);}
        }

        async function handleCreateEvent(){
            setBusy('event-submit',true,'מפרסם אירוע...');
            try{
                const ev=collectEventForm(''); validateEventPayload(ev);
                if(sessionToken){
                    const profile=currentProfile||await loadProfile();
                    if(profile){
                        await createEventRpc(ev); await loadProfile(); $('event-form').reset(); clearEventDraft();
                        setCheckedValues('ev-accepted-sector',['all']);
                        showToast('האירוע פורסם בהצלחה!','success'); await loadDashboard(); return;
                    }
                    applySessionToken('');
                }

                const name=$('host-name').value.trim(),phone=normalizePhone($('host-phone').value);
                const password=$('host-pass').value,confirmPassword=$('host-pass-confirm').value;
                const legalConsent=!!$('host-legal-consent')?.checked,smsConsent=!!$('host-sms-consent')?.checked;
                if(name.length<2) throw new Error('invalid_name');
                if(!isValidPhone(phone)) throw new Error('invalid_phone');
                if(password.length<8) throw new Error('invalid_password');
                if(password!==confirmPassword) throw new Error('הסיסמאות אינן זהות.');
                if(!legalConsent||!smsConsent) throw new Error('consent_required');
                const verificationToken=await ensurePhoneVerification(phone,'register');

                const {data:token,error}=await _supabase.rpc('username_register_v8',{
                    p_phone:phone,p_password:password,p_full_name:name,p_role:'host',
                    p_gender:null,p_sector:'all',p_volunteer_sector_preferences:['all'],p_volunteer_event_type_preferences:['all'],p_birth_year:null,
                    p_city:'',p_street:'',p_house_number:'',p_radius:30,p_max_days_per_week:3,
                    p_strict_separation:false,p_availability_days:[0,1,2,3,4],
                    p_availability_from:null,p_availability_until:null,p_transport_mode:'car',p_lat:null,p_lng:null,
                    p_verification_token:verificationToken,p_privacy_accepted:true,p_terms_accepted:true,p_sms_consent:true,
                    p_guardian_managed:false,p_guardian_name:null,p_guardian_consent:false
                });
                if(error){
                    if(String(error.message).includes('already_registered')){
                        clearSensitiveForms();
                        showToast('כבר קיים חשבון עם המספר הזה. מטעמי פרטיות לא שמרנו את פרטי האירוע. התחבר ואז פרסם אותו מתוך החשבון.','warning');
                        navigate('login');
                        return;
                    }
                    throw error;
                }
                applySessionToken(token);
                await loadProfile();
                updateHeaderActions();
                await createEventRpc(ev);
                $('event-form').reset();
                clearEventDraft();
                showToast('החשבון והאירוע נוצרו בהצלחה!','success');
                await loadDashboard();
            }catch(e){showToast(readableError(e),'error');}
            finally{setBusy('event-submit',false);}
        }

        async function finalizePendingEvent(){
            try{localStorage.removeItem('pendingHostEvent');}catch(_){}
        }

        function resolveDashboardArea() {
            if (!currentProfile) return 'volunteer';
            if (currentProfile.role==='both') {
                if (!['volunteer','host'].includes(dashboardArea)) dashboardArea='volunteer';
                return dashboardArea;
            }
            return currentProfile.role==='host' ? 'host' : 'volunteer';
        }

        function renderDashboardSwitcher() {
            if (currentProfile?.role!=='both') return '';
            const mode=resolveDashboardArea();
            return '<div class="flex justify-center"><div class="area-switch" role="group" aria-label="מעבר בין אזורי החשבון"><button aria-pressed="'+(mode==='volunteer'?'true':'false')+'" class="'+(mode==='volunteer'?'active':'')+'" onclick="switchDashboardArea(\'volunteer\')"><i class="fa-solid fa-hand-holding-heart ml-1"></i> אזור משמח</button><button aria-pressed="'+(mode==='host'?'true':'false')+'" class="'+(mode==='host'?'active':'')+'" onclick="switchDashboardArea(\'host\')"><i class="fa-solid fa-calendar-days ml-1"></i> אזור בעל שמחה</button></div></div>';
        }

        async function switchDashboardArea(mode) {
            if (!['volunteer','host'].includes(mode)) return;
            dashboardArea=mode;
            localStorage.setItem('smachimDashboardArea',mode);
            await loadDashboard();
        }

        function sectorListLabel(values) {
            const a=values||[];
            if(a.includes('all')) return 'כל המגזרים';
            return a.map(sectorLabel).join(', ')||'לא הוגדר';
        }

        function formatDateTime(value) {
            if(!value) return '';
            const d=new Date(String(value).replace(' ','T'));
            if(Number.isNaN(d.getTime())) return String(value).replace('T',' ');
            return new Intl.DateTimeFormat('he-IL',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'}).format(d);
        }

        function renderProfileOverview() {
            const address=fullAddress(currentProfile.city,currentProfile.street,currentProfile.house_number)||currentProfile.address||'לא הוגדרה כתובת';
            return '<div class="glass-card p-5 flex flex-wrap gap-4 justify-between items-center"><div><div class="text-xs font-bold text-slate-500">החשבון שלך</div><div class="font-bold text-lg">'+esc(roleLabel(currentProfile.role))+'</div><div class="text-sm text-slate-500 mt-1" dir="ltr">'+esc(displayPhone(currentProfile.phone))+'</div></div><div class="text-sm text-slate-600"><i class="fa-solid fa-location-dot ml-1"></i>'+esc(address)+'</div><button onclick="openProfileSettings()" class="btn-soft px-4 py-2 text-sm">הגדרות משמח</button></div>';
        }

        async function renderQuickStats() {
            const {data,error}=await _supabase.rpc('get_dashboard_stats');
            if(error||!data?.length) return '';
            const s=data[0];
            return '<div class="grid grid-cols-2 lg:grid-cols-4 gap-3"><div class="mini-stat"><div class="text-xs text-slate-500">התנדבויות קרובות</div><div class="text-2xl font-bold mt-1">'+Number(s.upcoming_approved||0)+'</div></div><div class="mini-stat"><div class="text-xs text-slate-500">אירועים פעילים שלי</div><div class="text-2xl font-bold mt-1">'+Number(s.hosted_active||0)+'</div></div><div class="mini-stat"><div class="text-xs text-slate-500">התראות חדשות</div><div class="text-2xl font-bold mt-1">'+Number(s.unread_notifications||0)+'</div></div><div class="mini-stat"><div class="text-xs text-slate-500">רדיוס התאמה</div><div class="text-2xl font-bold mt-1">'+esc(radiusLabel(currentProfile.radius))+'</div></div></div>';
        }

        function renderProfileCompleteness() {
            if(!['volunteer','both'].includes(currentProfile.role)) return '';
            const missing=[];
            if(!currentProfile.gender) missing.push('משמח/משמחת');
            if(!currentProfile.birth_year) missing.push('שנת לידה');
            if(!currentProfile.sector||currentProfile.sector==='all') missing.push('מגזר אישי');
            if(!currentProfile.city||!currentProfile.street) missing.push('כתובת');
            if(currentProfile.lat==null||currentProfile.lng==null) missing.push('מיקום במפה');
            if(!missing.length) return '';
            return '<div class="bg-amber-50 border border-amber-200 rounded-xl p-4 flex flex-wrap gap-3 justify-between items-center"><div><div class="font-bold text-amber-900">צריך להשלים את הפרופיל</div><div class="text-sm text-amber-800">חסר: '+esc(missing.join(', '))+'. עד להשלמה ייתכן שלא יוצגו התאמות.</div></div><button onclick="openProfileSettings()" class="bg-white border border-amber-200 px-3 py-2 rounded-lg font-bold text-sm text-amber-900">להשלמה</button></div>';
        }

        async function enableVolunteerMode() {
            if(!currentProfile.gender||!currentProfile.birth_year||!currentProfile.city||!currentProfile.street||currentProfile.lat==null){
                showToast('יש להשלים קודם את פרטי המשמח בהגדרות.','warning');
                return openProfileSettings();
            }
            const {error}=await _supabase.rpc('enable_volunteer_mode');
            if(error) return showToast(readableError(error),'error');
            await loadProfile(); dashboardArea='volunteer'; localStorage.setItem('smachimDashboardArea','volunteer');
            showToast('מצב משמח הופעל!','success'); await loadDashboard();
        }


        async function renderVolunteerScoreCard(){
            const {data:enabled,error:enabledError}=await _supabase.rpc('is_volunteer_scoring_enabled');
            if(enabledError||!enabled)return '';
            const {data,error}=await _supabase.rpc('get_my_volunteer_score');
            if(error)return '';
            const s=Array.isArray(data)?data[0]:data;
            if(!s)return '';
            const points=Number(s.points||0);
            const count=Number(s.confirmed_events||0);
            const next=s.next_rank_points==null?null:Number(s.next_rank_points);
            const from=s.rank_key==='advanced'?500:0;
            const max=next||Math.max(points,1500);
            const pct=s.rank_key==='senior'?100:Math.max(0,Math.min(100,Math.round(((points-from)/(max-from))*100)));
            const icon=s.rank_key==='senior'?'fa-crown':s.rank_key==='advanced'?'fa-star':'fa-seedling';
            return '<div class="glass-card p-5" aria-labelledby="volunteer-rank-title">'+
                '<div class="flex flex-wrap justify-between gap-4 items-center">'+
                    '<div class="flex items-center gap-4"><div class="w-14 h-14 rounded-full bg-brand-50 text-brand-700 flex items-center justify-center text-2xl" aria-hidden="true"><i class="fa-solid '+icon+'"></i></div>'+
                    '<div><h3 id="volunteer-rank-title" class="font-bold text-lg">'+esc(s.rank_label||'משמח מתחיל')+'</h3>'+
                    '<p class="text-sm text-slate-600"><b>'+points+'</b> נקודות · '+count+' אירועים שבהם אישרת הגעה</p></div></div>'+
                    (next===null?'<div class="status-pill bg-brand-50 text-brand-700">הדרגה הגבוהה ביותר</div>':'<div class="text-sm text-slate-500">עוד <b>'+Number(s.points_to_next_rank||0)+'</b> נקודות לדרגה הבאה</div>')+
                '</div>'+
                '<div class="progress-track mt-4" role="progressbar" aria-label="התקדמות לדרגה הבאה" aria-valuemin="0" aria-valuemax="100" aria-valuenow="'+pct+'"><div class="progress-fill" style="width:'+pct+'%"></div></div>'+
                '<p class="text-xs text-slate-500 mt-2">כאשר מנגנון הניקוד פעיל, כל אירוע שבו המשמח/ת מאשר/ת הגעה מעניק 100 נקודות. 5 אירועים = משמח מתקדם, 15 = משמח בכיר.</p>'+
            '</div>';
        }

        function renderVolunteerCriteriaSummary() {
            const gender=currentProfile.gender==='male'?'משמח':'משמחת';
            const age=currentProfile.birth_year?new Date().getFullYear()-Number(currentProfile.birth_year):'—';
            const time=(currentProfile.availability_from||currentProfile.availability_until)
                ? (currentProfile.availability_from?.slice(0,5)||'כל שעה')+'–'+(currentProfile.availability_until?.slice(0,5)||'כל שעה')
                : 'ללא הגבלת שעות';
            return '<div class="glass-card p-5"><div class="flex flex-wrap justify-between gap-3 items-center"><div><h3 class="font-bold text-lg">העדפות ההתאמה שלי</h3><p class="text-sm text-slate-600 mt-1">אני: '+esc(gender)+' · גיל: '+esc(age)+' · שיוך: '+esc(sectorLabel(currentProfile.sector))+' · מוכן לשמח: '+esc(sectorListLabel(currentProfile.volunteer_sector_preferences))+' · סוגי אירועים: '+esc(eventTypeListLabel(currentProfile.volunteer_event_type_preferences))+'</p><p class="text-sm text-slate-500 mt-1">'+esc(radiusLabel(currentProfile.radius))+' · '+(currentProfile.strict_separation?'רק הפרדה מלאה':'גם ללא הפרדה')+' · '+esc(time)+' · '+(currentProfile.transport_mode==='transit'?'תחבורה ציבורית':currentProfile.transport_mode==='any'?'כל אמצעי':'רכב')+'</p></div><button onclick="openProfileSettings()" class="btn-soft px-3 py-2 text-sm">שנה העדפות</button></div></div>';
        }

        function radiusChoiceValue(value){
            const n=Number(value||10);
            if(n<=10) return '10';
            if(n<=20) return '20';
            if(n<=50) return '50';
            if(n<=100) return '100';
            return '999';
        }

        function radiusLabel(value){
            const n=Number(value||10);
            return configuredRadiusOptions().find(x=>Number(x.value)===n)?.label || (n>=999?'כל הארץ':'עד '+n+' ק״מ');
        }

        function setDashHtml(id,html){const el=$(id);if(el)el.innerHTML=html||'';}

        async function loadDashboard(){
            if(!sessionToken) return navigate('login');
            const profile=await loadProfile(1);
            if(!profile){applySessionToken('');updateHeaderActions();showToast('ההתחברות פגה. יש להתחבר מחדש.','warning');return navigate('login');}

            updateHeaderActions();
            $('user-greeting').innerText='שלום, '+(currentProfile.full_name||'משתמש');
            navigate('dashboard');
            const mode=resolveDashboardArea();
            const container=$('dashboard-content');

            container.innerHTML=
                renderProfileOverview()+renderDashboardSwitcher()+
                '<div id="dash-stats" class="dashboard-skeleton">טוען סיכום...</div>'+
                '<div id="dash-completeness"></div>'+
                '<div id="dash-family" class="dashboard-skeleton">טוען משפחה...</div>'+
                (mode==='volunteer'?'<div id="dash-score" class="dashboard-skeleton">טוען דרגה...</div><div id="dash-criteria"></div>':'')+
                '<div id="dash-notifications" class="dashboard-skeleton">טוען התראות...</div>'+
                '<div id="dash-main-a" class="dashboard-skeleton">טוען נתונים...</div>'+
                '<div id="dash-main-b"></div>'+
                '<div id="dash-cta"></div><div id="dash-admin"></div>';

            void _supabase.rpc('sync_event_statuses');

            const tasks=[
                renderQuickStats().then(x=>setDashHtml('dash-stats',x)),
                renderNotifications().then(x=>setDashHtml('dash-notifications',x)),
                renderFamilySection().then(x=>setDashHtml('dash-family',x))
            ];
            setDashHtml('dash-completeness',renderProfileCompleteness());

            if(mode==='volunteer'){
                setDashHtml('dash-criteria',renderVolunteerCriteriaSummary());
                tasks.push(renderVolunteerScoreCard().then(x=>setDashHtml('dash-score',x)));
                tasks.push(renderMyRegistrations().then(x=>setDashHtml('dash-main-a',x)));
                tasks.push(renderMatchingEvents().then(x=>{setDashHtml('dash-main-b',x);setTimeout(initializeInlineMatchingMaps,0);}));
                if(currentProfile.role==='volunteer'){
                    setDashHtml('dash-cta','<div class="glass-card p-6 flex flex-wrap gap-3 items-center justify-between"><div><h3 class="font-bold text-lg">יש לך גם אירוע?</h3><p class="text-sm text-slate-500">אותו חשבון יכול לשמש גם כבעל שמחה.</p></div><button onclick="openAddEvent()" class="btn-dark px-4 py-2">פרסם אירוע</button></div>');
                }
            }else{
                tasks.push(renderHostEvents().then(x=>setDashHtml('dash-main-a',x)));
                if(currentProfile.role==='host'){
                    setDashHtml('dash-cta','<div class="glass-card p-6 flex flex-wrap gap-3 items-center justify-between"><div><h3 class="font-bold text-lg">רוצה גם לשמח?</h3><p class="text-sm text-slate-500">השלם שנת לידה, כתובת והעדפות ונפתח לך אזור משמח.</p></div><button onclick="openProfileSettings()" class="btn-brand px-4 py-2">הגדר פרטי משמח</button></div>');
                }
            }

            const adminPromise=_supabase.rpc('is_admin').then(async({data})=>{
                currentIsAdmin=!!data;
                if(currentIsAdmin) setDashHtml('dash-admin',await renderAdminPanel());
            });
            tasks.push(adminPromise);
            await Promise.allSettled(tasks);
        }

        async function renderFamilySection(){
            const {data,error}=await _supabase.rpc('get_family_children');
            if(error)return '<div class="glass-card p-5"><h3 class="font-bold">המשפחה שלי</h3><p class="text-sm text-slate-500 mt-1">לא הצלחנו לטעון כרגע.</p></div>';
            familyChildrenCache=data||[];
            return '<div class="glass-card p-6"><div class="flex flex-wrap justify-between gap-3 items-center"><div><h3 class="text-xl font-bold">'+esc(siteText('family_title','המשפחה שלי'))+'</h3><p class="text-sm text-slate-500">'+esc(siteText('family_subtitle','אפשר להוסיף ילד/ה בגיל 12–17 לחשבון רק אם תרצה/י. הילד/ה לא מקבל/ת חשבון נפרד.'))+'</p></div><button onclick="openFamilyChildForm()" class="btn-soft px-4 py-2"><i class="fa-solid fa-user-plus ml-1"></i> הוסף ילד/ה</button></div>'+
                (familyChildrenCache.length?'<div class="grid grid-cols-1 md:grid-cols-2 gap-3 mt-5">'+familyChildrenCache.map(c=>'<div class="border rounded-xl p-4 bg-slate-50"><div class="flex justify-between gap-3"><div><div class="font-bold text-lg">'+esc(c.full_name)+'</div><div class="text-sm text-slate-500">'+esc(adminGenderLabel(c.gender))+' · גיל '+(new Date().getFullYear()-Number(c.birth_year||0))+' · '+esc(eventTypeListLabel(c.volunteer_event_type_preferences))+'</div><div class="text-xs text-slate-400 mt-1">הרשמות פעילות: '+Number(c.active_registrations||0)+'</div></div><button onclick="openFamilyChildArea(\''+esc(c.id)+'\')" class="btn-brand px-3 py-2 text-sm">ניהול</button></div></div>').join('')+'</div>':'<div class="mt-4 text-sm text-slate-500">לא נוספו ילדים לחשבון. אין צורך להגדיר דבר אם האפשרות הזאת לא רלוונטית לך.</div>')+
            '</div>';
        }

        function syncFamilyChildEventDefault(){
            const current=checkedValues('family-event-type');
            if(current.length)return;
            const gender=$('family-child-gender')?.value;
            setCheckedValues('family-event-type',gender==='female'?['bat_mitzvah']:gender==='male'?['bar_mitzvah']:[]);
        }

        function fillFamilyChildForm(child=null){
            populateFamilyBirthYears();
            $('family-child-id').value=child?.id||'';
            $('family-form-title').textContent=child?'עריכת '+child.full_name:'הוספת ילד/ה לחשבון';
            $('family-child-name').value=child?.full_name||'';
            $('family-child-gender').value=child?.gender||'';
            $('family-child-birth-year').value=child?.birth_year||'';
            $('family-child-sector').value=child?.sector||(currentProfile?.sector&&currentProfile.sector!=='all'?currentProfile.sector:'');
            $('family-child-city').value=child?.city||currentProfile?.city||'';
            $('family-child-street').value=child?.street||currentProfile?.street||'';
            $('family-child-house-number').value=child?.house_number||currentProfile?.house_number||'';
            $('family-child-radius').value=radiusChoiceValue(child?.radius||currentProfile?.radius||10);
            $('family-child-transport').value=child?.transport_mode||currentProfile?.transport_mode||'car';
            $('family-child-separation').checked=child?!!child.strict_separation:!!currentProfile?.strict_separation;
            setCheckedValues('family-available-day',child?.availability_days||currentProfile?.availability_days||[0,1,2,3,4]);
            $('family-child-from').value=child?.availability_from?.slice(0,5)||currentProfile?.availability_from?.slice(0,5)||'';
            $('family-child-until').value=child?.availability_until?.slice(0,5)||currentProfile?.availability_until?.slice(0,5)||'';
            setCheckedValues('family-event-type',child?.volunteer_event_type_preferences||[]);
            if(!child)syncFamilyChildEventDefault();
            const consent=$('family-guardian-consent-wrap');
            if(consent)consent.classList.toggle('hidden',!!child);
            $('family-guardian-consent').checked=!!child;
        }

        async function openFamilyChildForm(childId=null){
            if(!currentProfile)await loadProfile();
            const child=childId?familyChildrenCache.find(x=>x.id===childId):null;
            if(childId&&!child){
                const {data}=await _supabase.rpc('get_family_children');
                familyChildrenCache=data||[];
            }
            fillFamilyChildForm(childId?familyChildrenCache.find(x=>x.id===childId):null);
            navigate('family-child-form');
        }

        async function saveFamilyChild(){
            setBusy('family-child-submit',true,'שומר...');
            try{
                const id=$('family-child-id').value||null;
                const name=$('family-child-name').value.trim();
                const gender=$('family-child-gender').value;
                const birthYear=Number($('family-child-birth-year').value);
                const sector=$('family-child-sector').value;
                const eventTypes=checkedValues('family-event-type');
                const city=$('family-child-city').value.trim();
                const street=$('family-child-street').value.trim();
                const number=$('family-child-house-number').value.trim();
                const radius=Number($('family-child-radius').value);
                const days=checkedNumbers('family-available-day');
                const from=$('family-child-from').value||null;
                const until=$('family-child-until').value||null;
                const transport=$('family-child-transport').value;
                const separation=!!$('family-child-separation').checked;
                const age=new Date().getFullYear()-birthYear;
                if(age<12||age>=18)throw new Error('family_child_age_required');
                if(!eventTypes.length)throw new Error('minor_event_types_only');
                if(!days.length)throw new Error('יש לבחור לפחות יום זמינות אחד.');
                if(!city||!street||!number)throw new Error('address_incomplete');
                if(!id&&!$('family-guardian-consent').checked)throw new Error('guardian_required');
                const coords=await verifyTypedAddress(city,street,number);
                let result;
                if(id){
                    result=await _supabase.rpc('update_family_child_v2',{
                        p_child_id:id,p_full_name:name,p_gender:gender,p_birth_year:birthYear,p_sector:sector,
                        p_event_type_preferences:eventTypes,p_city:city,p_street:street,p_house_number:number,
                        p_radius:radius,p_availability_days:days,p_availability_from:from,p_availability_until:until,
                        p_transport_mode:transport,p_strict_separation:separation,p_lat:coords.lat,p_lng:coords.lng
                    });
                }else{
                    result=await _supabase.rpc('add_family_child_v2',{
                        p_full_name:name,p_gender:gender,p_birth_year:birthYear,p_sector:sector,
                        p_event_type_preferences:eventTypes,p_city:city,p_street:street,p_house_number:number,
                        p_radius:radius,p_availability_days:days,p_availability_from:from,p_availability_until:until,
                        p_transport_mode:transport,p_strict_separation:separation,p_lat:coords.lat,p_lng:coords.lng,
                        p_guardian_consent:true
                    });
                }
                if(result.error)throw result.error;
                showToast(id?'פרטי הילד/ה עודכנו.':'הילד/ה נוסף/ה לחשבון.','success');
                await loadDashboard();
            }catch(e){showToast(String(e?.message||'').includes('לפחות יום')?String(e.message):readableError(e),'error');}
            finally{setBusy('family-child-submit',false);}
        }

        async function openFamilyChildArea(childId){
            activeFamilyChildId=childId;
            let child=familyChildrenCache.find(x=>x.id===childId);
            if(!child){
                const {data,error}=await _supabase.rpc('get_family_children');
                if(error)return showToast(readableError(error),'error');
                familyChildrenCache=data||[];
                child=familyChildrenCache.find(x=>x.id===childId);
            }
            if(!child)return showToast('לא מצאתי את הילד/ה בחשבון.','error');
            $('family-child-area-title').textContent=child.full_name;
            $('family-child-edit-button').onclick=()=>openFamilyChildForm(child.id);
            navigate('family-child-area');
            const box=$('family-child-area-content');
            box.innerHTML='<div class="dashboard-skeleton">טוען אירועים...</div>';
            const [{data:regs,error:rErr},{data:matches,error:mErr}]=await Promise.all([
                _supabase.rpc('get_family_child_registrations',{p_child_id:child.id}),
                _supabase.rpc('get_family_child_matching_events',{p_child_id:child.id})
            ]);
            if(rErr||mErr){box.innerHTML='<div class="glass-card p-6 text-red-700">לא הצלחנו לטעון את נתוני הילד/ה כרגע.</div>';return;}
            const today=new Date().toISOString().slice(0,10);
            const activeRegs=(regs||[]).filter(r=>r.event_date>=today&&r.event_status!=='cancelled');
            box.innerHTML=
                '<div class="glass-card p-6"><div class="flex flex-wrap justify-between gap-3"><div><h3 class="text-xl font-bold">ההתנדבויות של '+esc(child.full_name)+'</h3><p class="text-sm text-slate-500">כל הפעולות מנוהלות מהחשבון שלך וה-SMS נשלח לטלפון שלך.</p></div><button onclick="deleteFamilyChild(\''+esc(child.id)+'\')" class="bg-red-50 text-red-700 border border-red-200 rounded-lg px-3 py-2 text-sm font-bold">הסר מהחשבון</button></div><div class="space-y-3 mt-4">'+
                (activeRegs.length?activeRegs.map(r=>'<div class="border rounded-xl p-4 bg-slate-50"><div class="flex flex-wrap justify-between gap-3"><div><b>'+esc(r.event_name)+'</b><div class="text-sm text-slate-500">'+esc(eventTypeLabel(r.event_type))+' · '+esc(formatDate(r.event_date))+' · '+esc(timeRange(r.start_time,r.close_time))+'</div><div class="text-sm text-brand-700 mt-1">📍 '+esc((r.hall_name?r.hall_name+' · ':'')+(r.hall_address||fullAddress(r.city,r.street,r.house_number)))+'</div></div><div class="flex flex-wrap gap-2"><button onclick="openEventChat(\''+esc(r.event_id)+'\')" class="btn-soft px-3 py-2 text-xs">צ׳אט</button>'+(!r.attendance_confirmed_at?'<button onclick="confirmFamilyChildAttendance(\''+esc(child.id)+'\',\''+esc(r.event_id)+'\')" class="btn-brand px-3 py-2 text-xs">אישור הגעה</button>':'')+'<button onclick="cancelFamilyChildRegistration(\''+esc(child.id)+'\',\''+esc(r.event_id)+'\')" class="bg-red-50 text-red-700 rounded-lg px-3 py-2 text-xs font-bold">ביטול</button></div></div></div>').join(''):'<p class="text-slate-500">אין כרגע הרשמות פעילות.</p>')+
                '</div></div>'+
                '<div class="glass-card p-6"><h3 class="text-xl font-bold">אירועים שמתאימים ל'+esc(child.full_name)+'</h3><p class="text-sm text-slate-500 mt-1">מוצגים רק אירועי בר/בת מצווה שעומדים בכל הקריטריונים שהוגדרו.</p><div class="space-y-3 mt-4">'+
                ((matches||[]).length?(matches||[]).map(e=>'<div class="border rounded-xl p-4 bg-slate-50"><div class="flex flex-wrap justify-between gap-3"><div><b>'+esc(e.event_name)+'</b><div class="text-sm text-slate-500">'+esc(eventTypeLabel(e.event_type))+' · '+esc(formatDate(e.event_date))+' · '+esc(timeRange(e.start_time,e.close_time))+' · '+esc(e.distance_km)+' ק״מ</div><div class="text-sm text-brand-700 mt-1">📍 '+esc((e.hall_name?e.hall_name+' · ':'')+e.hall_address)+'</div>'+(e.exact_lat==null?'<div class="text-xs text-slate-500 mt-1">הכתובת המדויקת תוצג לאחר ההרשמה.</div>':'')+'</div><button onclick="registerFamilyChildForEvent(\''+esc(child.id)+'\',\''+esc(e.id)+'\')" class="btn-brand px-4 py-2 text-sm">רשום/י לאירוע</button></div></div>').join(''):'<p class="text-slate-500">אין כרגע אירועים מתאימים.</p>')+
                '</div></div>';
        }

        async function registerFamilyChildForEvent(childId,eventId){
            const child=familyChildrenCache.find(x=>x.id===childId);
            const ok=await askConfirm('רישום לאירוע','לרשום את '+(child?.full_name||'הילד/ה')+' לאירוע?','כן, רשום/י');
            if(!ok)return;
            const {error}=await _supabase.rpc('register_family_child_for_event',{p_child_id:childId,p_event_id:eventId});
            if(error)return showToast(readableError(error),'error');
            showToast('ההרשמה בוצעה.','success');await openFamilyChildArea(childId);
        }

        async function cancelFamilyChildRegistration(childId,eventId){
            const ok=await askConfirm('ביטול הרשמה','לבטל את הרשמת הילד/ה לאירוע?','בטל הרשמה');
            if(!ok)return;
            const {error}=await _supabase.rpc('cancel_family_child_registration',{p_child_id:childId,p_event_id:eventId});
            if(error)return showToast(readableError(error),'error');
            showToast('ההרשמה בוטלה.','success');await openFamilyChildArea(childId);
        }

        async function confirmFamilyChildAttendance(childId,eventId){
            const {error}=await _supabase.rpc('confirm_family_child_attendance',{p_child_id:childId,p_event_id:eventId});
            if(error)return showToast(readableError(error),'error');
            showToast('ההגעה אושרה.','success');await openFamilyChildArea(childId);
        }

        async function deleteFamilyChild(childId){
            const child=familyChildrenCache.find(x=>x.id===childId);
            const ok=await askConfirm('הסרת ילד/ה מהחשבון','להסיר את '+(child?.full_name||'הילד/ה')+' מהחשבון? הרשמות פעילות יבוטלו.','הסר');
            if(!ok)return;
            const {error}=await _supabase.rpc('delete_family_child',{p_child_id:childId});
            if(error)return showToast(readableError(error),'error');
            showToast('הילד/ה הוסר/ה מהחשבון.','success');activeFamilyChildId=null;await loadDashboard();
        }

        function openSupport(subject=''){
            navigate('support');
            if(currentProfile){
                if($('support-name'))$('support-name').value=currentProfile.full_name||'';
                if($('support-phone'))$('support-phone').value=displayPhone(currentProfile.phone||'');
            }
            if(subject&&$('support-subject')){
                $('support-subject').value=subject;
                announceA11y('נושא הפנייה נקבע ל'+subject);
            }
        }

        async function submitSupportRequest(){
            setBusy('support-submit',true,'שולח...');
            try{
                const name=$('support-name').value.trim();
                const phone=$('support-phone').value.trim();
                const subject=$('support-subject').value.trim();
                const message=$('support-message').value.trim();
                if(name.length<2||message.length<5)throw new Error('invalid_support_request');
                const normalized=normalizePhone(phone);
                if(!isValidPhone(normalized))throw new Error('invalid_phone');
                const res=await fetch(SUPABASE_URL+'/functions/v1/support-contact',{
                    method:'POST',
                    headers:{'Content-Type':'application/json','apikey':SUPABASE_PUBLISHABLE_KEY},
                    body:JSON.stringify({name,phone:normalized,subject,message})
                });
                const json=await res.json().catch(()=>({}));
                if(!res.ok)throw new Error(json?.error||'server_error');
                $('support-form')?.reset();
                if(currentProfile){
                    $('support-name').value=currentProfile.full_name||'';
                    $('support-phone').value=displayPhone(currentProfile.phone||'');
                }
                showToast('הפנייה נשלחה למנהל המערכת.','success');
                navigate('home');
            }catch(e){showToast(readableError(e),'error');}
            finally{setBusy('support-submit',false);}
        }

        async function renderNotifications() {
            const {data,error}=await _supabase.from('notifications').select('*').order('created_at',{ascending:false}).limit(8);
            if(error||!data?.length) return '';
            const unread=data.filter(n=>!n.read_at).length;
            return '<div class="glass-card p-6"><div class="flex justify-between items-center mb-4"><h3 class="text-xl font-bold">התראות '+(unread?'<span class="text-sm text-brand-600">('+unread+' חדשות)</span>':'')+'</h3>'+(unread?'<button onclick="markNotificationsRead()" class="text-sm font-bold text-brand-600 hover:underline">סמן הכול כנקרא</button>':'')+'</div><div class="space-y-3">'+data.map(n=>'<div class="p-3 rounded-lg border '+(n.read_at?'bg-white border-slate-100':'bg-brand-50 border-brand-100')+'"><div class="font-bold text-sm">'+esc(n.title)+'</div><div class="text-sm text-slate-600">'+esc(n.body)+'</div></div>').join('')+'</div></div>';
        }

        async function markNotificationsRead(){
            const {error}=await _supabase.rpc('mark_my_notifications_read');
            if(error)return showToast(readableError(error),'error');
            setDashHtml('dash-notifications',await renderNotifications());
        }

        async function fetchMyRegistrations(){
            const {data,error}=await _supabase.rpc('get_my_registrations_v2');
            if(error) return [];
            return data||[];
        }

        function eventCacheKey(ev){ return ev.event_id||ev.id; }

        function rememberEventForLinks(ev){
            const id=eventCacheKey(ev);
            if(id) calendarEventCache.set(id,{...ev,id,event_id:id,exact_address:ev.hall_address||ev.exact_address||''});
            return id;
        }

        function externalNavButtons(ev){
            if(ev.exact_lat==null||ev.exact_lng==null) return '';
            const eventId=rememberEventForLinks(ev);
            const origin=currentProfile.lat+','+currentProfile.lng;
            const dest=ev.exact_lat+','+ev.exact_lng;
            const travel=currentProfile.transport_mode==='transit'?'transit':'driving';
            const google='https://www.google.com/maps/dir/?api=1&origin='+encodeURIComponent(origin)+'&destination='+encodeURIComponent(dest)+'&travelmode='+travel;
            const waze='https://waze.com/ul?ll='+encodeURIComponent(dest)+'&navigate=yes&utm_source=smachim';
            return '<div class="flex flex-wrap gap-2 mt-2"><a target="_blank" rel="noopener" href="'+google+'" class="btn-soft px-3 py-1.5 text-xs"><i class="fa-brands fa-google ml-1"></i> Google Maps</a><a target="_blank" rel="noopener" href="'+waze+'" class="btn-soft px-3 py-1.5 text-xs"><i class="fa-brands fa-waze ml-1"></i> Waze</a><button type="button" onclick="openMoovitEvent(\''+esc(eventId)+'\')" class="btn-soft px-3 py-1.5 text-xs">Moovit</button></div>';
        }

        async function openMoovitEvent(eventId){
            const ev=calendarEventCache.get(eventId)||matchingEventsCache.find(x=>x.id===eventId)||hostEventsCache.get(eventId);
            if(!ev) return;
            const address=(ev.hall_name?ev.hall_name+' · ':'')+(ev.hall_address||ev.exact_address||fullAddress(ev.city,ev.street,ev.house_number));
            if(ev.exact_lat!=null&&ev.exact_lng!=null){
                const url='https://moovit.com/?to='+encodeURIComponent(address)+'&tll='+encodeURIComponent(ev.exact_lat+'_'+ev.exact_lng)+'&lang=he';
                window.open(url,'_blank','noopener');
            }else{
                try{await navigator.clipboard.writeText(address||'');}catch(_){}
                window.open('https://moovit.com/','_blank','noopener');
            }
        }

        function resolveEventName(eventId){
            return matchingEventsCache.find(x=>x.id===eventId)?.event_name
                || hostEventsCache.get(eventId)?.event_name
                || calendarEventCache.get(eventId)?.event_name
                || 'אירוע';
        }

        async function confirmAttendance(eventId){
            const {error}=await _supabase.rpc('confirm_attendance',{p_event_id:eventId});
            if(error) return showToast(readableError(error),'error');
            showToast('ההגעה אושרה. תודה!','success');
            setDashHtml('dash-main-a',await renderMyRegistrations());
        }

        async function renderMyRegistrations(){
            const regs=await fetchMyRegistrations();
            if(!regs.length) return '<div class="glass-card p-6"><h3 class="text-xl font-bold mb-2">ההתנדבויות שלי</h3><p class="text-slate-500">עדיין לא נרשמת לאירוע.</p></div>';

            const today=new Date().toISOString().slice(0,10);
            const upcoming=regs.filter(r=>r.event_date>=today&&r.event_status!=='cancelled');
            const history=regs.filter(r=>!upcoming.includes(r));

            const cards=(list,historyMode=false)=>list.map(r=>{
                calendarEventCache.set(r.event_id,{...r,exact_address:r.hall_address||'',couple_names:r.event_name});
                const confirmed=!!r.attendance_confirmed_at;
                return '<div class="border p-4 rounded-xl bg-slate-50"><div class="flex flex-wrap gap-4 justify-between items-start"><div><div class="flex gap-2 items-center flex-wrap"><h4 class="font-bold text-lg">'+esc(r.event_name)+'</h4><span class="status-pill bg-green-50 text-green-700">רשום</span>'+(confirmed?'<span class="status-pill bg-brand-50 text-brand-700">הגעה אושרה ✓</span>':'')+'</div><p class="text-xs font-bold text-slate-500 mt-1">'+esc(eventTypeLabel(r.event_type))+'</p><p class="text-sm text-slate-600 mt-1">📅 '+esc(relativeDateLabel(r.event_date))+' · '+formatDate(r.event_date)+' · ⏰ '+esc(timeRange(r.start_time,r.close_time))+'</p><p class="text-sm font-semibold text-brand-700 mt-1">📍 '+esc((r.hall_name?r.hall_name+' · ':'')+(r.hall_address||fullAddress(r.city,r.street,r.house_number)))+'</p>'+externalNavButtons(r)+'</div><div class="flex flex-wrap gap-2"><button onclick="openEventChat(\''+esc(r.event_id)+'\')" class="btn-brand px-3 py-1.5 text-xs"><i class="fa-regular fa-comments ml-1"></i> צ׳אט</button><button onclick="downloadCalendar(\''+esc(r.event_id)+'\')" class="btn-soft px-3 py-1.5 text-xs">יומן</button>'+(!confirmed&&!historyMode?'<button onclick="confirmAttendance(\''+esc(r.event_id)+'\')" class="btn-soft px-3 py-1.5 text-xs">אשר הגעה</button>':'')+(!historyMode&&r.event_status!=='cancelled'?'<button onclick="cancelMyRegistration(\''+esc(r.event_id)+'\')" class="bg-red-50 text-red-600 px-3 py-1.5 rounded-lg font-bold text-xs">בטל הרשמה</button>':'')+'</div></div></div>';
            }).join('');

            return '<div class="glass-card p-6"><div class="flex justify-between items-center mb-4"><h3 class="text-xl font-bold">ההתנדבויות שלי</h3><span class="text-xs text-slate-500">'+upcoming.length+' קרובות</span></div><div class="space-y-4">'+(upcoming.length?cards(upcoming):'<p class="text-slate-500">אין כרגע התנדבויות קרובות.</p>')+'</div>'+(history.length?'<details class="mt-5 border-t pt-4"><summary class="cursor-pointer font-bold text-sm text-slate-600">היסטוריה ('+history.length+')</summary><div class="space-y-3 mt-3">'+cards(history,true)+'</div></details>':'')+'</div>';
        }

        async function renderInlineEventMap(eventId){
            const ev=matchingEventsCache.find(x=>x.id===eventId);
            const mapEl=$('route-map-'+eventId),stats=$('route-stats-'+eventId);
            if(!ev||!mapEl||routeMapInstances.has(eventId))return;
            if(typeof L==='undefined'||ev.exact_lat==null||ev.exact_lng==null||currentProfile.lat==null||currentProfile.lng==null){
                if(stats)stats.textContent='המפה אינה זמינה כרגע.';return;
            }
            const map=L.map(mapEl,{scrollWheelZoom:false,zoomControl:true});
            routeMapInstances.set(eventId,map);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap contributors'}).addTo(map);
            const home=[Number(currentProfile.lat),Number(currentProfile.lng)],hall=[Number(ev.exact_lat),Number(ev.exact_lng)];
            L.marker(home).addTo(map).bindPopup('הבית שלי');
            L.marker(hall).addTo(map).bindPopup(esc(ev.hall_name||'האולם')+'<br>'+esc(ev.hall_address||''));
            map.fitBounds(L.latLngBounds([home,hall]),{padding:[28,28]});
            setTimeout(()=>map.invalidateSize(),80);
            try{
                const url='https://router.project-osrm.org/route/v1/driving/'+home[1]+','+home[0]+';'+hall[1]+','+hall[0]+'?overview=full&geometries=geojson';
                const res=await fetch(url),json=await res.json(),route=json?.routes?.[0];
                if(!route)throw new Error('route');
                const layer=L.geoJSON(route.geometry,{weight:5,opacity:.75}).addTo(map);
                map.fitBounds(layer.getBounds(),{padding:[26,26]});
                if(stats)stats.innerHTML='<b>מרחק אווירי:</b> '+esc(ev.distance_km)+' ק״מ · <b>מרחק בכביש:</b> '+(route.distance/1000).toFixed(1)+' ק״מ · <b>זמן נסיעה משוער:</b> '+Math.round(route.duration/60)+' דקות';
            }catch(_){
                L.polyline([home,hall],{dashArray:'6,8'}).addTo(map);
                if(stats)stats.innerHTML='<b>מרחק אווירי:</b> '+esc(ev.distance_km)+' ק״מ · מסלול כביש לא זמין כרגע.';
            }
        }

        function initializeInlineMatchingMaps(){
            if(matchingMapObserver){matchingMapObserver.disconnect();matchingMapObserver=null;}
            const nodes=[...document.querySelectorAll('[data-event-map]')];
            if(!('IntersectionObserver' in window)){nodes.forEach(el=>renderInlineEventMap(el.dataset.eventMap));return;}
            matchingMapObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{
                if(entry.isIntersecting){
                    renderInlineEventMap(entry.target.dataset.eventMap);
                    matchingMapObserver.unobserve(entry.target);
                }
            }),{rootMargin:'500px 0px'});
            nodes.forEach(el=>matchingMapObserver.observe(el));
        }

        function matchingCards(events){
            return events.map(ev=>{
                const count=currentProfile.gender==='male'?Number(ev.men_registered):Number(ev.women_registered);
                const quota=currentProfile.gender==='male'?Number(ev.quota_men):Number(ev.quota_women);
                const available=Math.max(quota-count,0);
                const ageRange=ev.age_min==null&&ev.age_max==null?'ללא הגבלת גיל':(ev.age_min??'—')+'–'+(ev.age_max??'—');
                const exact=(ev.hall_name?ev.hall_name+' · ':'')+(ev.hall_address||fullAddress(ev.city,ev.street,ev.house_number));
                const hasExact=ev.exact_lat!=null&&ev.exact_lng!=null;
                const locationSection=hasExact
                    ? '<div class="mt-4 border-t pt-4"><div id="route-map-'+esc(ev.id)+'" data-event-map="'+esc(ev.id)+'" class="route-map" role="region" tabindex="0" aria-label="מפת מסלול לאירוע '+esc(ev.event_name)+'" aria-describedby="route-stats-'+esc(ev.id)+'"></div><div id="route-stats-'+esc(ev.id)+'" class="text-sm text-slate-600 mt-3" role="status" aria-live="polite"><b>מרחק אווירי:</b> '+esc(ev.distance_km)+' ק״מ · מחשב מסלול...</div>'+externalNavButtons(ev)+'</div>'
                    : '<div class="mt-4 border-t pt-4 text-sm text-slate-500"><i class="fa-solid fa-location-dot ml-1"></i>הכתובת המדויקת והניווט יוצגו לאחר הרשמה לאירוע.</div>';
                return '<div class="border p-4 rounded-xl bg-slate-50"><div class="flex flex-col md:flex-row gap-4 md:justify-between md:items-start"><div class="min-w-0"><div class="flex gap-2 items-center flex-wrap"><h4 class="font-bold text-lg">'+esc(ev.event_name)+'</h4><span class="status-pill bg-white border text-slate-600">'+esc(relativeDateLabel(ev.event_date))+'</span><span class="status-pill bg-brand-50 text-brand-700">'+esc(eventTypeLabel(ev.event_type))+'</span></div><p class="text-sm text-slate-500 mt-1">בעל השמחה: <b>'+esc(ev.host_name)+'</b></p><p class="text-sm text-slate-600 mt-1">📅 '+dayName(ev.event_date)+' · '+formatDate(ev.event_date)+' · ⏰ '+esc(timeRange(ev.start_time,ev.close_time))+'</p><p class="text-sm font-bold text-brand-700 mt-1">📍 '+esc(exact)+'</p><p class="text-xs text-slate-600 mt-2"><b>מרחק אווירי:</b> '+esc(ev.distance_km)+' ק״מ · <b>הרשמה עד:</b> '+esc(formatDateTime(ev.registration_deadline))+'</p><p class="text-xs text-brand-700 font-semibold mt-1"><i class="fa-solid fa-circle-check ml-1"></i>התאמה מלאה: מגזר אירוע '+esc(sectorLabel(ev.sector_pref))+' · מגזרי משמחים '+esc(sectorListLabel(ev.accepted_volunteer_sectors))+' · '+(ev.is_separated?'הפרדה מלאה':'ללא הפרדה')+' · גיל '+esc(ageRange)+'</p><p class="text-xs text-slate-500 mt-1">נותרו '+available+' מקומות במכסה שלך · משמחים '+ev.men_registered+'/'+ev.quota_men+' · משמחות '+ev.women_registered+'/'+ev.quota_women+'</p>'+(ev.volunteer_note?'<div class="mt-2 bg-white border rounded-lg p-2 text-sm"><b>הערת בעל השמחה:</b> '+esc(ev.volunteer_note)+'</div>':'')+'</div><div class="flex flex-wrap gap-2 shrink-0"><button onclick="rsvpEvent(\''+esc(ev.id)+'\')" class="btn-brand px-4 py-2 text-sm">הירשם לשמח</button><button onclick="reportEvent(\''+esc(ev.id)+'\')" class="btn-soft px-3 py-2 text-sm" aria-label="דווח על האירוע '+esc(ev.event_name)+'"><i class="fa-regular fa-flag" aria-hidden="true"></i></button></div></div>'+locationSection+'</div>';
            }).join('');
        }

        function applyMatchingFilters(){
            const sort=$('match-sort')?.value||'date';
            let events=[...matchingEventsCache];
            if(sort==='distance') events.sort((a,b)=>(a.distance_km??99999)-(b.distance_km??99999));
            else if(sort==='availability') events.sort((a,b)=>{
                const ac=currentProfile.gender==='male'?Number(a.quota_men)-Number(a.men_registered):Number(a.quota_women)-Number(a.women_registered);
                const bc=currentProfile.gender==='male'?Number(b.quota_men)-Number(b.men_registered):Number(b.quota_women)-Number(b.women_registered);
                return bc-ac;
            });
            else events.sort((a,b)=>String(a.event_date).localeCompare(String(b.event_date))||String(a.start_time).localeCompare(String(b.start_time)));
            if($('matching-list')) $('matching-list').innerHTML=events.length?matchingCards(events):'<p class="text-slate-500">אין כרגע אירועים שעומדים בכל הקריטריונים שלך.</p>';
            routeMapInstances.forEach(m=>{try{m.remove();}catch(_){}});routeMapInstances.clear();
            setTimeout(initializeInlineMatchingMaps,0);
        }

        async function renderMatchingEvents(){
            const {data:events,error}=await _supabase.rpc('get_matching_events_v2');
            if(error) return '<div class="glass-card p-6"><h3 class="text-xl font-bold mb-2">אירועים שמתאימים לך</h3><p class="text-slate-600">לא הצלחנו לטעון התאמות כרגע.</p></div>';
            matchingEventsCache=events||[];
            return '<div class="glass-card p-6"><div class="flex flex-wrap gap-3 justify-between items-start mb-4"><div><h3 class="text-xl font-bold">אירועים שמתאימים לך</h3><p class="text-sm text-slate-500">מוצגים רק אירועים שעומדים בכל הקריטריונים של שני הצדדים: מין ומכסה, גיל, מגזר, הפרדה, רדיוס, זמינות, דדליין והתנגשויות.</p></div><select id="match-sort" onchange="applyMatchingFilters()" class="input-clean bg-white !w-auto text-sm"><option value="date">לפי תאריך</option><option value="distance">הכי קרוב</option><option value="availability">הכי הרבה מקום</option></select></div><div id="matching-list" class="space-y-4">'+(matchingEventsCache.length?matchingCards(matchingEventsCache):'<p class="text-slate-500">אין כרגע אירועים שעומדים בכל הקריטריונים שלך. אפשר לשנות רדיוס, מגזרים או זמינות בהגדרות.</p>')+'</div></div>';
        }

        async function reportEvent(eventId){
            const reason=await askText('דיווח על אירוע','כתוב בקצרה מה הבעיה באירוע.','סיבת הדיווח');
            if(!reason) return;
            const {error}=await _supabase.rpc('report_event',{p_event_id:eventId,p_reason:reason});
            if(error) showToast(readableError(error),'error'); else showToast('הדיווח נשלח למנהל המערכת.','success');
        }

        async function rsvpEvent(eventId){
            const ev=matchingEventsCache.find(e=>e.id===eventId);
            const text=ev?'להירשם ל־'+ev.event_name+'\nבעל השמחה: '+ev.host_name+'\n'+formatDate(ev.event_date)+' · '+timeRange(ev.start_time,ev.close_time)+'\n'+(ev.hall_name?ev.hall_name+' · ':'')+ev.hall_address+(ev.exact_lat==null?'\nהכתובת המדויקת תוצג מיד לאחר ההרשמה.':''):'להירשם לאירוע הזה?';
            const ok=await askConfirm('אישור הרשמה',text,'כן, הירשם');
            if(!ok) return;
            const {error}=await _supabase.rpc('register_for_event',{p_event_id:eventId});
            if(error) return showToast(readableError(error),'error');
            showToast('נרשמת בהצלחה! הצ׳אט הקבוצתי של האירוע נפתח עבורך.','success');
            await loadDashboard();
        }

        async function cancelMyRegistration(eventId){
            const ok=await askConfirm('ביטול הרשמה','לבטל את ההרשמה לאירוע? לאחר הביטול לא תהיה גישה לצ׳אט האירוע.','בטל הרשמה');
            if(!ok) return;
            const {error}=await _supabase.rpc('cancel_registration',{p_event_id:eventId});
            if(error) showToast(readableError(error),'error'); else {showToast('ההרשמה בוטלה.');await loadDashboard();}
        }

        async function renderHostEvents(){
            const {data:events,error}=await _supabase.rpc('get_host_events_v3');
            if(error) return '<div class="glass-card p-6"><h3 class="text-xl font-bold">האירועים שלי</h3><p class="text-slate-500 mt-2">לא הצלחנו לטעון את האירועים כרגע.</p></div>';
            hostEventsCache=new Map((events||[]).map(e=>[e.id,e]));
            return '<div class="glass-card p-6"><div class="flex flex-wrap gap-3 justify-between items-center mb-4"><div><h3 class="text-xl font-bold">האירועים שלי</h3><p class="text-sm text-slate-500">ניהול נרשמים, קריטריונים, צ׳אט ואישורי הגעה.</p></div><button onclick="openAddEvent()" class="btn-dark px-4 py-2 text-sm"><i class="fa-solid fa-plus ml-1"></i> אירוע חדש</button></div><div class="space-y-4">'+((events||[]).length?(events||[]).map(e=>{
                calendarEventCache.set(e.id,{...e,exact_address:e.hall_address,couple_names:e.event_name});
                const total=Number(e.approved_men)+Number(e.approved_women),quota=Number(e.quota_men)+Number(e.quota_women);
                const pct=quota?Math.min(100,Math.round(total/quota*100)):0;
                const age=e.age_min==null&&e.age_max==null?'לא משנה':(e.age_min??'—')+'–'+(e.age_max??'—');
                return '<div class="border p-4 rounded-xl bg-slate-50"><div class="flex flex-col md:flex-row gap-4 md:justify-between md:items-start"><div><div class="flex flex-wrap gap-2 items-center"><h4 class="font-bold text-lg">'+esc(e.event_name)+'</h4><span class="status-pill bg-white border text-slate-600">'+esc(eventStatusLabel(e))+'</span><span class="status-pill bg-brand-50 text-brand-700">'+esc(eventTypeLabel(e.event_type))+'</span></div><p class="text-sm text-slate-600 mt-1">📅 '+formatDate(e.event_date)+' · '+esc(timeRange(e.start_time,e.close_time))+' · הרשמה עד '+esc(formatDateTime(e.registration_deadline))+'</p><p class="text-sm font-semibold text-brand-700 mt-1">📍 '+esc((e.hall_name?e.hall_name+' · ':'')+e.hall_address)+'</p><p class="text-xs text-slate-600 mt-2">מגזר אירוע: '+esc(sectorLabel(e.sector_pref))+' · משמחים: '+esc(sectorListLabel(e.accepted_volunteer_sectors))+' · גיל: '+esc(age)+' · '+(e.is_separated?'הפרדה מלאה':'ללא הפרדה')+'</p><div class="mt-3 max-w-md"><div class="flex justify-between text-xs text-slate-600 mb-1"><span>נרשמו '+total+'/'+quota+'</span><span>'+pct+'%</span></div><div class="progress-track"><div class="progress-fill" style="width:'+pct+'%"></div></div><p class="text-xs text-slate-500 mt-1">משמחים '+e.approved_men+'/'+e.quota_men+' (אישרו שמגיעים '+e.confirmed_men+', אושרו בפועל '+e.verified_men+') · משמחות '+e.approved_women+'/'+e.quota_women+' (אישרו שמגיעות '+e.confirmed_women+', אושרו בפועל '+e.verified_women+')</p></div></div><div class="flex flex-wrap gap-2"><button onclick="showRegistrants(\''+esc(e.id)+'\')" class="btn-soft px-3 py-2 text-sm">נרשמים</button><button onclick="openEventChat(\''+esc(e.id)+'\')" class="btn-brand px-3 py-2 text-sm"><i class="fa-regular fa-comments ml-1"></i> צ׳אט</button><button onclick="downloadCalendar(\''+esc(e.id)+'\')" class="btn-soft px-3 py-2 text-sm">יומן</button>'+(e.event_status!=='cancelled'&&e.event_date>=new Date().toISOString().slice(0,10)?'<button onclick="openEditEvent(\''+esc(e.id)+'\')" class="btn-soft px-3 py-2 text-sm">עריכה</button><button onclick="cancelHostEvent(\''+esc(e.id)+'\')" class="bg-red-50 text-red-600 px-3 py-2 rounded-lg font-bold text-sm">ביטול</button>':'')+'</div></div><div id="registrants-'+esc(e.id)+'" class="mt-3 hidden"></div></div>';
            }).join(''):'<p class="text-slate-500">עדיין לא פרסמת אירוע.</p>')+'</div></div>';
        }

        function eventHasEnded(eventId){
            const ev=hostEventsCache.get(eventId);
            if(!ev)return false;
            const end=new Date(String(ev.event_date)+'T'+String(ev.close_time||'23:59').slice(0,8));
            return !Number.isNaN(end.getTime()) && end.getTime()<=Date.now();
        }

        async function setHostAttendance(eventId,userId,present){
            const action=present?'לאשר שהמשמח/ת השתתף/ה באירוע?':'לבטל את אישור ההגעה בפועל?';
            const ok=await askConfirm(present?'אישור השתתפות בפועל':'ביטול אישור השתתפות',action,present?'אשר הגעה':'בטל אישור');
            if(!ok)return;
            const {error}=await _supabase.rpc('host_confirm_attendance',{p_event_id:eventId,p_user_id:userId,p_present:present});
            if(error)return showToast(readableError(error),'error');
            showToast(present?'ההגעה בפועל אושרה.':'אישור ההגעה בפועל בוטל.','success');
            const box=$('registrants-'+eventId);
            if(box)box.classList.add('hidden');
            await showRegistrants(eventId);
            setDashHtml('dash-main-a',await renderHostEvents());
        }

        async function showRegistrants(eventId){
            const box=$('registrants-'+eventId); if(!box) return;
            if(!box.classList.contains('hidden')){box.classList.add('hidden');return;}
            box.classList.remove('hidden');box.innerHTML='<div class="text-sm text-slate-500" role="status">טוען נרשמים...</div>';
            const {data,error}=await _supabase.rpc('get_event_registrants_v3',{p_event_id:eventId});
            if(error) return box.innerHTML='<div class="text-sm text-red-700" role="alert">לא הצלחנו לטעון את רשימת הנרשמים.</div>';
            const ended=eventHasEnded(eventId);
            box.innerHTML=data?.length?'<div class="border-t pt-3 space-y-3">'+data.map(r=>{
                const age=r.birth_year?new Date().getFullYear()-Number(r.birth_year):'—';
                const self=r.attendance_confirmed_at?'<span class="status-pill bg-brand-50 text-brand-700">אישר/ה שמגיע/ה</span>':'<span class="status-pill bg-slate-100 text-slate-600">טרם אישר/ה</span>';
                const verified=r.host_attendance_confirmed_at?'<span class="status-pill bg-green-50 text-green-700">השתתפות אושרה</span>':'';
                const action=ended&&r.status==='approved'
                  ? (r.host_attendance_confirmed_at
                    ? '<button onclick="setHostAttendance(\''+esc(eventId)+'\',\''+esc(r.user_id)+'\',false)" class="btn-soft px-3 py-2 text-xs">בטל אישור בפועל</button>'
                    : '<button onclick="setHostAttendance(\''+esc(eventId)+'\',\''+esc(r.user_id)+'\',true)" class="btn-brand px-3 py-2 text-xs">אשר הגעה בפועל</button>')
                  : '';
                const scoreMeta=r.volunteer_points==null?'':' · '+esc(r.volunteer_rank||'משמח מתחיל')+' · '+Number(r.volunteer_points||0)+' נקודות';
                return '<div class="border rounded-xl bg-white p-3 flex flex-wrap justify-between items-center gap-3"><div><div class="font-semibold">'+esc(r.full_name)+' · '+(r.gender==='male'?'משמח':'משמחת')+' · גיל '+esc(age)+'</div><div class="text-xs text-slate-500 mt-1">נרשם '+new Date(r.registered_at).toLocaleDateString('he-IL')+scoreMeta+'</div><div class="flex flex-wrap gap-2 mt-2">'+self+verified+'</div></div><div>'+action+'</div></div>';
            }).join('')+'</div>':'<div class="text-sm text-slate-500 border-t pt-3">אין נרשמים עדיין.</div>';
        }

        async function openEditEvent(eventId){
            const e=hostEventsCache.get(eventId); if(!e) return;
            $('edit-event-id').value=e.id;
            $('edit-ev-name').value=e.event_name||'';
            $('edit-ev-type').value=e.event_type||'wedding';
            syncEventAgeRangeOptions('edit-');
            $('edit-ev-date').value=e.event_date||''; $('edit-ev-date').min=new Date().toISOString().slice(0,10);
            $('edit-ev-registration-deadline').value=toDateTimeLocal(e.registration_deadline);
            $('edit-ev-hall-name').value=e.hall_name||'';
            $('edit-ev-city').value=e.city||'';
            $('edit-ev-street').value=e.street||'';
            $('edit-ev-house-number').value=e.house_number||'';
            $('edit-ev-start').value=e.start_time?.slice(0,5)||''; $('edit-ev-close').value=e.close_time?.slice(0,5)||'';
            $('edit-ev-sector').value=e.sector_pref||'all'; $('edit-ev-separation').checked=!!e.is_separated;
            $('edit-ev-men').value=e.quota_men??0; $('edit-ev-women').value=e.quota_women??0;
            $('edit-ev-age-range').value=ageRangeValue(e.age_min,e.age_max); $('edit-ev-note').value=e.volunteer_note||'';
            setCheckedValues('edit-ev-accepted-sector',e.accepted_volunteer_sectors||['all']);
            navigate('edit-event');
        }

        async function saveEditEvent(){
            setBusy('edit-event-submit',true,'שומר...');
            try{
                const ev=collectEventForm('edit-');validateEventPayload(ev);
                const coords=await verifyTypedAddress(ev.city,ev.street,ev.house_number);
                const {error}=await _supabase.rpc('update_event_v4',{
                    p_event_id:$('edit-event-id').value,p_event_name:ev.event_name,p_event_type:ev.event_type,
                    p_event_date:ev.event_date,p_registration_deadline:ev.registration_deadline,p_hall_name:ev.hall_name,
                    p_city:ev.city,p_street:ev.street,p_house_number:ev.house_number,p_start_time:ev.start_time,p_close_time:ev.close_time,
                    p_sector_pref:ev.sector_pref,p_accepted_volunteer_sectors:ev.accepted_sectors,p_is_separated:ev.is_separated,
                    p_quota_men:ev.quota_men,p_quota_women:ev.quota_women,p_age_min:ev.age_min,p_age_max:ev.age_max,
                    p_volunteer_note:ev.note||null,p_lat:coords.lat,p_lng:coords.lng
                });
                if(error) throw error;
                showToast('האירוע עודכן בהצלחה.','success');await loadDashboard();
            }catch(e){showToast(readableError(e),'error');}
            finally{setBusy('edit-event-submit',false);}
        }

        async function cancelHostEvent(eventId){
            const ok=await askConfirm('ביטול אירוע','לבטל את האירוע? כל הנרשמים יקבלו התראה.','בטל אירוע');
            if(!ok) return;
            const {error}=await _supabase.rpc('cancel_event',{p_event_id:eventId});
            if(error) showToast(readableError(error),'error'); else {showToast('האירוע בוטל.');await loadDashboard();}
        }

        async function openProfileSettings(){
            if(!currentProfile) return;
            populateBirthYears();
            $('profile-phone-display').textContent=displayPhone(currentProfile.phone);
            $('profile-role-display').textContent='סוג חשבון: '+roleLabel(currentProfile.role);
            const guardianNote=$('profile-guardian-note');
            if(guardianNote){
                guardianNote.classList.toggle('hidden',!currentProfile.guardian_managed);
                guardianNote.textContent=currentProfile.guardian_managed?'חשבון זה מנוהל על ידי הורה/אפוטרופוס'+(currentProfile.guardian_name?' — '+currentProfile.guardian_name:'')+'. הודעות האימות והאירועים נשלחות לטלפון ההורה.':'';
            }
            $('profile-name').value=currentProfile.full_name||'';
            $('profile-gender').value=currentProfile.gender||'male';
            $('profile-birth-year').value=currentProfile.birth_year||'';
            $('profile-sector').value=(currentProfile.sector&&currentProfile.sector!=='all')?currentProfile.sector:'haredi';
            setCheckedValues('profile-sector-pref',currentProfile.volunteer_sector_preferences||['all']);
            setCheckedValues('profile-event-type-pref',currentProfile.volunteer_event_type_preferences||['all']);
            const isMinorManaged=!!currentProfile.guardian_managed&&(new Date().getFullYear()-Number(currentProfile.birth_year||0)<18);
            ['all','wedding','engagement'].forEach(v=>{
                const el=document.querySelector('input[name="profile-event-type-pref"][value="'+v+'"]');
                if(el){el.disabled=isMinorManaged;if(isMinorManaged)el.checked=false;}
            });
            if(isMinorManaged&&!checkedValues('profile-event-type-pref').length){
                setCheckedValues('profile-event-type-pref',['bar_mitzvah','bat_mitzvah']);
            }
            $('profile-city').value=currentProfile.city||'';
            $('profile-street').value=currentProfile.street||'';
            $('profile-house-number').value=currentProfile.house_number||'';
            $('profile-radius').value=radiusChoiceValue(currentProfile.radius);
            $('profile-days').value=currentProfile.max_days_per_week||3;
            $('profile-transport').value=currentProfile.transport_mode||'car';
            setCheckedValues('profile-available-day',currentProfile.availability_days||[0,1,2,3,4]);
            $('profile-available-from').value=currentProfile.availability_from?.slice(0,5)||'';
            $('profile-available-until').value=currentProfile.availability_until?.slice(0,5)||'';
            $('profile-separation').checked=!!currentProfile.strict_separation;
            navigate('profile-settings');
        }

        async function saveProfileSettings(){
            setBusy('profile-submit',true,'שומר...');
            try{
                const {city,street,number}=getAddressParts('profile');
                if(!city||!street||!number) throw new Error('address_incomplete');
                const coords=await verifyTypedAddress(city,street,number);
                const days=checkedNumbers('profile-available-day');
                const eventTypePrefs=checkedValues('profile-event-type-pref');
                if(!days.length) throw new Error('יש לבחור לפחות יום זמינות אחד.');
                if(!eventTypePrefs.length) throw new Error('invalid_event_type_preferences');
                const {error}=await _supabase.rpc('update_my_profile_v6',{
                    p_full_name:$('profile-name').value.trim(),p_gender:$('profile-gender').value,p_sector:$('profile-sector').value,
                    p_volunteer_sector_preferences:checkedValues('profile-sector-pref'),p_volunteer_event_type_preferences:eventTypePrefs,p_birth_year:Number($('profile-birth-year').value),
                    p_city:city,p_street:street,p_house_number:number,p_radius:Number($('profile-radius').value||30),
                    p_max_days_per_week:Number($('profile-days').value||3),p_strict_separation:$('profile-separation').checked,
                    p_availability_days:days,p_availability_from:$('profile-available-from').value||null,
                    p_availability_until:$('profile-available-until').value||null,p_transport_mode:$('profile-transport').value,
                    p_lat:coords.lat,p_lng:coords.lng
                });
                if(error) throw error;
                await loadProfile();
                if(currentProfile.role==='host'){
                    const {error:modeErr}=await _supabase.rpc('enable_volunteer_mode');
                    if(!modeErr){await loadProfile();dashboardArea='volunteer';localStorage.setItem('smachimDashboardArea','volunteer');}
                }
                showToast('הפרופיל עודכן.','success');await loadDashboard();
            }catch(e){showToast(String(e?.message||'').includes('לפחות יום')?String(e.message):readableError(e),'error');}
            finally{setBusy('profile-submit',false);}
        }

        async function openEventChat(eventId,eventName=''){
            activeChatEventId=eventId;activeChatEventName=eventName||resolveEventName(eventId);
            lastFocusedBeforeChat=document.activeElement instanceof HTMLElement?document.activeElement:null;
            $('chat-title').textContent='צ׳אט · '+activeChatEventName;
            const modal=$('chat-modal');
            modal.classList.remove('hidden');modal.classList.add('flex');
            setDialogBackgroundInert(modal,true);
            await refreshEventChat(true);
            if(chatPollTimer)clearInterval(chatPollTimer);
            chatPollTimer=setInterval(()=>refreshEventChat(false),5000);
            setTimeout(()=>$('chat-input')?.focus(),80);
            announceA11y('נפתח צ׳אט האירוע '+activeChatEventName);
        }

        function closeEventChat(){
            if(chatPollTimer){clearInterval(chatPollTimer);chatPollTimer=null;}
            activeChatEventId=null;
            const modal=$('chat-modal');
            modal.classList.add('hidden');modal.classList.remove('flex');
            setDialogBackgroundInert(modal,false);
            const restore=lastFocusedBeforeChat;lastFocusedBeforeChat=null;
            setTimeout(()=>restore?.focus?.(),30);
        }

        async function refreshEventChat(forceBottom=false){
            if(!activeChatEventId)return;
            const box=$('chat-messages');if(!box)return;
            box.setAttribute('aria-busy','true');
            const nearBottom=box.scrollHeight-box.scrollTop-box.clientHeight<100;
            const {data,error}=await _supabase.rpc('get_event_chat',{p_event_id:activeChatEventId,p_limit:150});
            if(error){box.innerHTML='<div class="text-sm text-red-600" role="alert">'+esc(readableError(error))+'</div>';box.setAttribute('aria-busy','false');return;}
            const rows=[...(data||[])].reverse();
            box.innerHTML=rows.length?rows.map(m=>{
                const mine=m.sender_id===currentProfile.id;
                return '<div class="chat-bubble '+(mine?'mine':'other')+'"><div class="text-xs font-bold '+(m.sender_role==='host'?'text-brand-700':'text-slate-600')+'">'+esc(m.sender_name)+(m.sender_role==='host'?' · בעל השמחה':'')+'</div><div class="text-sm whitespace-pre-wrap">'+esc(m.body)+'</div><div class="text-[11px] text-slate-400 mt-1">'+new Date(m.created_at).toLocaleString('he-IL',{hour:'2-digit',minute:'2-digit',day:'2-digit',month:'2-digit'})+'</div></div>';
            }).join(''):'<div class="text-center text-sm text-slate-500 py-10">עדיין אין הודעות. אפשר להיות הראשונים לכתוב.</div>';
            box.setAttribute('aria-busy','false');
            if(forceBottom||nearBottom)box.scrollTop=box.scrollHeight;
        }

        async function sendChatMessage(){
            const input=$('chat-input'),body=input.value.trim();
            if(!activeChatEventId||!body) return;
            setBusy('chat-send',true,'...');
            const {error}=await _supabase.rpc('send_event_message',{p_event_id:activeChatEventId,p_body:body});
            setBusy('chat-send',false);
            if(error) return showToast(readableError(error),'error');
            input.value='';await refreshEventChat(true);
        }

        function adminDateTime(v){
            if(!v)return '—';
            try{return new Date(v).toLocaleString('he-IL',{dateStyle:'short',timeStyle:'short'});}catch(_){return String(v);}
        }

        function adminBool(v){return v?'כן':'לא';}
        function adminRoleLabel(v){return ({volunteer:'משמח/ת',host:'בעל/ת שמחה',both:'משמח/ת + בעל/ת שמחה'})[v]||v||'—';}
        function adminGenderLabel(v){return v==='male'?'משמח':v==='female'?'משמחת':'—';}
        function adminStatusPill(text,kind='neutral'){
            const cls=kind==='bad'?'bg-red-50 text-red-700 border-red-200':kind==='good'?'bg-green-50 text-green-700 border-green-200':kind==='warn'?'bg-amber-50 text-amber-700 border-amber-200':'bg-slate-50 text-slate-600 border-slate-200';
            return '<span class="inline-flex items-center px-2 py-1 rounded-full border text-xs font-bold '+cls+'">'+esc(text)+'</span>';
        }

        function renderAdminPanel(){
            const tabs=[
                ['overview','סקירה','fa-gauge-high'],
                ['analytics','אנליטיקה','fa-chart-column'],
                ['users','משתמשים','fa-users'],
                ['events','אירועים','fa-calendar-days'],
                ['sms','SMS','fa-message'],
                ['reports','דיווחים','fa-triangle-exclamation'],
                ['settings','הגדרות','fa-sliders'],
                ['security','אבטחה','fa-shield-halved'],
                ['versions','גרסאות','fa-clock-rotate-left']
            ];
            return '<div class="space-y-5">'+
                '<div class="glass-card p-3"><div class="flex flex-wrap gap-2">'+tabs.map(t=>
                    '<button id="admin-tab-'+t[0]+'" onclick="adminOpenTab(\''+t[0]+'\')" class="btn-soft px-3 py-2 text-sm"><i class="fa-solid '+t[2]+' ml-1"></i>'+t[1]+'</button>'
                ).join('')+'</div></div>'+
                '<div id="admin-section-root"></div>'+
                '<div id="admin-detail-panel"></div>'+
            '</div>';
        }

        function adminSetActiveTab(name){
            document.querySelectorAll('[id^="admin-tab-"]').forEach(btn=>{
                btn.classList.remove('btn-dark');
                btn.classList.add('btn-soft');
                btn.setAttribute('aria-pressed','false');
                btn.removeAttribute('aria-current');
            });
            const active=$('admin-tab-'+name);
            if(active){active.classList.remove('btn-soft');active.classList.add('btn-dark');active.setAttribute('aria-pressed','true');active.setAttribute('aria-current','page');}
        }

        async function adminOpenTab(name){
            adminTab=name||'overview';
            adminSetActiveTab(adminTab);
            const root=$('admin-section-root');
            const detail=$('admin-detail-panel');
            if(detail)detail.innerHTML='';
            if(!root)return;
            root.innerHTML='<div class="glass-card p-8 text-center text-slate-500">טוען נתונים...</div>';
            try{
                if(adminTab==='overview') root.innerHTML=await adminRenderOverview();
                else if(adminTab==='analytics') root.innerHTML=await adminRenderAnalytics();
                else if(adminTab==='users') root.innerHTML=await adminRenderUsers();
                else if(adminTab==='events') root.innerHTML=await adminRenderEvents();
                else if(adminTab==='sms') root.innerHTML=await adminRenderSms();
                else if(adminTab==='reports') root.innerHTML=await adminRenderReports();
                else if(adminTab==='settings') root.innerHTML=await adminRenderSettings();
                else if(adminTab==='security') root.innerHTML=await adminRenderSecurity();
                else if(adminTab==='versions') root.innerHTML=await adminRenderVersions();
                else root.innerHTML='';
            }catch(e){
                root.innerHTML='<div class="glass-card p-6 text-red-700">'+esc(readableError(e))+'</div>';
            }
        }

        function adminMetric(title,value,subtitle=''){
            return '<div class="mini-stat p-4"><div class="text-xs text-slate-500">'+esc(title)+'</div><div class="text-2xl font-extrabold mt-1">'+esc(value??0)+'</div>'+(subtitle?'<div class="text-xs text-slate-400 mt-1">'+esc(subtitle)+'</div>':'')+'</div>';
        }

        async function adminRenderOverview(){
            const [{data:o,error},{data:sms}]=await Promise.all([
                _supabase.rpc('admin_dashboard_overview'),
                _supabase.rpc('admin_sms_status')
            ]);
            if(error)throw error;
            const alerts=[];
            if(Number(o.open_reports||0)>0)alerts.push({text:o.open_reports+' דיווחים ממתינים לטיפול',tab:'reports',bad:true});
            if(Number(o.sms_failed||0)>0)alerts.push({text:o.sms_failed+' הודעות SMS נכשלו',tab:'sms',bad:true});
            if(Number(o.events_underfilled||0)>0)alerts.push({text:o.events_underfilled+' אירועים עתידיים עדיין לא מלאים',tab:'events'});
            if(sms?.settings?.gateway_last_error)alerts.push({text:'תקלה אחרונה ב-SMS: '+sms.settings.gateway_last_error,tab:'sms',bad:true});
            if(sms?.settings?.sending_enabled===false)alerts.push({text:'שליחת SMS כבויה',tab:'sms',bad:true});

            return '<div class="space-y-5">'+
                '<div class="glass-card p-6"><div class="flex flex-wrap items-center justify-between gap-3"><div><h3 class="text-2xl font-bold">תמונת מצב</h3><p class="text-sm text-slate-500">הנתונים המרכזיים של האתר בזמן אמת.</p></div><button onclick="adminOpenTab(\'overview\')" class="btn-soft px-3 py-2"><i class="fa-solid fa-rotate ml-1"></i>רענן</button></div>'+
                '<div class="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-6 gap-3 mt-5">'+
                    adminMetric('משתמשים',o.users_total,'+'+Number(o.new_users_30d||0)+' ב־30 יום')+
                    adminMetric('משמחים/ות',o.volunteers)+
                    adminMetric('בעלי שמחה',o.hosts)+
                    adminMetric('אירועים עתידיים',o.events_upcoming)+
                    adminMetric('הרשמות מאושרות',o.registrations_approved)+
                    adminMetric('דיווחים פתוחים',o.open_reports)+
                    adminMetric('אירועים לא מלאים',o.events_underfilled)+
                    adminMetric('SMS בהמתנה',o.sms_pending)+
                    adminMetric('SMS נמסרו',o.sms_delivered)+
                    adminMetric('SMS נכשלו',o.sms_failed)+
                    adminMetric('תגובות SMS השבוע',o.sms_inbound_7d)+
                    adminMetric('מסירה ב־30 יום',o.sms_delivery_rate_30d==null?'—':o.sms_delivery_rate_30d+'%')+
                '</div></div>'+
                '<div class="grid grid-cols-1 lg:grid-cols-2 gap-5">'+
                    '<div class="glass-card p-6"><h3 class="font-bold text-lg mb-4">דורש תשומת לב</h3>'+
                    (alerts.length?'<div class="space-y-2">'+alerts.map(a=>'<button onclick="adminOpenTab(\''+a.tab+'\')" class="w-full text-right border rounded-xl p-3 '+(a.bad?'border-red-200 bg-red-50 text-red-700':'border-amber-200 bg-amber-50 text-amber-800')+'">'+esc(a.text)+'</button>').join('')+'</div>':'<div class="text-green-700 bg-green-50 border border-green-200 rounded-xl p-4">אין כרגע התראות תפעוליות דחופות.</div>')+
                    '</div>'+
                    '<div class="glass-card p-6"><h3 class="font-bold text-lg mb-4">בריאות המערכת</h3><div class="space-y-2 text-sm">'+
                        '<div class="flex justify-between"><span>שליחת SMS</span><b>'+(sms?.settings?.sending_enabled?'פעילה':'כבויה')+'</b></div>'+
                        '<div class="flex justify-between"><span>הזמנות SMS</span><b>'+(sms?.settings?.invite_enabled?'פעילות':'כבויות')+'</b></div>'+
                        '<div class="flex justify-between"><span>תזכורות</span><b>'+(sms?.settings?.reminder_enabled?'פעילות':'כבויות')+'</b></div>'+
                        '<div class="flex justify-between"><span>רענון Inbox אחרון</span><b>'+esc(adminDateTime(sms?.settings?.last_inbox_refresh_at))+'</b></div>'+
                        '<div class="flex justify-between"><span>Gateway נראה לאחרונה</span><b>'+esc(adminDateTime(sms?.settings?.last_gateway_seen_at))+'</b></div>'+
                        '<div class="flex justify-between"><span>סשנים פעילים</span><b>'+Number(o.active_user_sessions||0)+' משתמשים · '+Number(o.active_admin_sessions||0)+' מנהל</b></div>'+
                    '</div></div>'+
                '</div>'+
            '</div>';
        }

        function adminBreakdownCard(title,rows,labeler=(x)=>x){
            const a=Array.isArray(rows)?rows:[];
            const max=Math.max(1,...a.map(x=>Number(x.count||0)));
            return '<div class="glass-card p-5"><h4 class="font-bold mb-4">'+esc(title)+'</h4><div class="space-y-3">'+
                (a.length?a.map(x=>'<div><div class="flex justify-between text-sm mb-1"><span>'+esc(labeler(x.key))+'</span><b>'+Number(x.count||0)+'</b></div><div class="h-2 bg-slate-100 rounded-full overflow-hidden"><div class="h-full bg-slate-700 rounded-full" style="width:'+Math.max(3,Math.round(100*Number(x.count||0)/max))+'%"></div></div></div>').join(''):'<p class="text-sm text-slate-500">אין נתונים.</p>')+
            '</div></div>';
        }

        async function adminRenderAnalytics(){
            const [{data:series,error:sErr},{data:b,error:bErr},{data:o,error:oErr}]=await Promise.all([
                _supabase.rpc('admin_analytics_series',{p_days:30}),
                _supabase.rpc('admin_analytics_breakdown'),
                _supabase.rpc('admin_dashboard_overview')
            ]);
            if(sErr)throw sErr;if(bErr)throw bErr;if(oErr)throw oErr;
            const rows=series||[];
            const totals=rows.reduce((a,x)=>({users:a.users+Number(x.new_users||0),events:a.events+Number(x.new_events||0),regs:a.regs+Number(x.registrations||0),sms:a.sms+Number(x.sms_created||0),del:a.del+Number(x.sms_delivered||0)}),{users:0,events:0,regs:0,sms:0,del:0});
            const recent=rows.slice(-14);
            const max=Math.max(1,...recent.map(x=>Number(x.new_users||0)+Number(x.new_events||0)+Number(x.registrations||0)));
            return '<div class="space-y-5">'+
                '<div class="glass-card p-6"><h3 class="text-2xl font-bold">אנליטיקה</h3><p class="text-sm text-slate-500">מגמות שימוש ב־30 הימים האחרונים.</p><div class="grid grid-cols-2 md:grid-cols-5 gap-3 mt-5">'+
                    adminMetric('משתמשים חדשים',totals.users)+adminMetric('אירועים חדשים',totals.events)+adminMetric('הרשמות',totals.regs)+adminMetric('SMS שנוצרו',totals.sms)+adminMetric('SMS שנמסרו',totals.del)+
                '</div></div>'+
                '<div class="glass-card p-6"><h4 class="font-bold mb-4">14 הימים האחרונים</h4><div class="overflow-x-auto"><table class="w-full text-sm"><thead><tr class="text-slate-500 border-b"><th class="text-right py-2">תאריך</th><th>משתמשים</th><th>אירועים</th><th>הרשמות</th><th>SMS</th><th>נמסרו</th></tr></thead><tbody>'+
                    recent.map(x=>'<tr class="border-b border-slate-100"><td class="py-2 font-bold">'+esc(formatDate(x.day))+'</td><td class="text-center">'+Number(x.new_users||0)+'</td><td class="text-center">'+Number(x.new_events||0)+'</td><td class="text-center">'+Number(x.registrations||0)+'</td><td class="text-center">'+Number(x.sms_created||0)+'</td><td class="text-center">'+Number(x.sms_delivered||0)+'</td></tr>').join('')+
                '</tbody></table></div></div>'+
                '<div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">'+
                    adminBreakdownCard('סוגי אירועים',b?.event_types,eventTypeLabel)+
                    adminBreakdownCard('סוגי חשבונות',b?.user_roles,adminRoleLabel)+
                    adminBreakdownCard('מגזרים',b?.user_sectors,sectorLabel)+
                    adminBreakdownCard('סטטוס הרשמות',b?.registration_statuses,x=>({approved:'מאושר',waitlist:'המתנה',cancelled:'בוטל'}[x]||x))+
                    adminBreakdownCard('סוגי SMS',b?.sms_kinds,x=>x)+
                    adminBreakdownCard('ערים מובילות',b?.top_cities,x=>x)+
                '</div>'+
                '<div class="glass-card p-6"><div class="grid grid-cols-2 md:grid-cols-4 gap-3">'+
                    adminMetric('משתמשים חסומים',o.blocked_users)+
                    adminMetric('חשבונות הורה',o.guardian_managed)+
                    adminMetric('נוכחות שאושרה',o.attendance_confirmed)+
                    adminMetric('אירועים שבוטלו',o.events_cancelled)+
                '</div></div>'+
            '</div>';
        }

        function adminNewUserForm(){
            const sectors=configuredSectors().filter(x=>x.enabled!==false);
            const radii=configuredRadiusOptions().filter(x=>x.enabled!==false);
            const currentYear=new Date().getFullYear();
            const years=[];
            for(let y=currentYear-18;y>=1900;y--)years.push('<option value="'+y+'">'+y+'</option>');
            return '<div id="admin-new-user-card" class="glass-card p-6 mb-5 border-2 border-brand-100 hidden">'+
                '<div class="flex justify-between gap-3 items-start"><div><h3 class="text-xl font-bold">הוספת משתמש חדש</h3><p class="text-sm text-slate-500">החשבון נוצר ישירות על ידי מנהל. למשמח/ת נדרשים גם פרטי התאמה מלאים.</p></div><button onclick="adminToggleNewUserForm(false)" class="btn-soft px-3 py-2">סגור</button></div>'+
                '<form id="admin-new-user-form" onsubmit="event.preventDefault(); adminCreateUser();" class="space-y-4 mt-5">'+
                    '<div class="grid grid-cols-1 md:grid-cols-2 gap-4"><label><span class="field-label">שם מלא</span><input id="admin-new-name" class="input-clean" minlength="2" maxlength="100" required></label><label><span class="field-label">טלפון</span><input id="admin-new-phone" type="tel" class="input-clean" dir="ltr" placeholder="05XXXXXXXX" required></label></div>'+
                    '<div class="grid grid-cols-1 md:grid-cols-2 gap-4"><label><span class="field-label">סיסמה זמנית</span><input id="admin-user-new-password" type="password" class="input-clean" minlength="8" maxlength="72" required autocomplete="new-password"></label><label><span class="field-label">סוג חשבון</span><select id="admin-new-role" class="input-clean bg-white" onchange="adminSyncNewUserRole()" required><option value="host">בעל שמחה</option><option value="volunteer">משמח/ת</option><option value="both">בעל שמחה + משמח/ת</option></select></label></div>'+
                    '<div id="admin-new-volunteer-fields" class="hidden space-y-4">'+
                        '<div class="grid grid-cols-1 md:grid-cols-3 gap-4"><label><span class="field-label">איך לפנות?</span><select id="admin-new-gender" class="input-clean bg-white"><option value="">בחר/י</option><option value="male">משמח</option><option value="female">משמחת</option></select></label><label><span class="field-label">שנת לידה</span><select id="admin-new-birth-year" class="input-clean bg-white"><option value="">בחר/י</option>'+years.join('')+'</select></label><label><span class="field-label">מגזר</span><select id="admin-new-sector" class="input-clean bg-white"><option value="">בחר/י</option>'+sectors.map(x=>'<option value="'+esc(x.value)+'">'+esc(x.label)+'</option>').join('')+'</select></label></div>'+
                        '<div><span class="field-label">כתובת מגורים</span><div class="grid grid-cols-1 md:grid-cols-3 gap-3"><input id="admin-new-city" class="input-clean" placeholder="עיר"><input id="admin-new-street" class="input-clean" placeholder="רחוב"><input id="admin-new-house" class="input-clean" placeholder="מספר"></div></div>'+
                        '<label><span class="field-label">מרחק מקסימלי</span><select id="admin-new-radius" class="input-clean bg-white">'+radii.map(x=>'<option value="'+esc(x.value)+'">'+esc(x.label)+'</option>').join('')+'</select></label>'+
                    '</div>'+
                    '<label class="flex items-start gap-3 bg-amber-50 border border-amber-200 rounded-xl p-4"><input id="admin-new-consent" type="checkbox" class="mt-1" required><span class="text-sm">אני מאשר/ת שקיבלתי מהמשתמש הסכמה לפתיחת החשבון, לתנאי השימוש, למדיניות הפרטיות ולהודעות SMS תפעוליות.</span></label>'+
                    '<button id="admin-new-submit" type="submit" class="btn-brand px-5 py-3">צור משתמש</button>'+
                '</form>'+
            '</div>';
        }

        async function adminRenderUsers(){
            const {data,error}=await _supabase.rpc('admin_list_users_v3',{p_search:adminUserSearch||'',p_limit:200,p_offset:0});
            if(error)throw error;
            adminUsersCache=data||[];
            return adminNewUserForm()+'<div class="glass-card p-6"><div class="flex flex-wrap justify-between gap-3 items-end"><div><h3 class="text-2xl font-bold">משתמשים</h3><p class="text-sm text-slate-500">חיפוש, הוספה, מחיקה, בדיקת פרופיל, חסימה, SMS וניתוק סשנים.</p></div><div class="flex flex-wrap gap-2"><button onclick="adminToggleNewUserForm(true)" class="btn-brand px-4 py-2"><i class="fa-solid fa-user-plus ml-1"></i> הוסף משתמש</button><input id="admin-user-search" class="input-clean min-w-56" value="'+esc(adminUserSearch)+'" placeholder="שם, טלפון או עיר"><button onclick="adminSearchUsers()" class="btn-dark px-4">חפש</button></div></div>'+
                '<div class="mt-5 space-y-3">'+(adminUsersCache.length?adminUsersCache.map(u=>
                    '<div class="border rounded-xl p-4 bg-white"><div class="flex flex-wrap justify-between gap-3"><div><div class="font-bold text-lg">'+esc(u.full_name)+(u.is_admin?' <span class="text-xs bg-slate-100 border rounded-full px-2 py-1">מנהל</span>':'')+'</div><div class="text-sm text-slate-500"><span dir="ltr">'+esc(u.phone_masked||'••••')+'</span> · '+esc(adminRoleLabel(u.role))+' · '+esc(u.city||'ללא עיר')+'</div><div class="flex flex-wrap gap-2 mt-2">'+(u.is_blocked?adminStatusPill('חסום','bad'):adminStatusPill('פעיל','good'))+(Number(u.family_children_count||0)?adminStatusPill(Number(u.family_children_count)+' ילדים','warn'):'')+(u.sms_notifications_enabled?adminStatusPill('SMS פעיל','neutral'):adminStatusPill('SMS כבוי','warn'))+'</div></div>'+
                    '<div class="flex flex-wrap gap-2 items-start"><button onclick="adminShowUser(\''+esc(u.id)+'\')" class="btn-soft px-3 py-2">פרטים</button><button onclick="adminToggleBlock(\''+esc(u.id)+'\','+(!u.is_blocked)+')" class="'+(u.is_blocked?'bg-green-50 text-green-700':'bg-red-50 text-red-700')+' border rounded-lg px-3 py-2 font-bold text-sm">'+(u.is_blocked?'פתח חסימה':'חסום')+'</button><button onclick="adminSetUserSms(\''+esc(u.id)+'\','+(!u.sms_notifications_enabled)+')" class="btn-soft px-3 py-2">'+(u.sms_notifications_enabled?'כבה SMS':'הפעל SMS')+'</button><button onclick="adminForceLogout(\''+esc(u.id)+'\')" class="btn-soft px-3 py-2">נתק</button>'+(!u.is_admin?'<button onclick="adminDeleteUser(\''+esc(u.id)+'\',\''+esc(u.full_name)+'\')" class="bg-red-50 text-red-700 border border-red-200 rounded-lg px-3 py-2 font-bold text-sm">מחק</button>':'')+'</div></div>'+
                    '<div class="text-xs text-slate-400 mt-3">אירועים שפורסמו: '+Number(u.hosted_events||0)+' · הרשמות: '+Number(u.registrations_count||0)+' · ילדים בחשבון: '+Number(u.family_children_count||0)+' · נוצר: '+esc(adminDateTime(u.created_at))+'</div></div>'
                ).join(''):'<p class="text-slate-500 py-8 text-center">לא נמצאו משתמשים.</p>')+'</div></div>';
        }

        function adminToggleNewUserForm(show=true){
            const card=$('admin-new-user-card');
            if(!card)return;
            card.classList.toggle('hidden',!show);
            if(show){adminSyncNewUserRole();card.scrollIntoView({behavior:'smooth',block:'start'});}
        }

        function adminSyncNewUserRole(){
            const role=$('admin-new-role')?.value||'host';
            const volunteer=role==='volunteer'||role==='both';
            $('admin-new-volunteer-fields')?.classList.toggle('hidden',!volunteer);
            for(const id of ['admin-new-gender','admin-new-birth-year','admin-new-sector','admin-new-city','admin-new-street','admin-new-house']){
                const el=$(id);if(el)el.required=volunteer;
            }
        }

        async function adminCreateUser(){
            setBusy('admin-new-submit',true,'יוצר...');
            try{
                const name=$('admin-new-name').value.trim();
                const phone=normalizePhone($('admin-new-phone').value);
                const password=$('admin-user-new-password').value;
                const role=$('admin-new-role').value;
                const volunteer=role==='volunteer'||role==='both';
                const gender=volunteer?$('admin-new-gender').value:null;
                const birthYear=volunteer?Number($('admin-new-birth-year').value):null;
                const sector=volunteer?$('admin-new-sector').value:'all';
                const city=volunteer?$('admin-new-city').value.trim():'';
                const street=volunteer?$('admin-new-street').value.trim():'';
                const house=volunteer?$('admin-new-house').value.trim():'';
                const radius=volunteer?Number($('admin-new-radius').value):10;
                if(name.length<2)throw new Error('invalid_name');
                if(!isValidPhone(phone))throw new Error('invalid_phone');
                if(password.length<8)throw new Error('invalid_password');
                if(!$('admin-new-consent').checked)throw new Error('admin_user_consent_required');
                let coords={lat:null,lng:null};
                if(volunteer){
                    if(!gender)throw new Error('gender_required');
                    if(!birthYear||new Date().getFullYear()-birthYear<18)throw new Error('adult_account_required');
                    if(!sector)throw new Error('invalid_sector');
                    if(!city||!street||!house)throw new Error('address_incomplete');
                    coords=await verifyTypedAddress(city,street,house);
                }
                const {data,error}=await _supabase.rpc('admin_create_user',{
                    p_full_name:name,p_phone:phone,p_password:password,p_role:role,
                    p_gender:gender,p_birth_year:birthYear,p_sector:sector,
                    p_city:city,p_street:street,p_house_number:house,p_radius:radius,
                    p_lat:coords.lat,p_lng:coords.lng,p_consent_confirmed:true
                });
                if(error)throw error;
                $('admin-new-user-form')?.reset();
                showToast('המשתמש נוצר בהצלחה.','success');
                await adminOpenTab('users');
                if(data)await adminShowUser(data);
            }catch(e){showToast(readableError(e),'error');}
            finally{setBusy('admin-new-submit',false);}
        }

        async function adminDeleteUser(id,name){
            const ok=await askConfirm('מחיקת משתמש','למחוק לצמיתות את '+(name||'המשתמש')+'? ההרשמות והילדים המנוהלים בחשבון יוסרו. אם קיימים אירועים עתידיים פעילים, המחיקה תיחסם עד לביטולם.','מחק לצמיתות');
            if(!ok)return;
            const typed=await askText('אישור מחיקה','כדי למנוע מחיקה בטעות, הקלד/י מחיקה','מחיקה');
            if(typed!=='מחיקה')return showToast('המחיקה בוטלה.','warning');
            const {error}=await _supabase.rpc('admin_delete_user',{p_profile_id:id});
            if(error)return showToast(readableError(error),'error');
            showToast('המשתמש נמחק.','success');
            adminCloseDetail();
            await adminOpenTab('users');
        }

        async function adminSearchUsers(){
            adminUserSearch=$('admin-user-search')?.value.trim()||'';
            await adminOpenTab('users');
        }

        async function adminShowUser(id){
            const {data,error}=await _supabase.rpc('admin_user_detail',{p_profile_id:id});
            if(error)return showToast(readableError(error),'error');
            const p=data?.profile||{},st=data?.stats||{},regs=data?.recent_registrations||[];
            const detail=$('admin-detail-panel');if(!detail)return;
            detail.innerHTML='<div class="glass-card p-6 mt-5 border-2 border-slate-300"><div class="flex justify-between gap-3"><div><h3 class="text-xl font-bold">'+esc(p.full_name||'משתמש')+'</h3><p class="text-sm text-slate-500" dir="ltr">'+esc(displayPhone(p.phone||''))+'</p></div><button onclick="adminCloseDetail()" class="btn-soft px-3">סגור</button></div>'+
                '<div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-5 text-sm">'+
                    '<div><b>חשבון</b><p class="mt-1">סוג: '+esc(adminRoleLabel(p.role))+'<br>פנייה: '+esc(adminGenderLabel(p.gender))+'<br>מגזר: '+esc(sectorLabel(p.sector))+'<br>שנת לידה: '+esc(p.birth_year||'—')+'</p></div>'+
                    '<div><b>כתובת והתאמה</b><p class="mt-1">'+esc([p.street,p.house_number,p.city].filter(Boolean).join(' ')||'—')+'<br>רדיוס: '+esc(radiusLabel(p.radius))+'<br>ימים בשבוע: '+esc(p.max_days_per_week??'—')+'</p></div>'+
                    '<div><b>פעילות</b><p class="mt-1">אירועים שפורסמו: '+Number(st.hosted_events||0)+'<br>הרשמות: '+Number(st.registrations||0)+'<br>מאושרות: '+Number(st.approved||0)+'<br>סשנים פעילים: '+Number(st.active_sessions||0)+'</p></div>'+
                '</div>'+
                (p.guardian_managed?'<div class="mt-4 bg-amber-50 border border-amber-200 rounded-lg p-3 text-sm"><b>חשבון מנוהל ע״י הורה:</b> '+esc(p.guardian_name||'—')+' · אישור: '+esc(adminDateTime(p.guardian_consent_at))+'</div>':'')+
                '<div class="mt-5"><h4 class="font-bold mb-2">הרשמות אחרונות</h4><div class="space-y-2">'+(regs.length?regs.map(r=>'<div class="border rounded-lg p-3 text-sm"><b>'+esc(r.event_name)+'</b> · '+esc(formatDate(r.event_date))+' · '+esc(r.status)+'</div>').join(''):'<p class="text-sm text-slate-500">אין הרשמות.</p>')+'</div></div>'+
            '</div>';
            detail.scrollIntoView({behavior:'smooth',block:'start'});
        }

        function adminCloseDetail(){const d=$('admin-detail-panel');if(d)d.innerHTML='';}

        async function adminSetUserSms(id,enabled){
            const ok=await askConfirm(enabled?'הפעלת SMS':'כיבוי SMS',enabled?'לאפשר שוב הודעות SMS למשתמש?':'להפסיק הודעות SMS למשתמש הזה?');
            if(!ok)return;
            const {error}=await _supabase.rpc('admin_set_user_sms',{p_profile_id:id,p_enabled:enabled});
            if(error)return showToast(readableError(error),'error');
            showToast('ההגדרה עודכנה.','success');await adminOpenTab('users');
        }

        async function adminForceLogout(id){
            const ok=await askConfirm('ניתוק משתמש','לנתק את כל הסשנים הרגילים של המשתמש? הוא יצטרך להתחבר מחדש.');
            if(!ok)return;
            const {error}=await _supabase.rpc('admin_force_logout_user',{p_profile_id:id});
            if(error)return showToast(readableError(error),'error');
            showToast('המשתמש נותק.','success');
        }

        async function adminRenderEvents(){
            const {data,error}=await _supabase.rpc('admin_list_events',{p_search:adminEventSearch||'',p_status:adminEventStatus||'all',p_limit:200,p_offset:0});
            if(error)throw error;
            const events=data||[];
            return '<div class="glass-card p-6"><div class="flex flex-wrap justify-between gap-3 items-end"><div><h3 class="text-2xl font-bold">אירועים</h3><p class="text-sm text-slate-500">מעקב אחר תפוסה, דיווחים, בעל האירוע והנרשמים.</p></div><div class="flex flex-wrap gap-2"><input id="admin-event-search" class="input-clean min-w-52" value="'+esc(adminEventSearch)+'" placeholder="אירוע, בעל שמחה או עיר"><select id="admin-event-status" class="input-clean bg-white"><option value="all">כל הסטטוסים</option><option value="active">פעיל</option><option value="full">מלא</option><option value="completed">הסתיים</option><option value="cancelled">בוטל</option></select><button onclick="adminSearchEvents()" class="btn-dark px-4">סנן</button></div></div>'+
                '<div class="mt-5 space-y-3">'+(events.length?events.map(e=>{
                    const total=Number(e.quota_men||0)+Number(e.quota_women||0),approved=Number(e.approved_men||0)+Number(e.approved_women||0);
                    return '<div class="border rounded-xl p-4 bg-white"><div class="flex flex-wrap justify-between gap-3"><div><div class="font-bold text-lg">'+esc(e.event_name)+'</div><div class="text-sm text-slate-500">'+esc(eventTypeLabel(e.event_type))+' · '+esc(formatDate(e.event_date))+' · '+esc(String(e.start_time||'').slice(0,5))+' · '+esc(e.city||'')+'</div><div class="text-sm mt-2">בעל שמחה: <b>'+esc(e.host_name)+'</b> · תפוסה: <b>'+approved+'/'+total+'</b> · המתנה: '+Number(e.waitlist_count||0)+' · דיווחים: '+Number(e.reports_count||0)+'</div></div><div class="flex gap-2 items-start">'+adminStatusPill(eventStatusLabel(e),e.status==='cancelled'?'bad':e.status==='full'?'good':'neutral')+'<button onclick="adminShowEvent(\''+esc(e.id)+'\')" class="btn-soft px-3 py-2">פרטים ונרשמים</button>'+(e.status!=='cancelled'&&e.status!=='completed'?'<button onclick="adminCancelEvent(\''+esc(e.id)+'\')" class="bg-red-50 text-red-700 border border-red-200 rounded-lg px-3 py-2 font-bold text-sm">בטל אירוע</button>':'')+'</div></div></div>';
                }).join(''):'<p class="text-slate-500 py-8 text-center">לא נמצאו אירועים.</p>')+'</div></div>';
        }

        async function adminSearchEvents(){
            adminEventSearch=$('admin-event-search')?.value.trim()||'';
            adminEventStatus=$('admin-event-status')?.value||'all';
            await adminOpenTab('events');
            if($('admin-event-status'))$('admin-event-status').value=adminEventStatus;
        }

        async function adminShowEvent(id){
            const {data,error}=await _supabase.rpc('admin_event_detail',{p_event_id:id});
            if(error)return showToast(readableError(error),'error');
            const e=data?.event||{},h=data?.host||{},v=data?.venue||{},regs=data?.registrants||[],reports=data?.reports||[];
            const detail=$('admin-detail-panel');if(!detail)return;
            detail.innerHTML='<div class="glass-card p-6 mt-5 border-2 border-slate-300"><div class="flex justify-between gap-3"><div><h3 class="text-xl font-bold">'+esc(e.event_name||'אירוע')+'</h3><p class="text-sm text-slate-500">'+esc(eventTypeLabel(e.event_type))+' · '+esc(formatDate(e.event_date))+' · '+esc(String(e.start_time||'').slice(0,5))+'</p></div><button onclick="adminCloseDetail()" class="btn-soft px-3">סגור</button></div>'+
                '<div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-5 text-sm"><div><b>בעל שמחה</b><p>'+esc(h.name||'—')+'<br><span dir="ltr">'+esc(displayPhone(h.phone||''))+'</span></p></div><div><b>מקום</b><p>'+esc(v.hall_name||'—')+'<br>'+esc([v.street,v.house_number,v.city].filter(Boolean).join(' ')||'—')+'</p></div><div><b>הגדרות</b><p>משמחים: '+Number(e.quota_men||0)+' · משמחות: '+Number(e.quota_women||0)+'<br>גיל: '+esc(ageRangeValue(e.age_min,e.age_max)==='all'?'ללא הגבלה':ageRangeValue(e.age_min,e.age_max))+'<br>הפרדה: '+esc(e.is_separated?'מלאה':'ללא')+'</p></div></div>'+
                '<div class="grid grid-cols-1 lg:grid-cols-2 gap-5 mt-5"><div><h4 class="font-bold mb-2">נרשמים ('+regs.length+')</h4><div class="space-y-2 max-h-96 overflow-auto">'+(regs.length?regs.map(r=>'<div class="border rounded-lg p-3 text-sm"><div class="font-bold">'+esc(r.full_name)+' '+(r.guardian_managed?'(מנוהל ע״י הורה)':'')+'</div><div class="text-slate-500"><span dir="ltr">'+esc(displayPhone(r.phone||''))+'</span> · '+esc(adminGenderLabel(r.gender))+' · '+esc(r.status)+'</div></div>').join(''):'<p class="text-slate-500 text-sm">אין נרשמים.</p>')+'</div></div><div><h4 class="font-bold mb-2">דיווחים ('+reports.length+')</h4><div class="space-y-2 max-h-96 overflow-auto">'+(reports.length?reports.map(r=>'<div class="border rounded-lg p-3 text-sm"><b>'+esc(r.reporter_name||'משתמש')+'</b><div>'+esc(r.reason||'ללא פירוט')+'</div><div class="text-xs text-slate-400">'+esc(r.status)+' · '+esc(adminDateTime(r.created_at))+'</div></div>').join(''):'<p class="text-slate-500 text-sm">אין דיווחים.</p>')+'</div></div></div>'+
            '</div>';
            detail.scrollIntoView({behavior:'smooth',block:'start'});
        }

        async function adminRenderSms(){
            const [{data:status,error:sErr},{data:rows,error:rErr},{data:inbound,error:iErr}]=await Promise.all([
                _supabase.rpc('admin_sms_status'),
                _supabase.rpc('admin_sms_recent_v2',{p_filter:adminSmsFilter||'all',p_limit:100}),
                _supabase.rpc('admin_sms_inbound_recent',{p_limit:40})
            ]);
            if(sErr)throw sErr;if(rErr)throw rErr;if(iErr)throw iErr;
            const set=status?.settings||{},c=status?.counts||{};
            return '<div class="space-y-5">'+
                '<div class="glass-card p-6"><div class="flex flex-wrap justify-between gap-3"><div><h3 class="text-2xl font-bold">SMS</h3><p class="text-sm text-slate-500">מצב השליחה, תקלות, תגובות והגדרות מערכת.</p></div><div class="flex gap-2"><button onclick="adminRunSmsMaintenance()" class="btn-soft px-3 py-2">הרץ תחזוקה</button><button onclick="adminOpenTab(\'sms\')" class="btn-soft px-3 py-2">רענן</button></div></div><div class="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-7 gap-3 mt-5">'+adminMetric('בהמתנה',c.pending)+adminMetric('בתהליך',c.sending)+adminMetric('אצל הספק',c.sent)+adminMetric('נמסרו',c.delivered)+adminMetric('בוצעה פעולה',c.acted)+adminMetric('נכשלו',c.failed)+adminMetric('תגובות היום',c.inbound_today)+'</div></div>'+
                '<div class="glass-card p-6"><h4 class="font-bold text-lg">הגדרות SMS</h4><form onsubmit="event.preventDefault(); adminSaveSmsSettings();" class="grid grid-cols-1 md:grid-cols-4 gap-4 mt-4"><label class="flex items-center gap-2"><input id="admin-sms-sending" type="checkbox" '+(set.sending_enabled?'checked':'')+'> שליחה כללית</label><label class="flex items-center gap-2"><input id="admin-sms-invites" type="checkbox" '+(set.invite_enabled?'checked':'')+'> הזמנות</label><label class="flex items-center gap-2"><input id="admin-sms-reminders" type="checkbox" '+(set.reminder_enabled?'checked':'')+'> תזכורות</label><label><span class="field-label">שעות לפני תזכורת</span><input id="admin-sms-reminder-hours" type="number" min="1" max="168" class="input-clean" value="'+Number(set.reminder_hours_before||24)+'"></label><button class="btn-dark py-3 md:col-span-4">שמור הגדרות SMS</button></form><div class="grid grid-cols-1 md:grid-cols-3 gap-3 mt-4 text-sm text-slate-500"><div>Gateway נראה: <b>'+esc(adminDateTime(set.last_gateway_seen_at))+'</b></div><div>Inbox רוענן: <b>'+esc(adminDateTime(set.last_inbox_refresh_at))+'</b></div><div>שגיאה אחרונה: <b>'+esc(set.gateway_last_error||'אין')+'</b></div></div></div>'+
                '<div class="glass-card p-6"><div class="flex flex-wrap justify-between gap-3 items-center"><h4 class="font-bold text-lg">הודעות אחרונות</h4><select id="admin-sms-filter" onchange="adminChangeSmsFilter(this.value)" class="input-clean bg-white max-w-48"><option value="all">הכול</option><option value="pending">בהמתנה</option><option value="delivered">נמסרו</option><option value="failed">נכשלו</option><option value="acted">בוצעה פעולה</option></select></div><div class="overflow-x-auto mt-4"><table class="w-full text-xs"><thead><tr class="border-b text-slate-500"><th class="text-right py-2">זמן</th><th>משתמש</th><th>סוג</th><th>אירוע</th><th>מצב</th><th>ניסיונות</th><th>שגיאה/תגובה</th><th></th></tr></thead><tbody>'+
                    (rows||[]).map(q=>'<tr class="border-b border-slate-100"><td class="py-2 whitespace-nowrap">'+esc(adminDateTime(q.created_at))+'</td><td>'+esc(q.profile_name||'')+'</td><td>'+esc(q.kind)+'</td><td>'+esc(q.event_name||'')+'</td><td>'+esc((q.status||'')+(q.delivery_state?' / '+q.delivery_state:''))+'</td><td class="text-center">'+Number(q.attempt_count||0)+'</td><td class="max-w-64">'+esc(q.last_error||q.reply_action||q.reply_value||'—')+'</td><td>'+((q.status==='failed'||String(q.delivery_state||'').toLowerCase()==='failed')?'<button onclick="adminRetrySms(\''+esc(q.id)+'\')" class="text-brand-700 font-bold">נסה שוב</button>':'')+'</td></tr>').join('')+
                '</tbody></table></div></div>'+
                '<div class="glass-card p-6"><h4 class="font-bold text-lg mb-4">תגובות SMS נכנסות</h4><div class="space-y-2 max-h-96 overflow-auto">'+((inbound||[]).length?(inbound||[]).map(i=>'<div class="border rounded-lg p-3 text-sm"><div class="flex justify-between gap-2"><b>'+esc(i.profile_name||i.phone||'לא מזוהה')+'</b><span class="text-xs text-slate-400">'+esc(adminDateTime(i.received_at))+'</span></div><div class="mt-1">תגובה: <b>'+esc(i.message_body||'')+'</b>'+(i.event_name?' · '+esc(i.event_name):'')+'</div><div class="text-xs text-slate-500 mt-1">'+esc(i.result?JSON.stringify(i.result):'')+'</div></div>').join(''):'<p class="text-slate-500">אין תגובות.</p>')+'</div></div>'+
            '</div>';
        }

        async function adminChangeSmsFilter(v){adminSmsFilter=v||'all';await adminOpenTab('sms');if($('admin-sms-filter'))$('admin-sms-filter').value=adminSmsFilter;}

        async function adminSaveSmsSettings(){
            const hours=Number($('admin-sms-reminder-hours')?.value||24);
            const {error}=await _supabase.rpc('admin_update_sms_settings',{
                p_sending_enabled:!!$('admin-sms-sending')?.checked,
                p_invite_enabled:!!$('admin-sms-invites')?.checked,
                p_reminder_enabled:!!$('admin-sms-reminders')?.checked,
                p_reminder_hours_before:hours
            });
            if(error)return showToast(readableError(error),'error');
            showToast('הגדרות ה-SMS נשמרו.','success');await adminOpenTab('sms');
        }

        async function adminRetrySms(id){
            const ok=await askConfirm('שליחה חוזרת','לנסות לשלוח מחדש את הודעת ה-SMS שנכשלה?');
            if(!ok)return;
            const {error}=await _supabase.rpc('admin_retry_sms',{p_id:id});
            if(error)return showToast(readableError(error),'error');
            showToast('ההודעה הוחזרה לתור השליחה.','success');await adminOpenTab('sms');
        }

        async function adminRunSmsMaintenance(){
            const {error}=await _supabase.rpc('admin_run_sms_maintenance');
            if(error)return showToast(readableError(error),'error');
            showToast('תחזוקת SMS הושלמה.','success');await adminOpenTab('sms');
        }

        async function adminRenderReports(){
            const [{data:rows,error},{data:support,error:supportErr}]=await Promise.all([
                _supabase.rpc('admin_list_reports',{p_status:'all',p_limit:200}),
                _supabase.rpc('admin_list_support_requests',{p_status:'all',p_limit:200})
            ]);
            if(error)throw error;
            if(supportErr)throw supportErr;
            rows=rows||[];support=support||[];
            return '<div class="space-y-5">'+
                '<div class="glass-card p-6"><h3 class="text-2xl font-bold">פניות למנהל</h3><p class="text-sm text-slate-500">פניות כלליות שנשלחו מטופס יצירת הקשר באתר.</p><div class="space-y-3 mt-5">'+(support.length?support.map(r=>'<div class="border rounded-xl p-4 '+(r.status==='open'?'bg-amber-50 border-amber-200':'bg-white')+'"><div class="flex flex-wrap justify-between gap-3"><div><div class="font-bold">'+esc(r.subject)+'</div><div class="text-sm text-slate-700 mt-1 whitespace-pre-line">'+esc(r.message)+'</div><div class="text-xs text-slate-400 mt-2">'+esc(r.name)+' · <span dir="ltr">'+esc(displayPhone(r.phone||''))+'</span> · '+esc(adminDateTime(r.created_at))+'</div></div><div>'+adminStatusPill(r.status,r.status==='open'?'warn':'neutral')+(r.status==='open'?'<div class="flex gap-2 mt-2"><button onclick="adminResolveSupport(\''+esc(r.id)+'\',\'resolved\')" class="bg-green-50 text-green-700 border border-green-200 rounded-lg px-3 py-2 text-sm font-bold">טופל</button><button onclick="adminResolveSupport(\''+esc(r.id)+'\',\'dismissed\')" class="btn-soft px-3 py-2">דחה</button></div>':'')+'</div></div></div>').join(''):'<p class="text-slate-500 py-8 text-center">אין פניות.</p>')+'</div></div>'+
                '<div class="glass-card p-6"><h3 class="text-2xl font-bold">דיווחים על אירועים</h3><p class="text-sm text-slate-500">דיווחי בטיחות או בעיות שנשלחו מתוך אירועים.</p><div class="space-y-3 mt-5">'+(rows.length?rows.map(r=>'<div class="border rounded-xl p-4 '+(r.status==='open'?'bg-amber-50 border-amber-200':'bg-white')+'"><div class="flex flex-wrap justify-between gap-3"><div><div class="font-bold">'+esc(r.event_name)+'</div><div class="text-sm text-slate-600">'+esc(r.reason||'ללא פירוט')+'</div><div class="text-xs text-slate-400 mt-2">מדווח: '+esc(r.reporter_name)+' · <span dir="ltr">'+esc(displayPhone(r.reporter_phone||''))+'</span> · '+esc(adminDateTime(r.created_at))+'</div></div><div>'+adminStatusPill(r.status,r.status==='open'?'warn':'neutral')+(r.status==='open'?'<div class="flex gap-2 mt-2"><button onclick="adminResolveReport(\''+esc(r.id)+'\',\'resolved\')" class="bg-green-50 text-green-700 border border-green-200 rounded-lg px-3 py-2 text-sm font-bold">טופל</button><button onclick="adminResolveReport(\''+esc(r.id)+'\',\'dismissed\')" class="btn-soft px-3 py-2">דחה</button></div>':'')+'</div></div></div>').join(''):'<p class="text-slate-500 py-8 text-center">אין דיווחים.</p>')+'</div></div>'+
            '</div>';
        }

        async function adminResolveSupport(id,status){
            const {error}=await _supabase.rpc('admin_resolve_support_request',{p_id:id,p_status:status});
            if(error)return showToast(readableError(error),'error');
            showToast('הפנייה עודכנה.','success');
            await adminOpenTab('reports');
        }

        function adminTemplateLabel(kind){
            return ({
                event_invite:'הזמנה לאירוע',
                event_reminder:'תזכורת לפני אירוע',
                event_changed:'שינוי מהותי באירוע',
                event_note_update:'עדכון הערה',
                event_cancelled:'אירוע בוטל',
                registration_confirmed:'הרשמה אושרה',
                registration_cancelled:'הרשמה בוטלה',
                waitlist_joined:'כניסה לרשימת המתנה',
                waitlist_promoted:'קידום מרשימת המתנה',
                attendance_confirmed:'אישור הגעה',
                invite_declined:'דחיית הזמנה'
            })[kind]||kind;
        }

        function adminContentField(key,label,multiline=false){
            const value=adminEditorState?.content?.[key]||'';
            return '<label><span class="field-label">'+esc(label)+'</span>'+
                (multiline?'<textarea id="admin-content-'+key+'" class="input-clean min-h-24">'+esc(value)+'</textarea>':'<input id="admin-content-'+key+'" class="input-clean" value="'+esc(value)+'">')+
            '</label>';
        }

        function adminConfigRows(kind,items){
            return '<div class="space-y-2">'+(items||[]).map((x,i)=>
                '<div class="grid grid-cols-[auto_1fr_auto] gap-3 items-center border rounded-lg p-3">'+
                    '<span class="text-xs font-mono text-slate-400">'+esc(x.value)+'</span>'+
                    '<input id="admin-config-'+kind+'-label-'+i+'" class="input-clean" value="'+esc(x.label||'')+'">'+
                    '<label class="text-sm font-bold flex gap-2 items-center"><input id="admin-config-'+kind+'-enabled-'+i+'" type="checkbox" '+(x.enabled!==false?'checked':'')+'> פעיל</label>'+
                '</div>'
            ).join('')+'</div>';
        }

        function adminFieldLabelsEditor(){
            const defs={
                vol_name:'שם מלא — הרשמת משמח/ת',
                vol_phone:'טלפון — הרשמת משמח/ת',
                vol_gender:'פנייה — הרשמת משמח/ת',
                vol_birth_year:'שנת לידה — הרשמת משמח/ת',
                vol_sector:'מגזר — הרשמת משמח/ת',
                vol_address:'כתובת — הרשמת משמח/ת',
                event_name:'שם האירוע',
                event_type:'סוג האירוע',
                event_date:'תאריך האירוע',
                event_start:'שעת התחלה',
                event_end:'שעת סיום',
                event_deadline:'מועד אחרון להרשמה',
                event_venue:'כותרת כתובת/אולם',
                event_age_range:'טווח גילאים',
                host_name:'שם בעל השמחה',
                host_phone:'טלפון בעל השמחה',
                host_password:'סיסמת בעל השמחה',
                host_password_confirm:'אימות סיסמת בעל השמחה',
                family_name:'שם ילד/ה',
                family_gender:'פנייה לילד/ה',
                family_birth_year:'שנת לידה לילד/ה',
                family_sector:'מגזר ילד/ה'
            };
            const current=adminEditorState?.field_config?.labels||{};
            return '<div class="grid grid-cols-1 md:grid-cols-2 gap-3">'+Object.entries(defs).map(([key,desc])=>
                '<label><span class="field-label">'+esc(desc)+'</span><input id="admin-field-label-'+key+'" class="input-clean" value="'+esc(current[key]||'')+'" placeholder="'+esc(desc)+'"></label>'
            ).join('')+'</div>';
        }

        async function adminRenderSettings(){
            const [{data:site,error:siteErr},{data:sms,error:smsErr},{data:editor,error:editorErr},{data:templates,error:templatesErr},{data:textRows,error:textErr}]=await Promise.all([
                _supabase.rpc('admin_site_settings'),
                _supabase.rpc('admin_sms_status'),
                _supabase.rpc('admin_site_editor_state'),
                _supabase.rpc('admin_list_sms_templates'),
                _supabase.rpc('admin_list_site_texts',{p_search:adminTextSearch||'',p_limit:200,p_offset:0})
            ]);
            if(siteErr)throw siteErr;if(smsErr)throw smsErr;if(editorErr)throw editorErr;if(templatesErr)throw templatesErr;if(textErr)throw textErr;
            adminEditorState=editor||{content:{},field_config:{}};
            adminTextRows=textRows||[];
            const ss=sms?.settings||{};
            const cfg=adminEditorState.field_config||{};
            const eventTypes=cfg.event_types||[];
            const ageRanges=cfg.age_ranges||[];
            const radii=cfg.radius_options||[];
            const sectors=cfg.sectors||[];

            return '<div class="space-y-5">'+
                '<div class="glass-card p-6"><h3 class="text-2xl font-bold">הגדרות תפעוליות</h3><p class="text-sm text-slate-500">מתגים מרכזיים לעצירה או הפעלה של פעולות באתר במקרה הצורך.</p><form onsubmit="event.preventDefault(); adminSaveSiteSettings();" class="space-y-4 mt-5">'+
                    '<label class="flex items-start justify-between gap-4 border rounded-xl p-4"><span><b>הרשמות חדשות</b><span class="block text-sm text-slate-500">מאפשר יצירת חשבונות חדשים למשמחים ולבעלי שמחה.</span></span><input id="admin-setting-registration" type="checkbox" '+(site?.registration_enabled?'checked':'')+' class="mt-1 w-5 h-5"></label>'+
                    '<label class="flex items-start justify-between gap-4 border rounded-xl p-4"><span><b>פרסום אירועים חדשים</b><span class="block text-sm text-slate-500">משתמשים קיימים יוכלו או לא יוכלו לפרסם אירוע חדש.</span></span><input id="admin-setting-events" type="checkbox" '+(site?.event_creation_enabled?'checked':'')+' class="mt-1 w-5 h-5"></label>'+
                    '<label class="flex items-start justify-between gap-4 border rounded-xl p-4"><span><b>הוספת ילדים בגיל 12–17</b><span class="block text-sm text-slate-500">שולט באפשרות של הורה להוסיף ילד/ה לחשבון המשפחתי.</span></span><input id="admin-setting-minors" type="checkbox" '+(site?.minor_registration_enabled?'checked':'')+' class="mt-1 w-5 h-5"></label>'+
                    '<label class="flex items-start justify-between gap-4 border rounded-xl p-4"><span><b>הצגת כתובת מדויקת לפני הרשמה</b><span class="block text-sm text-slate-500">מומלץ להשאיר כבוי: לפני הרשמה יוצגו אולם ועיר בלבד; אחרי הרשמה מאושרת תוצג הכתובת המלאה.</span></span><input id="admin-setting-exact-venue" type="checkbox" '+(site?.show_exact_venue_before_registration?'checked':'')+' class="mt-1 w-5 h-5"></label>'+
                    '<label class="flex items-start justify-between gap-4 border rounded-xl p-4"><span><b>ניקוד ודרגות למשמחים</b><span class="block text-sm text-slate-500">כשהאפשרות כבויה לא מוצגים ניקוד או דרגות. כשהיא פעילה, כל אישור הגעה מצד המשמח/ת מעניק 100 נקודות.</span></span><input id="admin-setting-volunteer-scoring" type="checkbox" '+(site?.volunteer_scoring_enabled?'checked':'')+' class="mt-1 w-5 h-5"></label>'+
                    '<button class="btn-dark px-5 py-3">שמור הגדרות תפעול</button>'+
                '</form></div>'+

                '<div class="glass-card p-6"><div class="flex flex-wrap justify-between gap-3"><div><h3 class="text-2xl font-bold">לוגו ותמונת דף הבית</h3><p class="text-sm text-slate-500">הקבצים עולים לאחסון מאובטח דרך השרת. מפתח השירות של Supabase לא נשלח לדפדפן.</p></div><button onclick="adminSaveContentEditor()" class="btn-dark px-5 py-3">שמור תוכן ועיצוב</button></div>'+
                    '<input type="hidden" id="admin-logo-url" value="'+esc(adminEditorState.logo_url||'')+'"><input type="hidden" id="admin-hero-url" value="'+esc(adminEditorState.hero_url||'')+'">'+
                    '<div class="grid grid-cols-1 lg:grid-cols-2 gap-5 mt-5">'+
                        '<div class="border rounded-xl p-4"><b>לוגו</b><div class="bg-slate-50 rounded-lg mt-3 p-3"><img id="admin-logo-preview" src="'+esc(adminEditorState.logo_url||'')+'" alt="תצוגה מקדימה של לוגו האתר" class="max-h-36 mx-auto object-contain"></div><input id="admin-logo-file" type="file" accept="image/png,image/jpeg,image/webp,image/gif" class="input-clean mt-3"><button onclick="adminUploadAsset(\'logo\')" class="btn-soft px-4 py-2 mt-2">העלה לוגו</button></div>'+
                        '<div class="border rounded-xl p-4"><b>תמונת דף הבית</b><div class="bg-slate-50 rounded-lg mt-3 p-3"><img id="admin-hero-preview" src="'+esc(adminEditorState.hero_url||'')+'" alt="תצוגה מקדימה של תמונת דף הבית" class="max-h-36 mx-auto object-contain"></div><input id="admin-hero-file" type="file" accept="image/png,image/jpeg,image/webp,image/gif" class="input-clean mt-3"><button onclick="adminUploadAsset(\'hero\')" class="btn-soft px-4 py-2 mt-2">העלה תמונה</button></div>'+
                    '</div><p class="text-xs text-slate-400 mt-3">עד 5MB. JPG, PNG, WebP או GIF. העלאה לבדה אינה מפרסמת את השינוי עד ללחיצה על “שמור תוכן ועיצוב”.</p>'+
                '</div>'+

                '<div class="glass-card p-6"><h3 class="text-2xl font-bold">טקסטים באתר</h3><p class="text-sm text-slate-500">הטקסטים נשמרים כטקסט פשוט בלבד — לא ניתן להכניס HTML או קוד.</p><div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-5">'+
                    adminContentField('home_volunteer_title','כותרת — אני רוצה לשמח')+
                    adminContentField('home_volunteer_subtitle','תיאור — אני רוצה לשמח')+
                    adminContentField('home_host_title','כותרת — יש לי אירוע')+
                    adminContentField('home_host_subtitle','תיאור — יש לי אירוע')+
                    adminContentField('home_account_title','כותרת — אזור אישי')+
                    adminContentField('home_account_subtitle','תיאור — אזור אישי')+
                    adminContentField('login_title','כותרת התחברות')+
                    adminContentField('login_subtitle','תיאור התחברות')+
                    adminContentField('volunteer_registration_title','כותרת הרשמת משמח/ת')+
                    adminContentField('volunteer_registration_subtitle','תיאור הרשמת משמח/ת',true)+
                    adminContentField('family_title','כותרת אזור המשפחה')+
                    adminContentField('family_subtitle','תיאור אזור המשפחה',true)+
                    adminContentField('footer_privacy_label','טקסט קישור מדיניות פרטיות')+
                    adminContentField('footer_terms_label','טקסט קישור תנאי שימוש')+
                '</div><button onclick="adminSaveContentEditor()" class="btn-dark px-5 py-3 mt-5">שמור תוכן ועיצוב</button></div>'+

                '<div class="glass-card p-6"><h3 class="text-2xl font-bold">אפשרויות ושדות</h3><p class="text-sm text-slate-500">אפשר לשנות שמות ולהסתיר אפשרויות קיימות. הערכים הפנימיים נשארים קבועים כדי לא לפגוע בהתאמות ובנתונים קיימים.</p>'+
                    '<div class="grid grid-cols-1 xl:grid-cols-2 gap-6 mt-5">'+
                        '<div><h4 class="font-bold mb-3">סוגי אירועים</h4>'+adminConfigRows('event',eventTypes)+'<label class="block mt-3"><span class="field-label">ברירת מחדל בהרשמת משמח/ת</span><select id="admin-config-event-default" class="input-clean bg-white">'+eventTypes.filter(x=>x.enabled!==false).map(x=>'<option value="'+esc(x.value)+'" '+(cfg.volunteer_event_default===x.value?'selected':'')+'>'+esc(x.label)+'</option>').join('')+'</select></label></div>'+
                        '<div><h4 class="font-bold mb-3">טווחי גיל</h4>'+adminConfigRows('age',ageRanges)+'</div>'+
                        '<div><h4 class="font-bold mb-3">מרחקים</h4>'+adminConfigRows('radius',radii)+'</div>'+
                        '<div><h4 class="font-bold mb-3">מגזרים</h4>'+adminConfigRows('sector',sectors)+'</div>'+
                    '</div><div class="border-t mt-6 pt-5"><h4 class="font-bold mb-3">שמות שדות בטפסים</h4><p class="text-sm text-slate-500 mb-4">אפשר לשנות את הכיתוב שמוצג למשתמש בלי לשנות את מבנה הנתונים או את כללי האבטחה.</p>'+adminFieldLabelsEditor()+'</div><button onclick="adminSaveContentEditor()" class="btn-dark px-5 py-3 mt-5">שמור אפשרויות ושדות</button>'+
                '</div>'+

                '<div class="glass-card p-6"><div class="flex flex-wrap justify-between gap-3 items-end"><div><h3 class="text-2xl font-bold">כל הטקסטים באתר</h3><p class="text-sm text-slate-500">עורך כללי לטקסטים שמופיעים למשתמשים — כפתורים, הסברים, הודעות שגיאה, הודעות מערכת, מדיניות ותנאים. השינוי הוא טקסט בלבד ואינו יכול להפעיל HTML או קוד.</p></div><div class="flex gap-2"><input id="admin-text-search" class="input-clean min-w-64" value="'+esc(adminTextSearch)+'" placeholder="חפש טקסט..."><button onclick="adminSearchSiteTexts()" class="btn-soft px-4">חפש</button></div></div>'+
                    '<div class="mt-5 text-xs text-slate-400">מוצגים עד 200 פריטים בכל חיפוש. טקסטים שכבר שונו מופיעים ראשונים.</div>'+
                    '<div class="space-y-3 mt-4 max-h-[50rem] overflow-auto">'+(adminTextRows.length?adminTextRows.map((row,i)=>'<div class="border rounded-xl p-4"><div class="text-xs text-slate-400 mb-2">מקור</div><div class="text-sm bg-slate-50 rounded-lg p-3">'+esc(row.source_text)+'</div><label class="block mt-3"><span class="field-label">הטקסט שיוצג</span><textarea id="admin-site-text-'+i+'" class="input-clean min-h-20">'+esc(row.replacement??row.source_text)+'</textarea></label><div class="flex gap-2 mt-3"><button onclick="adminSaveSiteText('+i+')" class="btn-brand px-3 py-2 text-sm">שמור</button>'+(row.replacement&&row.replacement!==row.source_text?'<button onclick="adminResetSiteText('+i+')" class="btn-soft px-3 py-2 text-sm">שחזר מקורי</button>':'')+'</div></div>').join(''):'<p class="text-slate-500 py-6 text-center">לא נמצאו טקסטים בחיפוש.</p>')+'</div>'+
                '</div>'+
                '<div class="glass-card p-6"><div class="flex flex-wrap justify-between gap-3"><div><h3 class="text-2xl font-bold">נוסחי הודעות SMS</h3><p class="text-sm text-slate-500">אפשר לערוך את כל ההודעות. משתנים מותרים: {{event_name}}, {{date}}, {{time}}, {{place}}, {{address}}, {{sector}}, {{separation}}, {{note}}, {{link}}.</p></div><button onclick="adminOpenTab(\'sms\')" class="btn-soft px-4 py-2">הגדרות שליחה</button></div>'+
                    '<div class="space-y-5 mt-5">'+(templates||[]).map(t=>'<div class="border rounded-xl p-4"><div class="flex flex-wrap justify-between gap-2 items-center"><div><b>'+esc(adminTemplateLabel(t.kind))+'</b><div class="text-xs text-slate-400 font-mono">'+esc(t.kind)+'</div></div><div class="flex gap-2"><button onclick="adminSaveSmsTemplate(\''+esc(t.kind)+'\')" class="btn-brand px-3 py-2 text-sm">שמור נוסח</button><button onclick="adminResetSmsTemplate(\''+esc(t.kind)+'\')" class="btn-soft px-3 py-2 text-sm">שחזר ברירת מחדל</button></div></div><textarea id="admin-sms-template-'+esc(t.kind)+'" class="input-clean min-h-48 mt-3" dir="rtl">'+esc(t.template_text||'')+'</textarea></div>').join('')+'</div>'+
                '</div>'+

                '<div class="glass-card p-6"><h4 class="font-bold text-lg">מצב SMS מהיר</h4><div class="grid grid-cols-1 md:grid-cols-4 gap-3 mt-4">'+
                    adminMetric('שליחה כללית',ss.sending_enabled?'פעילה':'כבויה')+
                    adminMetric('הזמנות',ss.invite_enabled?'פעילות':'כבויות')+
                    adminMetric('תזכורות',ss.reminder_enabled?'פעילות':'כבויות')+
                    adminMetric('תזכורת לפני',Number(ss.reminder_hours_before||24)+' שעות')+
                '</div><button onclick="adminOpenTab(\'sms\')" class="btn-soft px-4 py-2 mt-4">פתח הגדרות SMS מלאות</button></div>'+
            '</div>';
        }

        async function adminSaveSiteSettings(){
            const ok=await askConfirm('שמירת הגדרות אתר','לשמור את ההגדרות התפעוליות? שינוי כאן משפיע מיידית על משתמשים.');
            if(!ok)return;
            const {error}=await _supabase.rpc('admin_update_site_settings_v3',{
                p_registration_enabled:!!$('admin-setting-registration')?.checked,
                p_event_creation_enabled:!!$('admin-setting-events')?.checked,
                p_minor_registration_enabled:!!$('admin-setting-minors')?.checked,
                p_show_exact_venue_before_registration:!!$('admin-setting-exact-venue')?.checked,
                p_volunteer_scoring_enabled:!!$('admin-setting-volunteer-scoring')?.checked
            });
            if(error)return showToast(readableError(error),'error');
            showToast('הגדרות האתר נשמרו.','success');
            await adminOpenTab('settings');
        }

        async function adminUploadAsset(kind){
            const input=$(kind==='logo'?'admin-logo-file':'admin-hero-file');
            const file=input?.files?.[0];
            if(!file)return showToast('יש לבחור קובץ תמונה.','warning');
            if(file.size>5*1024*1024)return showToast('הקובץ גדול מ־5MB.','error');
            const allowed=['image/jpeg','image/png','image/webp','image/gif'];
            if(!allowed.includes(file.type))return showToast('סוג הקובץ אינו נתמך.','error');
            try{
                const form=new FormData();
                form.append('kind',kind);
                form.append('file',file);
                const res=await fetch(SUPABASE_URL+'/functions/v1/admin-assets',{
                    method:'POST',
                    headers:{'apikey':SUPABASE_PUBLISHABLE_KEY,'x-app-session':sessionToken},
                    body:form
                });
                const json=await res.json().catch(()=>({}));
                if(!res.ok||!json?.url)throw new Error(json?.error||'upload_failed');
                const url=json.url;
                const hidden=$(kind==='logo'?'admin-logo-url':'admin-hero-url');
                const preview=$(kind==='logo'?'admin-logo-preview':'admin-hero-preview');
                if(hidden)hidden.value=url;if(preview)preview.src=url;
                showToast('התמונה הועלתה. לחץ “שמור תוכן ועיצוב” כדי לפרסם אותה.','success');
            }catch(e){showToast(readableError(e),'error');}
        }

        function adminCollectConfigRows(kind,items){
            return (items||[]).map((x,i)=>({
                ...x,
                label:$('admin-config-'+kind+'-label-'+i)?.value.trim()||x.label,
                enabled:!!$('admin-config-'+kind+'-enabled-'+i)?.checked
            }));
        }

        async function adminSaveContentEditor(){
            if(!adminEditorState)return;
            const content={};
            for(const key of [
                'home_volunteer_title','home_volunteer_subtitle','home_host_title','home_host_subtitle',
                'home_account_title','home_account_subtitle','login_title','login_subtitle',
                'volunteer_registration_title','volunteer_registration_subtitle','family_title','family_subtitle',
                'footer_privacy_label','footer_terms_label'
            ]) content[key]=$('admin-content-'+key)?.value.trim()||adminEditorState.content?.[key]||'';

            const base=adminEditorState.field_config||{};
            const labelKeys=[
                'vol_name','vol_phone','vol_gender','vol_birth_year','vol_sector','vol_address',
                'event_name','event_type','event_date','event_start','event_end','event_deadline','event_venue','event_age_range',
                'host_name','host_phone','host_password','host_password_confirm',
                'family_name','family_gender','family_birth_year','family_sector'
            ];
            const labels={...(base.labels||{})};
            labelKeys.forEach(key=>{
                const v=$('admin-field-label-'+key)?.value.trim();
                if(v)labels[key]=v; else delete labels[key];
            });
            const fieldConfig={
                ...base,
                labels,
                volunteer_event_default:$('admin-config-event-default')?.value||base.volunteer_event_default||'wedding',
                event_types:adminCollectConfigRows('event',base.event_types||[]),
                age_ranges:adminCollectConfigRows('age',base.age_ranges||[]),
                radius_options:adminCollectConfigRows('radius',base.radius_options||[]),
                sectors:adminCollectConfigRows('sector',base.sectors||[])
            };

            if(!fieldConfig.event_types.some(x=>x.enabled))return showToast('חייב להישאר לפחות סוג אירוע פעיל אחד.','error');
            if(!fieldConfig.age_ranges.some(x=>x.enabled))return showToast('חייב להישאר לפחות טווח גיל פעיל אחד.','error');
            if(!fieldConfig.radius_options.some(x=>x.enabled))return showToast('חייב להישאר לפחות מרחק פעיל אחד.','error');
            if(!fieldConfig.sectors.some(x=>x.enabled))return showToast('חייב להישאר לפחות מגזר פעיל אחד.','error');
            if(!fieldConfig.event_types.some(x=>x.enabled&&x.value===fieldConfig.volunteer_event_default)){
                return showToast('ברירת המחדל חייבת להיות סוג אירוע פעיל.','error');
            }

            const {error}=await _supabase.rpc('admin_update_site_editor',{
                p_logo_url:$('admin-logo-url')?.value||adminEditorState.logo_url,
                p_hero_url:$('admin-hero-url')?.value||adminEditorState.hero_url,
                p_content:content,
                p_field_config:fieldConfig
            });
            if(error)return showToast(readableError(error),'error');
            showToast('תוכן האתר והאפשרויות עודכנו.','success');
            await loadPublicSiteConfig();
            await adminOpenTab('settings');
        }

        async function adminSearchSiteTexts(){
            adminTextSearch=$('admin-text-search')?.value.trim()||'';
            await adminOpenTab('settings');
        }

        async function adminSaveSiteText(index){
            const row=adminTextRows[index];
            if(!row)return;
            const replacement=$('admin-site-text-'+index)?.value??row.source_text;
            const {error}=await _supabase.rpc('admin_update_site_text',{
                p_source_text:row.source_text,
                p_replacement:replacement
            });
            if(error)return showToast(readableError(error),'error');
            showToast('הטקסט עודכן.','success');
            await loadPublicSiteConfig();
            await adminOpenTab('settings');
        }

        async function adminResetSiteText(index){
            const row=adminTextRows[index];
            if(!row)return;
            const {error}=await _supabase.rpc('admin_reset_site_text',{p_source_text:row.source_text});
            if(error)return showToast(readableError(error),'error');
            showToast('הטקסט שוחזר למקור.','success');
            await loadPublicSiteConfig();
            await adminOpenTab('settings');
        }

        async function adminSaveSmsTemplate(kind){
            const text=$('admin-sms-template-'+kind)?.value||'';
            const {error}=await _supabase.rpc('admin_update_sms_template',{p_kind:kind,p_template_text:text});
            if(error)return showToast(readableError(error),'error');
            showToast('נוסח ההודעה נשמר.','success');
        }

        async function adminResetSmsTemplate(kind){
            const ok=await askConfirm('שחזור נוסח','להחזיר את נוסח ההודעה לברירת המחדל המקורית?');
            if(!ok)return;
            const {error}=await _supabase.rpc('admin_reset_sms_template',{p_kind:kind});
            if(error)return showToast(readableError(error),'error');
            showToast('הנוסח שוחזר.','success');
            await adminOpenTab('settings');
        }


        async function adminRenderVersions(){
            const res=await fetch('./versions/manifest.json?ts='+Date.now(),{cache:'no-store'});
            if(!res.ok)throw new Error('version_manifest_unavailable');
            const data=await res.json();
            const versions=Array.isArray(data?.versions)?data.versions:[];
            const cards=versions.map(v=>{
                const commit=String(v.commit||'');
                const commitUrl=commit?'https://github.com/nh8030954-art/smachim/commit/'+encodeURIComponent(commit):'';
                return '<div class="border rounded-xl p-4 bg-slate-50"><div class="flex flex-wrap justify-between gap-3 items-start"><div><div class="font-bold">'+esc(v.label||v.id||'גרסה')+'</div><div class="text-xs text-slate-500 mt-1">'+esc(v.date||'')+(commit?' · '+esc(commit.slice(0,8)):'')+'</div>'+(v.note?'<p class="text-sm text-slate-600 mt-2">'+esc(v.note)+'</p>':'')+'</div><div class="flex flex-wrap gap-2"><button type="button" onclick="adminPreviewVersion(\''+esc(v.path)+'\',\''+esc(v.label||'גרסה')+'\')" class="btn-brand px-3 py-2 text-sm">תצוגה</button><button type="button" onclick="adminDownloadVersion(\''+esc(v.path)+'\')" class="btn-soft px-3 py-2 text-sm">הורד index.html</button>'+(v.archive?'<a href="./'+esc(v.archive)+'" download class="btn-soft px-3 py-2 text-sm inline-flex items-center"><i class="fa-solid fa-file-zipper ml-1" aria-hidden="true"></i>ZIP מלא</a>':'')+(commitUrl?'<a target="_blank" rel="noopener" href="'+commitUrl+'" class="btn-soft px-3 py-2 text-sm inline-flex items-center">GitHub</a>':'')+'</div></div></div>';
            }).join('');
            return '<div class="space-y-5"><div class="glass-card p-6"><h3 class="text-2xl font-bold">גרסאות האתר</h3><p class="text-sm text-slate-500 mt-1">בכל שינוי עתידי ב־index.html או בקבצי העיצוב נשמר אוטומטית עותק של הגרסה הקודמת. אפשר לצפות בו בבטחה, להוריד את index.html, ובגיבויים האוטומטיים גם ZIP מלא של index.html ותיקיית assets.</p></div><div class="glass-card p-6"><div class="space-y-3">'+(cards||'<p class="text-slate-500">עדיין אין גרסאות שמורות.</p>')+'</div></div><div id="admin-version-preview" class="hidden glass-card p-4"><div class="flex justify-between gap-3 items-center mb-3"><h3 id="admin-version-preview-title" class="font-bold text-lg">תצוגת גרסה</h3><button type="button" onclick="$(\'admin-version-preview\').classList.add(\'hidden\')" class="btn-soft px-3 py-2">סגור תצוגה</button></div><iframe id="admin-version-frame" title="תצוגה בטוחה של גרסת אתר קודמת" sandbox="" class="w-full h-[70vh] border rounded-xl bg-white"></iframe><p class="text-xs text-slate-500 mt-2">התצוגה מנוטרלת מסקריפטים ולכן אינה יכולה לבצע פעולות במערכת.</p></div></div>';
        }

        async function adminPreviewVersion(path,label){
            const res=await fetch('./'+String(path||'').replace(/^\.\//,'')+'?ts='+Date.now(),{cache:'no-store'});
            if(!res.ok)return showToast('לא הצלחנו לפתוח את הגרסה.','error');
            let html=await res.text();
            const scriptRe=new RegExp('<script\\b[^>]*>[\\s\\S]*?<\\/script>','gi');
            html=html.replace(scriptRe,'');
            const base='<base href="'+location.origin+location.pathname.replace(/[^/]*$/,'')+'">';
            html=html.replace(/<head([^>]*)>/i,'<head$1>'+base);
            $('admin-version-preview-title').textContent='תצוגה: '+(label||'גרסה');
            $('admin-version-frame').srcdoc=html;
            $('admin-version-preview').classList.remove('hidden');
            $('admin-version-preview').scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});
        }

        async function adminDownloadVersion(path){
            const res=await fetch('./'+String(path||'').replace(/^\.\//,'')+'?ts='+Date.now(),{cache:'no-store'});
            if(!res.ok)return showToast('לא הצלחנו להוריד את הגרסה.','error');
            const html=await res.text();
            const blob=new Blob([html],{type:'text/html;charset=utf-8'});
            const url=URL.createObjectURL(blob);
            const a=document.createElement('a');
            a.href=url;a.download='index.html';a.click();
            setTimeout(()=>URL.revokeObjectURL(url),1000);
        }

        async function adminRenderSecurity(){
            const [{data:s,error:sErr},{data:audit,error:aErr},{data:health,error:hErr}]=await Promise.all([
                _supabase.rpc('admin_security_status'),
                _supabase.rpc('admin_audit_recent',{p_limit:100}),
                _supabase.rpc('admin_launch_health')
            ]);
            if(sErr)throw sErr;if(aErr)throw aErr;if(hErr)throw hErr;
            const a=s?.admin_account||{};
            return '<div class="space-y-5">'+
                '<div class="glass-card p-6"><h3 class="text-2xl font-bold">אבטחה והגדרות מנהל</h3><div class="grid grid-cols-2 md:grid-cols-5 gap-3 mt-5">'+adminMetric('סשנים משתמשים',s.active_user_sessions)+adminMetric('סשנים מנהל',s.active_admin_sessions)+adminMetric('סשנים שפג תוקפם',s.expired_sessions)+adminMetric('משתמשים חסומים',s.blocked_users)+adminMetric('ניסיונות מנהל שגויים',a.failed_attempts||0)+'</div><div class="mt-4 text-sm text-slate-500">שם משתמש מנהל: <b>'+esc(a.username||'—')+'</b> · נעילה עד: <b>'+esc(adminDateTime(a.locked_until))+'</b></div><div class="mt-2 text-xs text-slate-500 bg-slate-50 border rounded-lg p-3">סשן מנהל נשמר רק בכרטיסייה הנוכחית, פג בשרת אחרי שעתיים ונסגר בדפדפן לאחר 30 דקות ללא פעילות. רק סשן מנהל יכול לקרוא או לשנות נתוני ניהול.</div><button onclick="adminCleanupSessions()" class="btn-soft px-3 py-2 mt-4">נקה סשנים שפג תוקפם</button></div>'+
                renderAdminPasswordCard(false)+
                '<div class="glass-card p-6"><h4 class="font-bold text-lg mb-4">יומן פעולות מנהל</h4><div class="overflow-x-auto"><table class="w-full text-xs"><thead><tr class="border-b text-slate-500"><th class="text-right py-2">זמן</th><th>פעולה</th><th>יעד</th><th>פרטים</th></tr></thead><tbody>'+((audit||[]).map(x=>'<tr class="border-b border-slate-100"><td class="py-2 whitespace-nowrap">'+esc(adminDateTime(x.created_at))+'</td><td>'+esc(x.action)+'</td><td>'+esc((x.target_type||'')+(x.target_id?' / '+x.target_id:''))+'</td><td class="max-w-96">'+esc(x.details?JSON.stringify(x.details):'')+'</td></tr>').join('')||'<tr><td colspan="4" class="py-6 text-slate-500">עדיין אין פעולות ביומן.</td></tr>')+'</tbody></table></div></div>'+
                '<div class="glass-card p-6"><h4 class="font-bold">בדיקות הרשמה</h4><div class="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3 text-sm"><div class="border rounded-lg p-3">חשבונות ותיקים ללא אישור פרטיות: <b>'+Number(s.users_missing_privacy_consent||0)+'</b></div><div class="border rounded-lg p-3">חשבונות ותיקים ללא אישור SMS: <b>'+Number(s.users_missing_sms_consent||0)+'</b></div></div></div>'+
                '<div class="glass-card p-6"><h4 class="font-bold text-lg">בדיקת מוכנות להפצה</h4><div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3 mt-4 text-sm">'+
                    '<div class="border rounded-lg p-3">חשבונות ללא טלפון: <b>'+Number(health?.profiles_without_phone||0)+'</b></div>'+
                    '<div class="border rounded-lg p-3">משמחים ללא מיקום: <b>'+Number(health?.volunteers_missing_coords||0)+'</b></div>'+
                    '<div class="border rounded-lg p-3">אירועים פעילים ללא מיקום: <b>'+Number(health?.active_events_missing_location||0)+'</b></div>'+
                    '<div class="border rounded-lg p-3">הרשמות פעילות כפולות: <b>'+Number(health?.duplicate_active_registrations||0)+'</b></div>'+
                    '<div class="border rounded-lg p-3">SMS פעילים שפג תוקפם: <b>'+Number(health?.expired_pending_sms||0)+'</b></div>'+
                    '<div class="border rounded-lg p-3 '+(Number(health?.legacy_under18_nonfamily_volunteers||0)?'bg-amber-50 border-amber-200':'')+'">חשבונות ותיקים מתחת ל־18 שאינם חשבון משפחתי: <b>'+Number(health?.legacy_under18_nonfamily_volunteers||0)+'</b><span class="block text-xs text-slate-500 mt-1">חשבונות כאלה אינם יכולים להשתתף כמשמחים עד להסדרה.</span></div>'+
                '</div>'+(Number(health?.legacy_under18_currently_matchable||0)>0?'<div class="mt-4 bg-red-50 border border-red-200 text-red-700 rounded-lg p-3 font-bold">נמצאו חשבונות קטינים ישנים שעדיין יכולים לקבל התאמות — נדרש טיפול.</div>':'<div class="mt-4 bg-green-50 border border-green-200 text-green-700 rounded-lg p-3">לא נמצאה אפשרות להתאמה של קטין מחוץ לחשבון משפחתי.</div>')+'</div>'+
            '</div>';
        }

        async function adminCleanupSessions(){
            const {data,error}=await _supabase.rpc('admin_cleanup_expired_sessions');
            if(error)return showToast(readableError(error),'error');
            showToast('נוקו '+Number(data||0)+' סשנים שפג תוקפם.','success');await adminOpenTab('security');
        }

        async function refreshAdminView(){await adminOpenTab(adminTab);}

        async function adminToggleBlock(profileId,blocked){
            const ok=await askConfirm(blocked?'חסימת משתמש':'פתיחת חסימה',blocked?'לחסום את המשתמש ולנתק את הסשנים הפעילים שלו?':'לפתוח את החסימה?');
            if(!ok)return;
            const {error}=await _supabase.rpc('admin_set_blocked',{p_profile_id:profileId,p_blocked:blocked});
            if(error)return showToast(readableError(error),'error');
            showToast(blocked?'המשתמש נחסם.':'החסימה הוסרה.','success');
            await adminOpenTab('users');
        }

        async function adminResolveReport(reportId,status){
            const {error}=await _supabase.rpc('admin_resolve_report',{p_report_id:reportId,p_status:status});
            if(error)return showToast(readableError(error),'error');
            showToast('הדיווח עודכן.','success');await adminOpenTab('reports');
        }

        async function adminCancelEvent(eventId){
            const ok=await askConfirm('ביטול אירוע כמנהל','לבטל את האירוע? הנרשמים יקבלו התראה והודעות פעילות של האירוע יבוטלו.','בטל אירוע');
            if(!ok)return;
            const {error}=await _supabase.rpc('admin_cancel_event',{p_event_id:eventId});
            if(error)return showToast(readableError(error),'error');
            showToast('האירוע בוטל.','success');await adminOpenTab('events');
        }

        loadAccessibilityPreferences();
        initAccessibility();
        populateBirthYears();
        populateFamilyBirthYears();
        syncVolunteerGuardianMode();
        syncEventAgeRangeOptions('');
        syncEventAgeRangeOptions('edit-');
        bindAllChoice('vol-sector-pref');
        bindAllChoice('vol-event-type-pref');
        bindAllChoice('ev-accepted-sector');
        bindAllChoice('edit-ev-accepted-sector');
        bindAllChoice('profile-sector-pref');
        bindAllChoice('profile-event-type-pref');
        $('ev-type')?.addEventListener('change',()=>syncEventAgeRangeOptions(''));
        $('edit-ev-type')?.addEventListener('change',()=>syncEventAgeRangeOptions('edit-'));
        $('ev-date')?.addEventListener('change',e=>guardEventDateInput(e.target));
        $('edit-ev-date')?.addEventListener('change',e=>guardEventDateInput(e.target));
        initializeAddressLists();
        initEventDraftAutosave();
        updateHeaderActions();
        $('modal-input')?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();resolveAppModal(true);}});
        $('chat-input')?.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key==='Enter'){e.preventDefault();sendChatMessage();}});
        ['pointerdown','keydown'].forEach(evt=>document.addEventListener(evt,()=>{if(adminMode)armAdminIdleLogout();},{passive:true}));
        loadPublicSiteConfig().finally(()=>initSession());
